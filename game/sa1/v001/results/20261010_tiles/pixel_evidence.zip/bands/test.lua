local labels={["LoadAudioData"]=36481,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=37084,["Tad_GetSong"]=37188,["Tad_GlobalVolumesPersist"]=37216,["Tad_GlobalVolumesResetOnSongStart"]=37210,["Tad_Init"]=36700,["Tad_IsLoaderActive"]=37242,["Tad_IsSfxPlaying"]=37256,["Tad_IsSongLoaded"]=37250,["Tad_IsSongPlaying"]=37262,["Tad_LoadSong"]=37143,["Tad_LoadSongIfChanged"]=37176,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=36827,["Tad_QueueCommand"]=37100,["Tad_QueueCommandOverride"]=37105,["Tad_QueuePannedSoundEffect"]=37122,["Tad_QueueSoundEffect"]=37132,["Tad_ReloadCommonAudioData"]=37192,["Tad_SetTransferSize"]=37222,["Tad_SongsStartImmediately"]=37198,["Tad_SongsStartPaused"]=37204,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=45,["Tad_sfxQueue_sfx"]=44,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5777,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62282,["__COLORBSS_LOAD__"]=1024,["__COLORBSS_RUN__"]=1024,["__COLORBSS_SIZE__"]=3072,["__DATA_LOAD__"]=12764155,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__SA1_LOAD__"]=37514,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=1007,["__STARTUP__"]=1,["_abs"]=61913,["_boss_age"]=63649,["_boss_attribute_cache"]=63484,["_boss_attribute_cache_count"]=63646,["_boss_attribute_z_cache"]=63628,["_boss_dda_phase"]=63867,["_boss_dda_x"]=63873,["_boss_dda_y"]=63879,["_boss_death_parts"]=63651,["_boss_death_timer"]=63650,["_boss_fire_gap"]=63660,["_boss_fire_round"]=63657,["_boss_fire_shots"]=63659,["_boss_fire_state"]=63656,["_boss_fire_volley"]=63658,["_boss_history_x"]=63100,["_boss_history_y"]=63228,["_boss_history_z"]=63356,["_boss_last_vblank"]=63036,["_boss_motion_steps"]=63655,["_boss_part_active"]=63064,["_boss_part_bottom"]=63046,["_boss_part_fall_fraction"]=63091,["_boss_part_fall_velocity"]=63082,["_boss_part_timer"]=63073,["_boss_part_x"]=63037,["_boss_part_z"]=63055,["_boss_path_half"]=63654,["_boss_player_bottom"]=63663,["_boss_player_x"]=63661,["_boss_render_camera_delta"]=63647,["_boss_restart_timer"]=63652,["_boss_z_phase"]=63653,["_death_accel_fraction"]=63901,["_death_timer"]=63899,["_death_vy"]=63898,["_enemy_p0_samples"]=47713,["_enemy_p1_samples"]=48448,["_enemy_p2_samples"]=49153,["_enemy_p3_samples"]=49858,["_enemy_p4_samples"]=50563,["_enemy_p5_samples"]=51280,["_enemy_p6_samples"]=51997,["_enemy_p7_samples"]=52564,["_enemy_p8_samples"]=53131,["_fx4_explosion_lift"]=907,["_fx_asset_bank"]=27546,["_fx_asset_height"]=27502,["_fx_asset_width"]=27458,["_fx_audio_events"]=5648,["_fx_boss_hits"]=12668,["_fx_boss_project"]=13242,["_fx_build_ground"]=2193,["_fx_build_packet"]=1283,["_fx_buttons"]=61258,["_fx_draw"]=59334,["_fx_draw_count"]=59974,["_fx_em0_geometry"]=15169,["_fx_enemy_collisions"]=14636,["_fx_enemy_em1_update"]=16388,["_fx_enemy_em1_update_reference"]=25057,["_fx_enemy_fire_em1"]=24995,["_fx_enemy_remove"]=24984,["_fx_enemy_render"]=15307,["_fx_enemy_render_bullets"]=15586,["_fx_far_d_acc"]=61270,["_fx_far_u_acc"]=61268,["_fx_fire_actions"]=61261,["_fx_frame"]=16682,["_fx_ground_c1ptr"]=63026,["_fx_ground_c3ptr"]=63028,["_fx_ground_camera"]=27590,["_fx_ground_color1"]=61277,["_fx_ground_color3"]=61727,["_fx_ground_depth_rows"]=27735,["_fx_ground_far_x"]=62992,["_fx_ground_far_xptr"]=63022,["_fx_ground_far_y"]=63032,["_fx_ground_greens"]=33081,["_fx_ground_horizon"]=63030,["_fx_ground_horizontal"]=62177,["_fx_ground_hptr"]=62987,["_fx_ground_native"]=2278,["_fx_ground_palette_record"]=62990,["_fx_ground_phase"]=61257,["_fx_ground_vptr"]=63024,["_fx_ground_width"]=33000,["_fx_ground_world_phase"]=62989,["_fx_init"]=17445,["_fx_input"]=61260,["_fx_open_size"]=58596,["_fx_packet"]=59977,["_fx_packet_count"]=59975,["_fx_present"]=334,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=33089,["_fx_stage_contact"]=60459,["_fx_stage_render"]=59749,["_fx_stage_update"]=60790,["_fx_submit"]=61143,["_ground_irq_vblank_count"]=61265,["_history_head"]=63648,["_hit_pending"]=61272,["_intro_timer"]=63902,["_legacy_enemy_fire_boss_at"]=23589,["_main"]=17482,["_memcpy"]=61744,["_monosh_bom_geometry"]=43346,["_monosh_boss_body_geometry"]=39089,["_monosh_boss_bom_depth_by_size"]=39533,["_monosh_boss_bom_geometry"]=39311,["_monosh_boss_bullet_velocity"]=39771,["_monosh_boss_draw_order_base"]=34547,["_monosh_boss_draw_order_mid"]=36707,["_monosh_boss_explosion_ground_bottom"]=39660,["_monosh_boss_explosion_scale_low"]=39549,["_monosh_boss_face_geometry"]=38867,["_monosh_boss_frame"]=17671,["_monosh_boss_hp"]=63035,["_monosh_boss_init"]=17514,["_monosh_boss_path_center_y"]=33587,["_monosh_boss_path_center_y_mid"]=34307,["_monosh_boss_path_x"]=33347,["_monosh_boss_path_x_mid"]=34067,["_monosh_boss_path_z"]=33107,["_monosh_boss_path_z_mid"]=33827,["_monosh_boss_prepare_fire"]=19570,["_monosh_boss_prepare_render"]=17707,["_monosh_boss_render_only"]=13022,["_monosh_boss_should_restart"]=17493,["_monosh_boss_state"]=63034,["_monosh_bullet_reflect_rng"]=63705,["_monosh_collision_bullet_bands"]=63697,["_monosh_combat_build_collision_bands"]=19752,["_monosh_combat_fast_cache_reset"]=14221,["_monosh_combat_fast_frame"]=13437,["_monosh_combat_fast_render"]=13567,["_monosh_combat_fast_render_cached"]=14228,["_monosh_combat_fire_cooldown"]=63706,["_monosh_combat_half_frame"]=63707,["_monosh_combat_init"]=19596,["_monosh_combat_reflect_bullet"]=13866,["_monosh_combat_render"]=19749,["_monosh_combat_update"]=19691,["_monosh_ebullet4_geometry"]=44153,["_monosh_ebullet_animation_geometry"]=43931,["_monosh_ebullet_geometry"]=44375,["_monosh_ebullet_velocity"]=44385,["_monosh_em1_animation_assets_ready"]=63862,["_monosh_em1_closed_geometry"]=43568,["_monosh_em1_open_geometry"]=43790,["_monosh_enemies"]=63711,["_monosh_enemy_active_count"]=20512,["_monosh_enemy_active_count_value"]=63709,["_monosh_enemy_bullet_count"]=63708,["_monosh_enemy_bullets"]=63791,["_monosh_enemy_camera_delta_cached"]=63860,["_monosh_enemy_collision_cursor"]=63865,["_monosh_enemy_draw_cache_valid"]=63863,["_monosh_enemy_em1_count"]=63861,["_monosh_enemy_em1_phase"]=63836,["_monosh_enemy_em1_shrink"]=63852,["_monosh_enemy_fast_advance"]=15980,["_monosh_enemy_fast_check_player_bullets"]=21602,["_monosh_enemy_fast_render"]=21087,["_monosh_enemy_fast_render_bullets"]=22552,["_monosh_enemy_fast_spawn_due"]=22928,["_monosh_enemy_fast_update_bullets"]=14306,["_monosh_enemy_fire_at"]=20524,["_monosh_enemy_fire_boss_at"]=20553,["_monosh_enemy_fire_em0_fast"]=23987,["_monosh_enemy_frame"]=20315,["_monosh_enemy_geometry"]=43124,["_monosh_enemy_ground_bottom"]=43820,["_monosh_enemy_half_frame"]=63864,["_monosh_enemy_init"]=20166,["_monosh_enemy_path_fire_frames"]=53743,["_monosh_enemy_path_frames"]=53734,["_monosh_enemy_paths"]=53698,["_monosh_enemy_player_hit"]=63866,["_monosh_enemy_render_only"]=20345,["_monosh_enemy_spawn_index"]=63833,["_monosh_enemy_spawn_wait"]=63834,["_monosh_enemy_spawns"]=53752,["_monosh_enemy_stage_complete"]=20518,["_monosh_enemy_stage_complete_flag"]=63710,["_monosh_ground_depth_pointer"]=61275,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=63889,["_monosh_player_bullet_count"]=63680,["_monosh_player_bullet_sizes"]=43099,["_monosh_player_bullets"]=63665,["_monosh_player_can_fire"]=26815,["_monosh_player_draw_asset"]=26831,["_monosh_player_draw_flags"]=26773,["_monosh_player_init"]=26710,["_monosh_player_invuln"]=63892,["_monosh_player_pose"]=63894,["_monosh_player_state"]=63891,["_monosh_player_stumble"]=63893,["_monosh_player_update"]=29163,["_monosh_player_update_reference"]=28040,["_monosh_player_world_active"]=26809,["_monosh_player_x"]=63887,["_monosh_project_x"]=29773,["_monosh_reflected_bullet_count"]=63696,["_monosh_reflected_bullets"]=63681,["_monosh_runtime_fire_actions"]=61262,["_monosh_runtime_frame_counter"]=61263,["_monosh_runtime_paused"]=61267,["_monosh_stage1_spawn_count"]=54894,["_monosh_stage1_spawns"]=53958,["_monosh_stage_collision_bullet_cursor"]=64141,["_monosh_stage_collision_bullet_index"]=64142,["_monosh_stage_contact_result"]=64139,["_monosh_stage_draw_cache_valid"]=64140,["_monosh_stage_frame"]=28315,["_monosh_stage_frame_counter"]=64003,["_monosh_stage_geometry"]=57560,["_monosh_stage_half_frame"]=64007,["_monosh_stage_hitbox_count"]=64137,["_monosh_stage_hitboxes"]=64009,["_monosh_stage_init"]=28280,["_monosh_stage_is_clear"]=28364,["_monosh_stage_lift"]=58349,["_monosh_stage_near_count"]=64008,["_monosh_stage_need_hitboxes"]=64138,["_monosh_stage_object_count"]=64001,["_monosh_stage_objects"]=63905,["_monosh_stage_render_only"]=28361,["_monosh_stage_spawn_index"]=64002,["_monosh_stage_spawn_wait"]=64005,["_monosh_stage_title_timer"]=63895,["_monosh_title_draw"]=17471,["_monosh_title_visible"]=58365,["_movement_fraction"]=63900,["_old_buttons"]=61273,["_player_flip"]=63903,["_player_fy"]=63896,["_player_run_phase"]=63904,["_pose_x_01"]=53896,["_pose_x_12"]=53915,["_pose_x_23"]=53934,["_stage_bom0_geometry"]=57116,["_stage_bush0_geometry"]=54896,["_stage_bush1_geometry"]=55340,["_stage_em0_geometry"]=56228,["_stage_flystone_geometry"]=55784,["_stage_lift_0"]=57572,["_stage_lift_1"]=57683,["_stage_lift_2"]=57794,["_stage_lift_3"]=57905,["_stage_lift_4"]=58016,["_stage_lift_5"]=58127,["_stage_lift_6"]=58238,["_stage_tree0_geometry"]=56672,["_v9968_copy_to_vram_linear"]=14222,["addeq0sp"]=61383,["addeqysp"]=61385,["addysp"]=61401,["addysp1"]=61400,["aslax2"]=61414,["aslax3"]=61425,["aslax4"]=61439,["asrax1"]=61456,["asrax2"]=61466,["asrax3"]=61481,["audio4_first_done"]=497,["audio4_second_done"]=497,["background_done"]=98722,["booleq"]=61706,["boolge"]=61723,["boolgt"]=61721,["boolle"]=61713,["boollt"]=61715,["boolne"]=61700,["booluge"]=61739,["boolugt"]=61737,["boolule"]=61729,["boolult"]=61731,["bullet_render4"]=99584,["c_sp"]=66,["clip_left_found"]=1358,["decsp1"]=61501,["decsp2"]=61510,["decsp3"]=61523,["decsp4"]=61536,["decsp5"]=61549,["dispatch_nonzero"]=98752,["dma_chunk_ready"]=679,["dma_finished"]=840,["dma_started"]=761,["fast_base_ready"]=35596,["fast_fail"]=35629,["fast_tiles"]=35566,["fx4_build_skip"]=58368,["fx4_desc_count"]=58380,["fx4_dma_bytes"]=58376,["fx4_generation"]=58374,["fx4_half_bytes"]=58378,["fx4_page"]=58372,["fx4_wait_obj_blank"]=886,["fx_add_next_bounds"]=14305,["fx_audio_init"]=37268,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=37319,["fx_audio_sent"]=5653,["fx_build_obj"]=1638,["fx_commit_dma"]=14305,["fx_dma_bytes"]=59204,["fx_dma_count"]=59202,["fx_dma_desc"]=59206,["fx_em1_open_sizes"]=58639,["fx_emit_native"]=15843,["fx_is_obj"]=1590,["fx_latch_obj"]=1986,["fx_obj_build_done"]=1984,["fx_obj_count"]=58938,["fx_obj_dma_bytes"]=58944,["fx_obj_next"]=58666,["fx_obj_overflow"]=58942,["fx_obj_present"]=58802,["fx_obj_present_count"]=58940,["fx_obj_upload_done"]=2191,["fx_plan_dma"]=14286,["fx_project16"]=29803,["fx_read_gsu_spans"]=14231,["fx_reset_next_bounds"]=14305,["fx_sky_colors"]=17006,["fx_sky_colors_end"]=17090,["fx_sky_pointer"]=58970,["fx_upload_ground"]=2609,["fx_upload_obj"]=2032,["game_started"]=0,["generic"]=99536,["ground_done"]=2562,["ground_empty"]=2703,["gsu_uv_cache"]=99207,["half_dma_finished"]=767,["incsp1"]=61629,["incsp2"]=61644,["incsp3"]=61658,["incsp4"]=61663,["incsp5"]=61668,["incsp6"]=61673,["incsp7"]=61678,["incsp8"]=61683,["initialized"]=1351,["integer_render4"]=100384,["invoke_row"]=1402,["keys"]=58538,["ldaidx"]=61688,["logic_finished"]=485,["margin_render"]=99600,["math4_lift_result"]=984,["memcpy_getparams"]=61785,["memcpy_upwards"]=61747,["mulax10"]=61804,["mulax3"]=61829,["mulax5"]=61846,["mulax6"]=61866,["mulax7"]=61888,["negax"]=61917,["nmi_game"]=33430,["order"]=58410,["packet_done"]=1438,["packet_work"]=6,["player4_present"]=58948,["player4_upload_bytes"]=58952,["popax"]=61636,["popptr1"]=61931,["popsargsudiv16"]=62021,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=61967,["pusha"]=61949,["pusha0"]=61969,["pusha0sp"]=61945,["pushax"]=61971,["pushaysp"]=61947,["pushw0sp"]=61993,["pushwysp"]=61995,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=493,["render_second_finished"]=493,["render_second_started"]=493,["render_started"]=473,["render_stop"]=99754,["reset"]=32768,["row_done"]=1465,["sa1_clear_done"]=651,["sa1_clear_start"]=551,["sa1_compact"]=36067,["sa1_cover_row"]=35320,["sa1_dirty_done"]=555,["sa1_draw_done"]=1489,["sa1_draw_rows"]=35631,["sa1_draw_start"]=670,["sa1_edge_prepare"]=35813,["sa1_edge_restore"]=35991,["sa1_edge_save"]=35891,["sa1_entry"]=512,["sa1_find_shape"]=35084,["sa1_native_done"]=1489,["sa1_near_row"]=36227,["sa1_plan_dirty"]=33791,["sa1_prepare_transfer"]=34362,["sa1_select_cover"]=35170,["sa1_sort_packet"]=993,["sa1_tile_masks"]=34517,["sa1_tiles_clear"]=34649,["sa1_tiles_transfer"]=34664,["sa1_try_fast"]=35407,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=61414,["shlax3"]=61425,["shlax4"]=61439,["shrax1"]=62053,["shrax3"]=62061,["shrax4"]=62075,["sorted"]=1417,["sreg"]=68,["stage_update_done"]=61141,["staspidx"]=62092,["stax0sp"]=62114,["staxspidx"]=62125,["staxysp"]=62116,["subysp"]=62173,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=61355,["tosaddax"]=61357,["tosdiva0"]=61562,["tosdivax"]=61564,["tosicmp"]=61585,["tosicmp0"]=61583,["tossuba0"]=62152,["tossubax"]=62154,["tosudiva0"]=62186,["tosudivax"]=62188,["tosumoda0"]=62265,["tosumodax"]=62267,["transfer_chunk"]=581,["udiv16"]=62203,["L1"]=62237,["@L1"]=62255,["Pos"]=61580,["@L3"]=61621,["@L4"]=61622,["@L2"]=62259,["L0"]=62213,["ret0"]=61702,["ret1"]=61708,["L3"]=61774,["done"]=61782,["L2"]=62046,["@L0"]=62244,["udiv16by8a"]=62244}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/bands"
local maxframe=1800
local targetPresents=470
local scenario="bands"
local padded=false
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={16687},["_monosh_combat_fast_frame"]={17080},["_monosh_combat_render"]={17087},["_monosh_enemy_frame"]={17135},["_monosh_stage_frame"]={17157},["_monosh_boss_frame"]={17249},["_monosh_boss_prepare_render"]={17266},["_monosh_boss_render_only"]={17271,17290},["_fx_build_packet"]={17437},["_fx_build_ground"]={17440}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,0x7f0000+site,0x7f0000+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,0x7f0000+site+3,0x7f0000+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local a=labels[name]+(cpu==emu.cpuType.snes and 0x7f0000 or 0)
 emu.addMemoryCallback(fn,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if labels.sa1_sort_packet then
 cb('sa1_sort_packet',function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability')end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 if scenario=='boss' then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
cb('dma_finished',function()
 presents=presents+1
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  if padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  for _,a in ipairs({0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page})do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
