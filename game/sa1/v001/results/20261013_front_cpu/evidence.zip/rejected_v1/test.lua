local labels={["LoadAudioData"]=64112,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64715,["Tad_GetSong"]=64819,["Tad_GlobalVolumesPersist"]=64847,["Tad_GlobalVolumesResetOnSongStart"]=64841,["Tad_Init"]=64331,["Tad_IsLoaderActive"]=64873,["Tad_IsSfxPlaying"]=64887,["Tad_IsSongLoaded"]=64881,["Tad_IsSongPlaying"]=64893,["Tad_LoadSong"]=64774,["Tad_LoadSongIfChanged"]=64807,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=64458,["Tad_QueueCommand"]=64731,["Tad_QueueCommandOverride"]=64736,["Tad_QueuePannedSoundEffect"]=64753,["Tad_QueueSoundEffect"]=64763,["Tad_ReloadCommonAudioData"]=64823,["Tad_SetTransferSize"]=64853,["Tad_SongsStartImmediately"]=64829,["Tad_SongsStartPaused"]=64835,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=81,["Tad_sfxQueue_sfx"]=80,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5949,["__BULLETJIT_LOAD__"]=98304,["__BULLETJIT_RUN__"]=768,["__BULLETJIT_SIZE__"]=416,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65381,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=12168,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__LEFTJIT_LOAD__"]=98720,["__LEFTJIT_RUN__"]=768,["__LEFTJIT_SIZE__"]=373,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=65145,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=214,["__STARTUP__"]=1,["_abs"]=65012,["_boss_age"]=40453,["_boss_attribute_cache"]=40288,["_boss_attribute_cache_count"]=40450,["_boss_attribute_z_cache"]=40432,["_boss_dda_phase"]=40671,["_boss_dda_x"]=40677,["_boss_dda_y"]=40683,["_boss_death_parts"]=40455,["_boss_death_timer"]=40454,["_boss_fire_gap"]=40464,["_boss_fire_round"]=40461,["_boss_fire_shots"]=40463,["_boss_fire_state"]=40460,["_boss_fire_volley"]=40462,["_boss_history_x"]=39904,["_boss_history_y"]=40032,["_boss_history_z"]=40160,["_boss_last_vblank"]=39840,["_boss_motion_steps"]=40459,["_boss_part_active"]=39868,["_boss_part_bottom"]=39850,["_boss_part_fall_fraction"]=39895,["_boss_part_fall_velocity"]=39886,["_boss_part_timer"]=39877,["_boss_part_x"]=39841,["_boss_part_z"]=39859,["_boss_path_half"]=40458,["_boss_player_bottom"]=40467,["_boss_player_x"]=40465,["_boss_render_camera_delta"]=40451,["_boss_restart_timer"]=40456,["_boss_z_phase"]=40457,["_death_accel_fraction"]=40705,["_death_timer"]=40703,["_death_vy"]=40702,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=3162,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=15767,["_fx_boss_project"]=16341,["_fx_build_ground"]=4176,["_fx_build_packet"]=3248,["_fx_buttons"]=38062,["_fx_draw"]=36138,["_fx_draw_count"]=36778,["_fx_em0_geometry"]=18268,["_fx_enemy_collisions"]=17735,["_fx_enemy_em1_update"]=19487,["_fx_enemy_em1_update_reference"]=28156,["_fx_enemy_fire_em1"]=28094,["_fx_enemy_remove"]=28083,["_fx_enemy_render"]=18406,["_fx_enemy_render_bullets"]=18685,["_fx_far_d_acc"]=38074,["_fx_far_u_acc"]=38072,["_fx_fire_actions"]=38065,["_fx_frame"]=19781,["_fx_ground_c1ptr"]=39830,["_fx_ground_c3ptr"]=39832,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38081,["_fx_ground_color3"]=38531,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39796,["_fx_ground_far_xptr"]=39826,["_fx_ground_far_y"]=39836,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39834,["_fx_ground_horizontal"]=38981,["_fx_ground_hptr"]=39791,["_fx_ground_native"]=4264,["_fx_ground_palette_record"]=39794,["_fx_ground_phase"]=38061,["_fx_ground_vptr"]=39828,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39793,["_fx_init"]=20544,["_fx_input"]=38064,["_fx_open_size"]=61695,["_fx_packet"]=36781,["_fx_packet_count"]=36779,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=63558,["_fx_stage_render"]=62848,["_fx_stage_update"]=63889,["_fx_submit"]=64242,["_ground_irq_vblank_count"]=38069,["_history_head"]=40452,["_hit_pending"]=38076,["_intro_timer"]=40706,["_legacy_enemy_fire_boss_at"]=26688,["_main"]=20581,["_memcpy"]=64843,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59792,["_monosh_boss_draw_order_mid"]=61952,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=20770,["_monosh_boss_hp"]=39839,["_monosh_boss_init"]=20613,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=22669,["_monosh_boss_prepare_render"]=20806,["_monosh_boss_render_only"]=16121,["_monosh_boss_should_restart"]=20592,["_monosh_boss_state"]=39838,["_monosh_bullet_reflect_rng"]=40509,["_monosh_collision_bullet_bands"]=40501,["_monosh_combat_build_collision_bands"]=22851,["_monosh_combat_fast_cache_reset"]=17320,["_monosh_combat_fast_frame"]=16536,["_monosh_combat_fast_render"]=16666,["_monosh_combat_fast_render_cached"]=17327,["_monosh_combat_fire_cooldown"]=40510,["_monosh_combat_half_frame"]=40511,["_monosh_combat_init"]=22695,["_monosh_combat_reflect_bullet"]=16965,["_monosh_combat_render"]=22848,["_monosh_combat_update"]=22790,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40666,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40515,["_monosh_enemy_active_count"]=23611,["_monosh_enemy_active_count_value"]=40513,["_monosh_enemy_bullet_count"]=40512,["_monosh_enemy_bullets"]=40595,["_monosh_enemy_camera_delta_cached"]=40664,["_monosh_enemy_collision_cursor"]=40669,["_monosh_enemy_draw_cache_valid"]=40667,["_monosh_enemy_em1_count"]=40665,["_monosh_enemy_em1_phase"]=40640,["_monosh_enemy_em1_shrink"]=40656,["_monosh_enemy_fast_advance"]=19079,["_monosh_enemy_fast_check_player_bullets"]=24701,["_monosh_enemy_fast_render"]=24186,["_monosh_enemy_fast_render_bullets"]=25651,["_monosh_enemy_fast_spawn_due"]=26027,["_monosh_enemy_fast_update_bullets"]=17405,["_monosh_enemy_fire_at"]=23623,["_monosh_enemy_fire_boss_at"]=23652,["_monosh_enemy_fire_em0_fast"]=27086,["_monosh_enemy_frame"]=23414,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40668,["_monosh_enemy_init"]=23265,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40670,["_monosh_enemy_render_only"]=23444,["_monosh_enemy_spawn_index"]=40637,["_monosh_enemy_spawn_wait"]=40638,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=23617,["_monosh_enemy_stage_complete_flag"]=40514,["_monosh_ground_depth_pointer"]=38079,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40693,["_monosh_player_bullet_count"]=40484,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40469,["_monosh_player_can_fire"]=29914,["_monosh_player_draw_asset"]=29930,["_monosh_player_draw_flags"]=29872,["_monosh_player_init"]=29809,["_monosh_player_invuln"]=40696,["_monosh_player_pose"]=40698,["_monosh_player_state"]=40695,["_monosh_player_stumble"]=40697,["_monosh_player_update"]=32262,["_monosh_player_update_reference"]=31139,["_monosh_player_world_active"]=29908,["_monosh_player_x"]=40691,["_monosh_project_x"]=32872,["_monosh_reflected_bullet_count"]=40500,["_monosh_reflected_bullets"]=40485,["_monosh_runtime_fire_actions"]=38066,["_monosh_runtime_frame_counter"]=38067,["_monosh_runtime_paused"]=38071,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40945,["_monosh_stage_collision_bullet_index"]=40946,["_monosh_stage_contact_result"]=40943,["_monosh_stage_draw_cache_valid"]=40944,["_monosh_stage_frame"]=31414,["_monosh_stage_frame_counter"]=40807,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40811,["_monosh_stage_hitbox_count"]=40941,["_monosh_stage_hitboxes"]=40813,["_monosh_stage_init"]=31379,["_monosh_stage_is_clear"]=31463,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40812,["_monosh_stage_need_hitboxes"]=40942,["_monosh_stage_object_count"]=40805,["_monosh_stage_objects"]=40709,["_monosh_stage_render_only"]=31460,["_monosh_stage_spawn_index"]=40806,["_monosh_stage_spawn_wait"]=40809,["_monosh_stage_title_timer"]=40699,["_monosh_title_draw"]=20570,["_monosh_title_visible"]=34997,["_movement_fraction"]=40704,["_old_buttons"]=38077,["_player_flip"]=40707,["_player_fy"]=40700,["_player_run_phase"]=40708,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=17321,["addeq0sp"]=64482,["addeqysp"]=64484,["addysp"]=64500,["addysp1"]=64499,["aslax2"]=64513,["aslax3"]=64524,["aslax4"]=64538,["asrax1"]=64555,["asrax2"]=64565,["asrax3"]=64580,["audio4_first_done"]=828,["audio4_second_done"]=828,["background_done"]=112482,["blank_table"]=3149,["booleq"]=64805,["boolge"]=64822,["boolgt"]=64820,["boolle"]=64812,["boollt"]=64814,["boolne"]=64799,["booluge"]=64838,["boolugt"]=64836,["boolule"]=64828,["boolult"]=64830,["bullet_render4"]=113344,["c_sp"]=102,["clip_left_found"]=34353,["compact_ppu_boot"]=100278,["decsp1"]=64600,["decsp2"]=64609,["decsp3"]=64622,["decsp4"]=64635,["decsp5"]=64648,["dispatch_nonzero"]=112512,["dma_chunk_ready"]=1333,["dma_finished"]=2616,["dma_started"]=1533,["edge_restore_completed"]=37093,["edge_save_completed"]=36941,["fast_base_ready"]=36826,["fast_fail"]=36875,["fast_tiles"]=36793,["fp_bytes"]=64,["fp_cost"]=76,["fp_count"]=62,["fp_current"]=52456,["fp_descriptors"]=52648,["fp_gap"]=70,["fp_generation"]=74,["fp_prefix"]=52936,["fp_previous"]=52552,["fp_probe_begin"]=111671,["fp_probe_masks"]=111761,["fp_probe_ready"]=111936,["fp_probe_return"]=111955,["fp_source_base"]=72,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=3141,["fx_add_next_bounds"]=17404,["fx_audio_init"]=64899,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64950,["fx_audio_sent"]=5653,["fx_build_obj"]=3614,["fx_commit_dma"]=17404,["fx_dma_bytes"]=36008,["fx_dma_count"]=36006,["fx_dma_desc"]=36010,["fx_em1_open_sizes"]=61738,["fx_emit_native"]=18942,["fx_is_obj"]=3566,["fx_latch_obj"]=3962,["fx_obj_build_done"]=3960,["fx_obj_count"]=35646,["fx_obj_dma_bytes"]=35652,["fx_obj_next"]=35374,["fx_obj_overflow"]=35650,["fx_obj_present"]=35510,["fx_obj_present_count"]=35648,["fx_obj_upload_done"]=4174,["fx_plan_dma"]=17385,["fx_project16"]=32902,["fx_read_gsu_spans"]=17330,["fx_reset_next_bounds"]=17404,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35678,["fx_upload_ground"]=4534,["fx_upload_obj"]=4008,["game_started"]=0,["generic"]=113296,["ground_done"]=4487,["ground_empty"]=4628,["gsu_uv_cache"]=112967,["half_dma_finished"]=1539,["idle_clear_dma"]=103009,["idle_clear_done"]=103065,["incsp1"]=64728,["incsp2"]=64743,["incsp3"]=64757,["incsp4"]=64762,["incsp5"]=64767,["incsp6"]=64772,["incsp7"]=64777,["incsp8"]=64782,["initialized"]=3316,["integer_render4"]=114144,["invoke_row"]=34397,["irq_game"]=33469,["keys"]=35246,["ldaidx"]=64787,["left_hint_finished"]=1138,["logic_finished"]=805,["margin_render"]=113360,["math4_lift_result"]=3239,["memcpy_getparams"]=64884,["memcpy_upwards"]=64846,["mulax10"]=64903,["mulax3"]=64928,["mulax5"]=64945,["mulax6"]=64965,["mulax7"]=64987,["negax"]=65016,["nmi_game"]=33505,["order"]=35118,["p3Complete"]=2969,["p3Flip"]=3039,["packet_done"]=3414,["packet_work"]=9,["pfBase"]=35796,["pfBytes"]=35792,["pfDesc"]=35794,["pfHigh"]=35806,["pfLimit"]=35810,["pfLow"]=35804,["pfMid"]=35808,["pfPartial"]=35790,["pfTables"]=50408,["pf_found"]=15707,["pf_full_check"]=15497,["pf_search"]=15535,["pipe_actual_blank"]=1729,["pipe_available"]=35096,["pipe_budget_lines"]=99254,["pipe_bw_busy"]=35046,["pipe_choose_target"]=1133,["pipe_collect"]=871,["pipe_complete"]=35042,["pipe_descriptor"]=1404,["pipe_dma_chunk"]=35106,["pipe_dma_measured_end"]=1560,["pipe_fast_begin"]=1990,["pipe_fast_done"]=2426,["pipe_fast_empty"]=2432,["pipe_fast_group"]=2027,["pipe_fast_groups_done"]=2415,["pipe_fast_partial_done"]=3080,["pipe_fast_unavailable"]=2434,["pipe_flip"]=2436,["pipe_front_slot"]=35036,["pipe_full_descriptor"]=1493,["pipe_ground_extra"]=45068,["pipe_ground_extra_end"]=47968,["pipe_ground_wait"]=844,["pipe_irq"]=1054,["pipe_irq_checked"]=1668,["pipe_irq_done"]=1660,["pipe_irq_exit"]=1691,["pipe_irq_transfer"]=1076,["pipe_main_offset"]=35088,["pipe_missed"]=35078,["pipe_near_build"]=14749,["pipe_near_prepare_next"]=14643,["pipe_near_prepared"]=35788,["pipe_near_present"]=35786,["pipe_near_select"]=15086,["pipe_next_slot"]=35090,["pipe_no_time"]=1898,["pipe_obj_pointer"]=35102,["pipe_pending"]=35040,["pipe_prefix_plan"]=15305,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_reserved"]=1892,["pipe_set_chunk"]=1496,["pipe_setup_transfer"]=1259,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_time_left"]=1737,["pipe_transfer_complete"]=1609,["pipe_transfer_pause"]=1650,["pipe_wait_dma"]=1112,["pipe_write_slot"]=35030,["player4_next"]=35654,["player4_present"]=35656,["player4_upload_bytes"]=35660,["player4_uploaded"]=35658,["popax"]=64735,["popptr1"]=65030,["popsargsudiv16"]=65120,["prefetch_finished"]=1639,["ptr1"]=110,["ptr2"]=112,["ptr3"]=114,["ptr4"]=116,["push0"]=65066,["pusha"]=65048,["pusha0"]=65068,["pusha0sp"]=65044,["pushax"]=65070,["pushaysp"]=65046,["pushw0sp"]=65092,["pushwysp"]=65094,["regbank"]=122,["regsave"]=106,["render_entry"]=112064,["render_finished"]=824,["render_second_finished"]=824,["render_second_started"]=824,["render_started"]=778,["render_stop"]=113514,["reset"]=32768,["restore_jit_ready"]=59247,["row_done"]=34461,["sa1_background_cache"]=58257,["sa1_background_initialize"]=58575,["sa1_bullet_cache_init"]=101844,["sa1_bullet_cache_prepare"]=101845,["sa1_clear_done"]=702,["sa1_clear_start"]=530,["sa1_clear_wide_band"]=59256,["sa1_compact"]=37484,["sa1_cover_row"]=36503,["sa1_deep_rebase"]=57904,["sa1_dirty_done"]=553,["sa1_dirty_row_rect"]=35673,["sa1_dirty_rows"]=57939,["sa1_dma_begin"]=57055,["sa1_dma_end"]=57091,["sa1_dma_irq"]=57336,["sa1_dma_poll"]=57102,["sa1_dma_try_begin"]=57021,["sa1_draw_done"]=34485,["sa1_draw_rows"]=36877,["sa1_draw_start"]=721,["sa1_edge_cpu_restore"]=58970,["sa1_edge_cpu_save"]=58926,["sa1_edge_prepare"]=37142,["sa1_edge_restore"]=37367,["sa1_edge_save"]=37224,["sa1_entry"]=512,["sa1_fb_read"]=57324,["sa1_fb_write"]=57330,["sa1_find_shape"]=36244,["sa1_ground_compiled"]=15259,["sa1_idle_clear"]=102847,["sa1_left_hint_draw"]=103413,["sa1_list_sort"]=15109,["sa1_merge_dma"]=59639,["sa1_native_done"]=34485,["sa1_near_patch"]=58784,["sa1_near_patch_bounds"]=58698,["sa1_near_row"]=37644,["sa1_occupancy_capture"]=57388,["sa1_output_done"]=34501,["sa1_plan_dirty"]=34903,["sa1_prepare_transfer"]=35570,["sa1_select_cover"]=36353,["sa1_small_edge_load"]=59100,["sa1_small_edge_prepare"]=59040,["sa1_small_edge_restore"]=59228,["sa1_small_edge_save"]=59200,["sa1_snapshot"]=57159,["sa1_sparse_direct_finish"]=103081,["sa1_sparse_map_prepare"]=103080,["sa1_sprite_begin"]=33587,["sa1_sprite_done"]=34472,["sa1_stack_clear_band"]=59318,["sa1_stack_clear_line"]=59493,["sa1_stack_clear_prepare"]=59301,["sa1_tile_masks"]=35677,["sa1_tiles_clear"]=35809,["sa1_tiles_transfer"]=35824,["sa1_transfer_mask_capture"]=57621,["sa1_transfer_mask_prepare"]=57688,["sa1_try_fast"]=36590,["save_jit_ready"]=59219,["scaled_render4"]=113872,["scaled_unpacked4"]=114032,["sd_collect_costs"]=103187,["shlax2"]=64513,["shlax3"]=64524,["shlax4"]=64538,["shrax1"]=65152,["shrax3"]=65160,["shrax4"]=65174,["small_prepare_cpu"]=59157,["small_prepare_done"]=59199,["sorted"]=3393,["sparse_direct_overflow"]=103186,["sreg"]=104,["stage_update_done"]=64240,["staspidx"]=65191,["stax0sp"]=65213,["staxspidx"]=65224,["staxysp"]=65215,["subysp"]=65272,["tm_first"]=100369,["tm_length"]=100881,["tm_rest"]=101393,["tmp1"]=118,["tmp2"]=119,["tmp3"]=120,["tmp4"]=121,["tosadda0"]=64454,["tosaddax"]=64456,["tosdiva0"]=64661,["tosdivax"]=64663,["tosicmp"]=64684,["tosicmp0"]=64682,["tossuba0"]=65251,["tossubax"]=65253,["tosudiva0"]=65285,["tosudivax"]=65287,["tosumoda0"]=65364,["tosumodax"]=65366,["transfer_chunk"]=1333,["udiv16"]=65302,["L1"]=65336,["@L1"]=65354,["Pos"]=64679,["@L3"]=64720,["@L4"]=64721,["@L2"]=65358,["L0"]=65312,["ret0"]=64801,["ret1"]=64807,["L3"]=64873,["done"]=64881,["L2"]=65145,["@L0"]=65343,["udiv16by8a"]=65343}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/movestress_detinput_captureburst_frontprobe_cpu_tracepalette_tracebounds_tracedeadline"
local maxframe=800
local targetPresents=0
local scenario="movestress_detinput_captureburst_frontprobe_cpu_tracepalette_tracebounds_tracedeadline"
local exactMaskBounds=false
local splitFixtures={}
local function captureGeneration(g)
 return scenario:match('^transferfixture') or scenario:match('^splitfixture') or scenario:match('^opaquefixture') or scenario:match('^clipfixture') or scenario:match('^stackfixture') or scenario:match('^leftfixtureindexed') or scenario:match('^leftfixtureexplosion') or scenario:match('^leftfixtureflame') or g<=120 or g%60==0 or (scenario:match('captureburst') and g>=530 and g<=570)
end
local padded=false
local pipeline=true
local vramPrefetch3=true
local vramFourShared=false
local vramFifo=false
local vramFourOwned=false
local fixedMap=true
local prebankDma=false
local dmaShortIo=false
local prefixRefreshSixteenth=false
local splitViewports=false
local fixedMapDelta=false
local fixedMapDeltaDma=false
local packetOffload=false
local packetIramArrays=false
local packetRunning=false
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local finishedCapture=false
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local pageCommit=nil
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuActiveParts,cpuActiveEntries={},{}
local irqTicks,irqClock,irqDepth=0,0,0
local activeBegin=0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local boundsFrames=scenario:match('tracebounds') and assert(io.open(output..'/mask_bounds_frames.bin','wb')) or nil
local completedFrames={}
local expectedPalette={0,0,154,119,254,82,94,10,101,15,113,55,83,90,141,61,1,6,74,38,76,8,53,0,0,4,55,101,109,97,120,45}
if scenario:match('tracepalette') then
 local z=assert(io.open(output..'/palette_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  if field>90 then
   local s=emu.getState()
   z:write(string.format('{"field":%d,"line":%d,"hclock":%d,"address":%d,"value":%d,"cgadd":%d,"pc":%d}\n',field,s['ppu.scanline'],s['memoryManager.hClock'],address,value,s['ppu.cgramAddress'],s['cpu.pc']));z:flush()
  end
 end,emu.callbackType.write,32,63,emu.cpuType.snes,emu.memType.snesCgRam)
end
if scenario:match('tracedma') then
 local z=assert(io.open(output..'/sa1_dma_writes.jsonl','w'))
 local blankLog=assert(io.open(output..'/blank_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local st=emu.getState()
  blankLog:write(string.format('{"field":%d,"line":%d,"value":%d,"pc":%d,"hdmaAddress":%d,"hdmaCount":%d}\n',field,st['ppu.scanline'],value,st['cpu.pc'],st['dmaController.channel[1].hdmaTableAddress'],st['dmaController.channel[1].hdmaLineCounterAndRepeat']));blankLog:flush()
 end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
 local reads=assert(io.open(output..'/cpu_dma_reads.jsonl','w'));local readCount=0
 emu.addMemoryCallback(function(address,value)
  if presents==0 and emu.read16(0x311e,emu.memType.snesMemory)==1 and readCount<800 then
   readCount=readCount+1;local s=emu.getState()
   reads:write(string.format('{"address":%d,"value":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',address,value,s['cart.coprocessor.dmaSrcAddr'],s['cart.coprocessor.dmaDestAddr'],tostring(s['cart.coprocessor.charConvDmaActive']),tostring(s['ppu.forcedBlank']),s['ppu.scanline']));reads:flush()
  end
 end,emu.callbackType.read,0x400000,0x43ffff,emu.cpuType.snes,emu.memType.snesMemory)
 emu.addMemoryCallback(function(address,value)
  if emu.read16(0x11e,emu.memType.sa1Memory)==1 then
   local s=emu.getState()
   z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,emu.memType.sa1Memory),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
  end
 end,emu.callbackType.write,0x2230,0x2239,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local cpuStageJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write16(4194304+labels[name],value,emu.memType.snesMemory)end
end
for name,sites in pairs({["_fx_read_input"]={19786},["_monosh_combat_fast_frame"]={20179},["_monosh_combat_render"]={20186},["_monosh_enemy_frame"]={20234},["_monosh_stage_frame"]={20256},["_monosh_boss_frame"]={20348},["_monosh_boss_prepare_render"]={20365},["_monosh_boss_render_only"]={20370,20389},["_fx_build_packet"]={20536},["_fx_build_ground"]={20539}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock;cpuActiveEntries[name]=activeClock() end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()
   cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272
   cpuActiveParts[name]=(cpuActiveParts[name] or 0)+(activeClock()-cpuActiveEntries[name])/21477.272
   if name=='_fx_read_input' and scenario:match('detinput') then
    local phase=logic%240
    local value=0x80
    if scenario:match('move') then
     value=value+(phase<60 and 0x100 or phase<120 and 0x800 or phase<180 and 0x200 or 0x400)
    end
    emu.write16(0x7e0000+labels._fx_buttons,value,emu.memType.snesMemory)
   end
  end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write(4194304+labels[name],value,emu.memType.snesMemory)end
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local gameHook=false and (name=='_fx_build_packet' or name=='initialized' or name=='sorted' or name=='packet_done' or name=='sa1_list_sort')
 local packetHook=packetOffload and (name=='initialized' or name=='sorted' or name=='packet_done' or name=='sa1_list_sort')
 if gameHook or packetHook then cpu=emu.cpuType.sa1 end
 if packetHook then local run=fn;fn=function()if packetRunning then run()end end end
 local irqName=name:match('^pipe_') or name=='p3PumpBlank' or name=='p3Complete' or name=='p3Flip' or name=='stage_time_ok' or name=='stage_converted' or name=='stage_too_large' or name=='fx_obj_upload_done' or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local frontProbeHook=name:match('^fp_probe')
 local a=labels[name]+(frontProbeHook and 0x800000 or packetHook and 0 or gameHook and 0xc10000 or cpu==emu.cpuType.snes and labels[name]<65536 and (irqName and 12648448 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()if finishedCapture then return end;local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if labels.fp_probe_begin then
 local f=assert(io.open(output..'/fixed_front_probe.jsonl','w'))
 local begin,masksClock,readyClock,entry,result=nil,0,0,nil,nil
 local previous={};for i=0,95 do previous[i]=0 end
 local current=nil;local lastGeneration=0
 cb('fp_probe_begin',function()
  local s=emu.getState();assert(not begin,'nested front probe')
  begin=s.masterClock;entry={a=s['cpu.a'],x=s['cpu.x'],y=s['cpu.y'],d=s['cpu.d'],db=s['cpu.dbr'],sp=s['cpu.sp'],line=s['ppu.scanline'],irq=irqDepth>0 and 1 or 0}
 end)
 cb('fp_probe_masks',function()
  local mt=emu.memType.snesMemory;local b=0x7e0000
  assert(begin,'front masks before begin');masksClock=emu.getState().masterClock
  local gen=emu.read16(labels.fp_generation,mt)
  assert(gen==lastGeneration+1,'front probe skipped or repeated a generation')
  current={}
  for i=0,95 do
   current[i]=emu.read(b+labels.fp_current+i,mt)
   assert(current[i]==emu.read(0x432800+i,mt),'front probe copied wrong current mask')
   assert(emu.read(b+labels.fp_previous+i,mt)==previous[i],'front probe previous mask changed')
  end
 end)
 cb('fp_probe_ready',function()
  local mt=emu.memType.snesMemory;local b=0x7e0000;local gap=1;local runs
  assert(begin and current,'front probe ready before mask copy')
  readyClock=emu.getState().masterClock
  repeat
   runs={}
   for tile=32,767 do
    if ((current[tile//8]|previous[tile//8])>>(tile%8))&1~=0 then
     local start=tile*32;local finish=start+32
     if #runs>0 and start-runs[#runs][2]<gap then runs[#runs][2]=finish
     else runs[#runs+1]={start,finish}end
    end
   end
   if #runs>48 then gap=gap+64 end
  until #runs<=48
  assert(emu.read16(labels.fp_count,mt)==#runs and emu.read16(labels.fp_gap,mt)==gap,'front probe run count/gap differs')
  local bytes,cost=0,0;local base=emu.read16(labels.fp_source_base,mt)
  for i,r in ipairs(runs)do
   local length=r[2]-r[1];local a=b+labels.fp_descriptors+(i-1)*6
   assert(emu.read16(a,mt)==length and emu.read16(a+2,mt)==r[1]+base and emu.read16(a+4,mt)==r[1]//2-496,'front probe descriptor differs')
   bytes=bytes+length;cost=cost+length+length//32+length//128+57
   local p=b+labels.fp_prefix+(i-1)*4
   assert(emu.read16(p,mt)==bytes and emu.read16(p+2,mt)==cost,'front probe cumulative prefix differs')
  end
  assert(emu.read16(labels.fp_bytes,mt)==bytes and emu.read16(labels.fp_cost,mt)==cost,'front probe totals differ')
  result={gen=emu.read16(labels.fp_generation,mt),bytes=bytes,cost=cost,count=#runs,gap=gap}
 end)
 cb('fp_probe_return',function()
  local s=emu.getState();assert(begin and result,'front probe returned before verification')
  assert(s['cpu.a']==entry.a and s['cpu.x']==entry.x and s['cpu.y']==entry.y and s['cpu.d']==entry.d and s['cpu.dbr']==entry.db and s['cpu.sp']==entry.sp,'front probe did not restore CPU registers/stack')
  local mt=emu.memType.snesMemory
  for i=0,95 do assert(emu.read(0x7e0000+labels.fp_previous+i,mt)==current[i],'front probe did not remember current mask')end
  f:write(string.format('{"generation":%d,"field":%d,"irq":%d,"bytes":%d,"cost":%d,"count":%d,"gap":%d,"beginLine":%d,"endLine":%d,"totalMs":%.6f,"copyMs":%.6f,"planningMs":%.6f,"rememberMs":%.6f}\n',result.gen,field,entry.irq,result.bytes,result.cost,result.count,result.gap,entry.line,s['ppu.scanline'],(s.masterClock-begin)/21477.272,(masksClock-begin)/21477.272,(readyClock-masksClock)/21477.272,(s.masterClock-readyClock)/21477.272));f:flush()
  previous=current;current=nil;lastGeneration=result.gen;result=nil;begin=nil
 end)
end
if scenario:match('tracebounds') then
 local f=assert(io.open(output..'/mask_bounds_trace.bin','wb'))
 cb('sa1_occupancy_capture',function()
  local mt=emu.memType.sa1Memory
  local data={}
  local function append16(v)data[#data+1]=string.char(v%256,math.floor(v/256)%256)end
  append16(emu.read16(0x198,mt))
  for i=0,95 do data[#data+1]=string.char(emu.read(0x432800+i,mt))end
  for band=0,23 do
   local first,last=128,0
   for bit=0,31 do
    local b=emu.read(0x432800+band*4+math.floor(bit/8),mt)
    if math.floor(b/2^(bit%8))%2==1 then first=math.min(first,bit*4);last=(bit+1)*4 end
   end
   local left=emu.read16(0x120+band*4,mt);local right=emu.read16(0x122+band*4,mt)
   local exact=left==first and right==last
   assert(exact or (not exactMaskBounds and ((last==0 and left>=right) or (last>0 and left<=first and right>=last))),string.format('mask bounds job %d band %d: %d..%d expected %d..%d',emu.read16(0x198,mt),band,left,right,first,last))
   append16(left);append16(right)
  end
  f:write(table.concat(data));f:flush()
 end,emu.cpuType.sa1)
end
if scenario:match('traceedge') then
 local f=assert(io.open(output..'/edge_cache.jsonl','w'))
 local current=nil;local begin=0;local restoreBegin=0;local saved=0
 cb('sa1_edge_save',function()
  local mt=emu.memType.sa1Memory
  begin=emu.getState().masterClock;current=nil
  local width=emu.read16(0xc4,mt)
  if width>0 then
   local function s16(v)return v>=32768 and v-65536 or v end
   current={job=emu.read16(0x198,mt),field=field,asset=emu.read16(0x3e,mt),width=emu.read16(0x34,mt),height=emu.read16(0x36,mt),left=s16(emu.read16(0x38,mt)),top=s16(emu.read16(0x3a,mt)),flags=emu.read16(0x3c,mt),first=emu.read16(0xa0,mt),count=emu.read16(0xa8,mt),cacheWidth=width,saveConversionBusy=emu.read16(0x11e,mt)}
  end
 end,emu.cpuType.sa1)
 cb('edge_save_completed',function()
  if current then
   local mt=emu.memType.sa1Memory
   saved=emu.getState().masterClock;current.saveMs=(saved-begin)/21477.272
   current.cacheRows=emu.read16(0xca,mt);current.cacheFirst=emu.read16(0xc8,mt);current.cacheBytes=current.cacheWidth*current.cacheRows
   assert(current.cacheBytes<=1024,'edge guard exceeds IRAM cache')
   if current.cacheWidth<=12 then assert(current.cacheBytes<=512,'edge guard overwrites small JIT')end
  end
 end,emu.cpuType.sa1)
 cb('sa1_edge_restore',function()restoreBegin=emu.getState().masterClock;if current then current.restoreConversionBusy=emu.read16(0x11e,emu.memType.sa1Memory)end end,emu.cpuType.sa1)
 for _,kind in ipairs({'save','restore'})do
  for name,mode in pairs({sa1_small_edge_='jit',sa1_edge_cpu_='mvn'})do
   cb(name..kind,function()if current then current[kind..'Mode']=mode end end,emu.cpuType.sa1)
  end
 end
 cb('edge_restore_completed',function()
  if current then
   current.restoreMs=(emu.getState().masterClock-restoreBegin)/21477.272
   current.chunkDrawAndCodeMs=(restoreBegin-saved)/21477.272
   local parts={};for k,v in pairs(current)do parts[#parts+1]=string.format('"%s":%s',k,type(v)=='string' and string.format('%q',v) or tostring(v))end
   f:write('{',table.concat(parts,','),'}\n');f:flush();current=nil
  end
 end,emu.cpuType.sa1)
 if labels.sa1_small_edge_load then
  local jit=assert(io.open(output..'/edge_jit.jsonl','w'))
  local start=0;local cpu=false
  cb('sa1_small_edge_load',function()start=emu.getState().masterClock;cpu=false end,emu.cpuType.sa1)
  cb('small_prepare_cpu',function()cpu=true end,emu.cpuType.sa1)
  cb('small_prepare_done',function()
   if start>0 then
    local mt=emu.memType.sa1Memory
    jit:write(string.format('{"job":%d,"asset":%d,"cacheWidth":%d,"cpuCopy":%s,"ms":%.6f}\n',emu.read16(0x198,mt),emu.read16(0x3e,mt),emu.read16(0xc4,mt),tostring(cpu),(emu.getState().masterClock-start)/21477.272));jit:flush();start=0
   end
  end,emu.cpuType.sa1)
  if labels.save_jit_ready then
   local t=assert(io.open("D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/small_edge_templates.bin",'rb'));local original=t:read('*a');t:close()
   local uses=assert(io.open(output..'/edge_jit_uses.jsonl','w'))
   for _,kind in ipairs({'save','restore'})do
    cb(kind..'_jit_ready',function()
     local mt=emu.memType.sa1Memory
     local width=emu.read16(0xc4,mt);local bank=emu.read16(0x102,mt)&255
     assert(width>0 and width<=32 and width%2==0,'invalid small edge width')
     assert(emu.read16(0x1b0,mt)==(false and width or 1),'edge JIT used before lazy load')
     for i=0,511 do
      local expect=original:byte((width//2-1)*512+i+1)
      if (i>=7 and i<=127 and (i-7)%8==0) or (i>=266 and i<=386 and (i-266)%8==0) then expect=bank end
      assert(emu.read(0x500+i,mt)==expect,'edge JIT code/bank differs at '..i)
     end
     uses:write(string.format('{"job":%d,"kind":"%s","bank":%d,"cacheWidth":%d}\n',emu.read16(0x198,mt),kind,bank,width));uses:flush()
    end,emu.cpuType.sa1)
   end
  end
 end
 if labels.edge_band_chunk_ready then
  local bands={}
  local log=assert(io.open(output..'/edge_band.jsonl','w'))
  cb('edge_band_chunk_ready',function()
   local mt=emu.memType.sa1Memory
   if emu.read16(0x1b4,mt)>0 then
    local asset=emu.read16(0x3e,mt);local w=emu.read16(0x34,mt);local h=emu.read16(0x36,mt)
    local rows=assert(bands[asset..'_'..w..'_'..h],'band guard shape missing')
    local first=emu.read16(0xa0,mt);local count=emu.read16(0xa8,mt);local right=0
    for b=first//8+1,(first+count+7)//8 do right=math.max(right,rows[b])end
    local left=emu.read16(0x38,mt);local expected=right>0 and math.max(0,(right+left-255)//2) or 0
    expected=(expected+1)&0xfffe
    local actual=emu.read16(0xc4,mt);local old=emu.read16(0x1b2,mt)
    assert(actual==expected and actual<=old and old<=32,'band guard width differs from ROM alpha table')
    log:write(string.format('{"job":%d,"asset":%d,"width":%d,"height":%d,"left":%d,"top":%d,"first":%d,"count":%d,"oldWidth":%d,"newWidth":%d}\n',emu.read16(0x198,mt),asset,w,h,left,emu.read16(0x3a,mt),first,count,old,actual));log:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.clip_left_cache_hit then
 local log=assert(io.open(output..'/clip_cache.jsonl','w'))
 for _,name in ipairs({'clip_left_cache_hit','clip_left_cache_miss','clip_reverse_cache_hit','clip_reverse_cache_miss','clip_cache_edge_invalidate','clip_cache_bullet_invalidate'})do
  cb(name,function()
   local mt=emu.memType.sa1Memory
   log:write(string.format('{"event":"%s","field":%d,"job":%d,"tag":%d,"asset":%d}\n',name,field,#times+1,emu.read16(0x07fc,mt),emu.read16(0x3e,mt)));log:flush()
  end,emu.cpuType.sa1)
 end
end
if false then
 local log=assert(io.open(output..'/game_offload.jsonl','w'))
 local active=false;local begin=0
 cb('sa1_game_begin',function()active=true;begin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_game_end',function()
  active=false
  local mt=emu.memType.sa1Memory
  assert(emu.read16(0x435100+labels.c_sp,mt)==0x7c00,'game software stack did not balance')
  for i=0,62,2 do
   assert(emu.read16(0x437b00+i,mt)==0xa55a,'game software stack crossed scratch boundary')
   assert(emu.read16(0x437e00+i,mt)==0xa55a,'game hardware stack crossed software stack boundary')
  end
  log:write(string.format('{"field":%d,"logic":%d,"ms":%.6f}\n',field,logic,(emu.getState().masterClock-begin)/21477.272));log:flush()
 end,emu.cpuType.sa1)
 emu.addMemoryCallback(function()
  if active then local f=assert(io.open(output..'/failure.txt','w'));f:write('SA-1 game accessed S-CPU arithmetic registers');f:close();emu.stop(1)end
 end,emu.callbackType.write,0x4202,0x4206,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if labels.fallback_publish and scenario:match('tracefallback') then
 local f=assert(io.open(output..'/fallback_debug.jsonl','w'))
 cb('fallback_publish',function()
  local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt);local page=emu.read16(record+6,mt)*2
  local outside={}
  for tile=32,767 do
   local mask=emu.read(0x7e0000+labels.fbMasks+slot*128+math.floor(tile/8),mt)
   if (mask & (1<<(tile%8)))==0 then
    for b=0,31 do
     if emu.read(page+tile*32+b,emu.memType.snesVideoRam)~=0 then outside[#outside+1]=tile;break end
    end
   end
  end
  f:write(string.format('{"generation":%d,"page":%d,"outside":[%s]}\n',gen,page,table.concat(outside,',')));f:flush()
 end)
 if labels.sa1_fallback_build then cb('sa1_fallback_build',function()
  local s=emu.getState()
  f:write(string.format('{"field":%d,"sa1Stack":%d}\n',field,s['cart.coprocessor.cpu.sp'] or -1));f:flush()
 end,emu.cpuType.sa1)end
end
emu.addMemoryCallback(function(address,value)
 local line=emu.getState()['ppu.scanline']
 if field>85 and (line>=203 or line<21) and line<225 and (value&0x80)==0 then
  local f=assert(io.open(output..'/failure.txt','w'));f:write('HDMA unblanked reserved DMA lines field='..field..' line='..line..' value='..value);f:close()
  local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)
 end
end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
-- VRAM/OAM DMA�͎��ۂ�forced blank�܂���VBLANK���ɊJ�n����B
emu.addMemoryCallback(function(address,value)
 if field>90 and (value&1)~=0 then
  local bb=emu.read(0x4301,emu.memType.snesMemory)
  if bb==0x18 or bb==4 then
   local st=emu.getState()
   if emu.read16(0x4305,emu.memType.snesMemory)==0 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('zero-length VRAM/OAM DMA would transfer 65536 bytes field='..field);f:close();emu.stop(1)
   end
   if vramPrefetch3 and bb==0x18 then
    local first=(st['ppu.vramAddress']&0x7fff)*2
    local last=first+emu.read16(0x4305,emu.memType.snesMemory)
    local fixedOverlap=(first<1024 and last>0) or (first<0x4400 and last>0x4000)
    if vramFourShared then fixedOverlap=(first<0x9000 and last>0x8c00) or (first<0xc000 and last>0xbc00) end
    if vramFifo then
     local playerUpload=first==0xc800 and last==0xcb80 and emu.read(0x4304,emu.memType.snesMemory)==0xdf
     local mapUpload=first==0xc040 and last==0xc600
     fixedOverlap=not (playerUpload or mapUpload or (first>=0x20 and last<=0xbc20))
     if first<0xbc20 then
      for zero=0,0xa000,0x2000 do assert(not (first<zero+32 and last>zero),'FIFO overwrites reserved zero tile')end
     end
    end
    if vramFourOwned then
     local base=math.floor(first/0x3000)*0x3000
     local a=first-base;local b=last-base
     local playerUpload=first==0xc800 and last==0xcb80 and emu.read(0x4304,emu.memType.snesMemory)==0xdf
     fixedOverlap=not (playerUpload or (base<0xc000 and ((a>=0x20 and b<=0x2800) or (a>=0x2840 and b<=0x2e00) or (a>=0x2e00 and b<=0x3000))))
    end
    if fixedMap then
     local playerUpload=first==0xc800 and last==0xcb80 and emu.read(0x4304,emu.memType.snesMemory)==0xdf
     local mapUpload=fixedMapDelta and first==0xc040 and last==0xc600 and emu.read(0x4304,emu.memType.snesMemory)==0x7e
     if fixedMapDeltaDma and first>=0xc040 and last<=0xc600 and emu.read(0x4304,emu.memType.snesMemory)==1 then mapUpload=true end
     fixedOverlap=not (playerUpload or mapUpload or (first>=0x20 and last<=0x5c20) or (first>=0x6020 and last<=0xbc20))
    end
    if fixedOverlap then
     local f=assert(io.open(output..'/failure.txt','w'))
     f:write('frame DMA overwrites fixed BG2 CHR field='..field..' first='..first..' last='..last);f:close();emu.stop(1)
    end
   end
   if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('VRAM/OAM DMA started outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
   end
  end
 end
end,emu.callbackType.write,0x420b,0x420b,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(function(address,value)
 if field>90 then
  local st=emu.getState()
  if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write('BG1 page changed outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
  end
  pageCommit={field=field,line=st['ppu.scanline'],clock=st.masterClock}
 end
end,emu.callbackType.write,0x210b,0x210b,emu.cpuType.snes,emu.memType.snesMemory)
local packetClock=0
if pipeline then
 local function irqEntry()if irqDepth==0 then irqClock=emu.getState().masterClock end;irqDepth=irqDepth+1 end
 cb('pipe_irq',irqEntry)
 if labels.p3PumpBlank then cb('p3PumpBlank',irqEntry)end
 cb('pipe_irq_exit',function()irqDepth=irqDepth-1;assert(irqDepth>=0,'IRQ accounting underflow');if irqDepth==0 then irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end end)
 emu.addMemoryCallback(function(address,value)
  if irqDepth>0 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write(string.format('IRQ modified game math register $%04x at field %d',address,field));f:close()
   emu.stop(1)
  end
 end,emu.callbackType.write,0x4202,0x4206,emu.cpuType.snes,emu.memType.snesMemory)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
if packetOffload and labels.sa1_packet_finished then
 local packetLog=assert(io.open(output..'/packet_prepare.jsonl','w'))
 local packetBegin=0
 cb('sa1_packet_prepare',function()packetRunning=true;packetBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_packet_finished',function()
  packetLog:write(string.format('{"field":%d,"ms":%.6f,"inputCount":%d,"outputCount":%d}\n',field,(emu.getState().masterClock-packetBegin)/21477.272,emu.read16(0x431404,emu.memType.sa1Memory),emu.read16(0x431402,emu.memType.sa1Memory)));packetLog:flush()
  packetRunning=false
 end,emu.cpuType.sa1)
end
if not packetOffload then for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done','pipe_prefix_plan','pipe_fast_begin','pipe_fast_partial_done','pipe_collect','pipe_flip'})do
 if labels[name] then
  cb(name,function()
   if presents<10 or (scenario:match('timing') and field>=620 and field<=650) then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 end
 cb('prefetch_finished',function()
  if true then return end
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if captureGeneration(gen) then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 if scenario:match('tracedeadline') then
  local f=assert(io.open(output..'/transfer_deadline.jsonl','w'))
  local function log(name,extra)
   -- 197�sIRQ���d�������]������O���ߑ�����B
   if field<660 or field>720 then return end
   local s=emu.getState();local mt=emu.memType.snesMemory;local base=0x7e0000
   local offset=emu.read16(base+labels.pipe_record_offset,mt);local r=base+labels.pipe_records+offset
   local e={event=name,field=field,present=presents,clock=s.masterClock,line=s['ppu.scanline'],hclock=s['memoryManager.hClock'],a=s['cpu.a'],x=s['cpu.x'],d=s['cpu.d'],slot=emu.read16(base+labels.pipe_target_slot,mt),generation=emu.read16(r+8,mt),remaining=emu.read16(r+34,mt),cursor=emu.read16(r+4,mt),descriptors=emu.read16(r+2,mt),available=emu.read16(base+labels.pipe_available,mt),cost=emu.read16(base+labels.pipe_dma_chunk,mt),flipped=emu.read16(base+labels.pipe_presented_irq,mt),complete=emu.read16(base+labels.pipe_complete,mt),request=emu.read16(0x311e,mt),grant=emu.read16(0x311c,mt),blank=s['ppu.forcedBlank']}
   if extra then for k,v in pairs(extra)do e[k]=v end end
   local parts={};for k,v in pairs(e)do parts[#parts+1]=string.format('"%s":%s',k,type(v)=='string' and string.format('%q',v) or tostring(v))end
   f:write('{',table.concat(parts,','),'}\n');f:flush()
  end
  for _,name in ipairs({'pipe_irq_transfer','pipe_collect','pipe_wait_dma','pipe_choose_target','pipe_setup_transfer','pipe_time_left','pipe_reserved','pipe_no_time','pipe_prefix_plan','pipe_fast_begin','pipe_fast_group','pipe_fast_groups_done','pipe_fast_partial_done','pipe_fast_empty','pipe_fast_unavailable','pipe_descriptor','pipe_full_descriptor','pipe_set_chunk','pipe_transfer_complete','pipe_transfer_pause','pipe_flip','dma_finished','p3Complete','p3Flip','pipe_irq_checked'})do
   assert(labels[name],'missing deadline trace label '..name)
   cb(name,function()log(name)end)
  end
  if labels.pfTables then
   local checked=assert(io.open(output..'/prefix_search_verified.jsonl','w'))
   cb('pipe_fast_begin',function()
    local mt=emu.memType.snesMemory;local b=0x7e0000
    if not true and emu.read16(b+labels.pfPartial,mt)==0 then return end
    local offset=emu.read16(b+labels.pipe_record_offset,mt);local r=b+labels.pipe_records+offset
    local start=emu.read16(r+4,mt)//6;local count=emu.read16(r+2,mt)//6
    assert(start<count and count<=48,'invalid prefix table extent')
    local table=b+labels.pfTables+(offset//512)*256;local beforeBytes,beforeCost=0,0
    if start>0 then beforeBytes=emu.read16(table+(start-1)*4,mt);beforeCost=emu.read16(table+(start-1)*4+2,mt)end
    local originalLength=emu.read16(table+start*4,mt)-beforeBytes
    local partial=originalLength-emu.read16(r+208+start*6,mt)
    assert(partial>=0,'prefix partial length negative')
    beforeBytes=beforeBytes+partial;beforeCost=beforeCost+partial+partial//32+partial//128+(prefixRefreshSixteenth and partial//16 or 0)
    local available=emu.read16(b+labels.pipe_available,mt);local limit=available-384+beforeCost
    local last=start
    for i=start+1,count do if emu.read16(table+(i-1)*4+2,mt)<limit then last=i else break end end
    if true and emu.read16(table+(count-1)*4+2,mt)<limit+384-192 then last=count end
    assert(last>start,'empty prefix executed')
    local bytes=emu.read16(table+(last-1)*4,mt)-beforeBytes
    assert(emu.read16(b+labels.pfDesc,mt)==(last-start)*6,'prefix search chose wrong descriptor count')
    assert(emu.read16(b+labels.pfBytes,mt)==bytes,'prefix search chose wrong byte count')
    checked:write(string.format('{"field":%d,"start":%d,"last":%d,"count":%d,"partial":%d,"bytes":%d,"limit":%d}\n',field,start,last,count,partial,bytes,limit));checked:flush()
   end)
  end
  emu.addMemoryCallback(function(address,value)
   if value==1 then
    local mt=emu.memType.snesMemory
    log('dma_420b',{dmaBytes=emu.read16(0x4305,mt),dmaSource=emu.read16(0x4302,mt)+emu.read(0x4304,mt)*65536,dmaDestination=emu.getState()['ppu.vramAddress'],dmaMode=emu.read(0x4301,mt)})
   end
  end,emu.callbackType.write,0x420b,0x420b,emu.cpuType.snes,emu.memType.snesMemory)
 end
 cb(labels.pipe_irq_checked and 'pipe_irq_checked' or 'pipe_irq_done',function()
  -- IRQ�����̃L���[�Ǘ��͕\���������s�ł���BPPU�̎��]���E�ؑֈʒu��ʁX�Ɍ�������B
  local line=emu.getState()['ppu.scanline']
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_list_sort or labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_list_sort and 'sa1_list_sort' or labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=(false or packetOffload) and emu.memType.sa1Memory or emu.memType.snesMemory;local base=packetOffload and (packetIramArrays and 0 or 0x430000) or false and 4194304 or 0x7e0000
  local n=packetOffload and emu.read16(0x700+labels.packet_work+8,mt) or false and emu.read16(labels.packet_work+8,emu.memType.sa1Memory) or emu.read16(base+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(base+labels.keys+i,mt),value=emu.read16(base+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   local base=packetOffload and (packetIramArrays and 0 or 0x430000) or false and 4194304 or 0x7e0000
   local mt=(false or packetOffload) and emu.memType.sa1Memory or emu.memType.snesMemory
   for i,v in ipairs(sortReference)do assert(emu.read16(base+labels.order+(i-1)*2,mt)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(base+labels.order+(i-1)*2,mt))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.sparse_direct_overflow then cb('sparse_direct_overflow',function()error('direct sparse VRAM capacity exceeded field='..field)end,emu.cpuType.sa1)end
if labels.idle_clear_dma then
 local f=assert(io.open(output..'/idle_clear.jsonl','w'));local started,slot,band=0,0,0
 cb('idle_clear_dma',function()
  started=emu.getState().masterClock
  slot=emu.read16(0xa0,emu.memType.sa1InternalRam)//2
  band=emu.read16(0xac,emu.memType.sa1InternalRam)
 end,emu.cpuType.sa1)
 cb('idle_clear_done',function()
  f:write(string.format('{"field":%d,"slot":%d,"band":%d,"ms":%.6f}\n',field,slot,band,(emu.getState().masterClock-started)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
if labels.pipe_fast_partial_done then
 local f=assert(io.open(output..'/prefix_dma.jsonl','w'));local started=0
 local planClock,planMs=0,0
 cb('pipe_prefix_plan',function()planClock=emu.getState().masterClock end)
 cb('pipe_fast_begin',function()
  started=emu.getState().masterClock
  planMs=planClock>0 and (started-planClock)/21477.272 or 0
  planClock=0
 end)
 cb('pipe_fast_partial_done',function()
  local st=emu.getState();local mt=emu.memType.snesMemory;local base=0x7e0000
  f:write(string.format('{"field":%d,"line":%d,"bytes":%d,"descriptors":%d,"ms":%.6f,"planMs":%.6f}\n',field,st['ppu.scanline'],emu.read16(base+labels.pfBytes,mt),emu.read16(base+labels.pfDesc,mt)//6,(st.masterClock-started)/21477.272,planMs));f:flush()
 end)
end
if labels.stage_too_large then cb('stage_too_large',function()error('compact WRAM staging capacity exceeded field='..field)end)end
if labels.stage_time_ok then
 local started=0;local bytes=0;local count=0;local line=0
 cb('stage_time_ok',function()
  local st=emu.getState();local mt=emu.memType.snesMemory
  local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.stage_record,mt)
  started=st.masterClock;line=st['ppu.scanline'];bytes=emu.read16(record+34,mt);count=emu.read16(record+2,mt)//6
 end)
 cb('stage_converted',function()
  local st=emu.getState()
  cpuStageJobs[#cpuStageJobs+1]=string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}',field,bytes,count,line,st['ppu.scanline'],(st.masterClock-started)/21477.272)
 end)
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
if labels.opaque_prefix_selected and labels.opaque_prefix_patch_done then
 local f=assert(io.open(output..'/opaque_prefix.jsonl','w'))
 local opaqueActive=false
 cb('opaque_prefix_selected',function()
  opaqueActive=true
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"kind":"select","job":%d,"index":%d,"width":%d,"height":%d,"frontAsset":%d}\n',#times+1,emu.read16(0x2c,mt),emu.read16(0x34,mt),emu.read16(0x36,mt),emu.read16(0xb8,mt)));f:flush()
 end,emu.cpuType.sa1)
 cb('opaque_prefix_patch_done',function()
  if not opaqueActive then return end
  local mt=emu.memType.sa1Memory;local slot=emu.read16(0x8c,mt)
  local bank=emu.read(0x94,mt);local old=bank*65536+emu.read16(0x92,mt)
  assert(emu.read(0x70a+slot,mt)==bank,'opaque prefix changed native bank')
  local new=bank*65536+emu.read16(0x708+slot,mt);local op=emu.read(new,mt)
  assert(new>=old and (op==0xa9 or op==0xbd or op==0x6b),'opaque prefix resumed without accumulator load')
  local format=0
  if not false then
   local hint=emu.read(old-5,mt)+emu.read(old-4,mt)*256+emu.read(old-3,mt)*65536
   local marker=emu.read(hint,mt);format=marker>=128 and marker or 0
  end
  f:write(string.format('{"kind":"patch","job":%d,"row":%d,"old":%d,"new":%d,"format":%d,"allHidden":%s}\n',#times+1,emu.read16(0x8e,mt),old,new,format,op==0x6b and 'true' or 'false'));f:flush()
 end,emu.cpuType.sa1)
 cb('opaque_prefix_finished',function()opaqueActive=false end,emu.cpuType.sa1)
end
if labels.cache_miss then
 local f=assert(io.open(output..'/bullet_cache.jsonl','w'));local start=0;local missed=false
 cb('sa1_bullet_cache_prepare',function()start=emu.getState().masterClock;missed=false end,emu.cpuType.sa1)
 cb('cache_miss',function()missed=true end,emu.cpuType.sa1)
 cb('cache_ready',function()
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"field":%d,"asset":%d,"width":%d,"height":%d,"flags":%d,"miss":%s,"ms":%.6f}\n',#times+1,field,emu.read16(0x3e,mt),emu.read16(0x34,mt),emu.read16(0x36,mt),emu.read16(0x3c,mt),missed and 'true' or 'false',(emu.getState().masterClock-start)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
cb('render_started',function()begin=emu.getState().masterClock;activeBegin=activeClock();cpuParts={};cpuActiveParts={} end)
cb('logic_finished',function()
 if scenario:match('^splitfixture') then
  local objects=splitFixtures[(logic-1)%#splitFixtures+1]
  word('_fx_packet_count',#objects)
  for i,o in ipairs(objects)do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,o[1]&65535,mt);emu.write16(a+2,o[2]&65535,mt)
   for j=3,8 do emu.write(a+j+1,o[j],mt)end
  end
 end
 if scenario:match('^opaquefixture') then
  local targets={{49,37},{49,38},{50,38},{50,39},{52,40},{53,41},{55,42},{55,43},{56,44},{58,45},{60,47},{62,48},{62,49},{64,49},{64,50},{66,51},{66,52},{68,53},{68,54},{71,55},{71,56},{73,57},{73,58},{76,59},{76,60},{79,61},{79,62}};local fronts={{39,64,49},{39,64,50},{39,64,64},{39,66,51},{39,66,52},{39,68,53},{39,68,54},{39,71,55},{39,71,56},{39,73,57},{39,73,58},{39,76,59},{39,76,60},{39,79,61},{39,79,62},{39,82,64},{39,85,66},{39,85,67},{39,88,68},{39,88,69},{39,91,71},{39,94,73},{39,94,74},{39,97,76},{39,100,78},{39,128,94},{40,64,49},{40,64,50},{40,66,51},{40,66,52},{40,68,53},{40,68,54},{40,71,55},{40,71,56},{40,73,57},{40,73,58},{40,76,59},{40,76,60},{40,79,61},{40,79,62},{40,82,64},{40,85,66},{40,85,67},{40,88,68},{40,88,69},{40,91,71},{40,94,73},{40,94,74},{40,97,76},{40,100,78},{40,128,84},{41,64,49},{41,64,50},{41,66,51},{41,66,52},{41,68,53},{41,68,54},{41,71,55},{41,71,56},{41,73,57},{41,73,58},{41,76,59},{41,76,60},{41,79,61},{41,79,62},{41,82,64},{41,85,66},{41,85,67},{41,88,68},{41,88,69},{41,91,71},{41,94,73},{41,94,74},{41,97,76},{41,100,78},{41,128,88}}
  local g=targets[(logic-1)%#targets+1];local f=fronts[(logic-1)%#fronts+1]
  local centers={40,41,128,129,216,217,16,250};local tops={-20,0,30,55,120,180,191}
  local center=centers[(logic-1)%#centers+1];local top=tops[(logic-1)%#tops+1]
  local shifts={-24,0,24};local shift=shifts[math.floor((logic-1)/#centers)%3+1]
  local objects={{16,130,79,62,39},{center,top+g[2]+20,g[1],g[2],40},{128,120,12,12,7},{center,top+g[2]+20,g[1],g[2],40},{center+shift,top-8+f[3]+20,f[2],f[3],f[1]}}
  word('_fx_packet_count',#objects)
  for i,o in ipairs(objects)do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,o[1]&65535,mt);emu.write16(a+2,o[2]&65535,mt)
   emu.write(a+4,o[3],mt);emu.write(a+5,o[4],mt);emu.write(a+6,o[5],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^clipfixture') then
  local objects={{16,110,79,62,39},{16,150,79,62,39},{128,120,12,12,7},{16,130,79,62,39},{-10,155,88,38,42},{16,160,79,62,39},{250,165,91,71,40},{250,110,91,71,41}}
  word('_fx_packet_count',#objects)
  for i,g in ipairs(objects)do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,g[1]&65535,mt);emu.write16(a+2,g[2],mt)
   emu.write(a+4,g[3],mt);emu.write(a+5,g[4],mt);emu.write(a+6,g[5],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^transferfixture') then
  -- ���ۂ�asset�Ək���\��9�`���A�L�q�q�̓r�������E��IRQ�ĊJ��ʂ��B
  word('_fx_packet_count',9)
  for i=0,8 do
   local a=0x7e0000+labels._fx_packet+i*10;local mt=emu.memType.snesMemory
   emu.write16(a,48+(i%3)*80,mt);emu.write16(a+2,94+math.floor(i/3)*58,mt)
   emu.write(a+4,94,mt);emu.write(a+5,74,mt);emu.write(a+6,40+(logic+i)%2,mt);emu.write(a+7,0,mt);emu.write16(a+8,i+1,mt)
  end
 end
 if scenario:match('^stackfixture') then
  local centers={0,47,48,49,128,182,222,265,266,267,268,286,300}
  local tops={-20,0,30,55,56,120,180}
  local h=73+math.floor((logic-1)/(#centers*#tops))%2
  local w=94
  if scenario:match('wide') then
   local g=math.floor((logic-1)/(#centers*#tops))%3
   if g==2 then w=91;h=71 else h=73+g end
  end
  if scenario:match('^stackfixturemin') then
   local geometries={{91,71}}
   local g=geometries[math.floor((logic-1)/(#centers*#tops))%#geometries+1]
   w=g[1];h=g[2]
  end
  local top=tops[math.floor((logic-1)/#centers)%#tops+1]
  word('_fx_packet_count',2)
  for i=1,2 do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[(logic+i-2)%#centers+1],mt)
   emu.write16(a+2,(top+h+20)&65535,mt)
   emu.write(a+4,w,mt);emu.write(a+5,h,mt);emu.write(a+6,39+i,mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^leftfixture') then
  local geometries={{0,90,48},{3,90,47},{0,93,50},{3,93,49},{0,97,52},{3,96,51},{0,104,55},{3,100,53},{0,107,57},{3,103,55},{0,114,61},{3,110,58}}
  if scenario:match('^leftfixtureindexed') then
   local centers={-40,-39,0,1,16,17,30,31,64,65,128,129,250,251}
   local tops={-20,30,180}
   word('_fx_packet_count',2)
   for i=1,2 do
    local n=((logic-1)*2+i-1)%(#geometries*#centers*#tops)
    local g=geometries[n%#geometries+1]
    local x=centers[math.floor(n/#geometries)%#centers+1]
    local top=tops[math.floor(n/(#geometries*#centers))%#tops+1]
    local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
    emu.write16(a,x&65535,mt);emu.write16(a+2,(top+g[3]+20)&65535,mt)
    emu.write(a+4,g[2],mt);emu.write(a+5,g[3],mt);emu.write(a+6,g[1],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
   end
  else
  local centers={-40,0,16,30,64,128,250}
  local bottoms={40,120,205}
  word('_fx_packet_count',2)
  for i=1,2 do
   local g=geometries[math.floor((logic-1)/7)*2%#geometries+i]
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[(logic+i-2)%#centers+1]&65535,mt)
   local bottomIndex=math.floor((logic-1)/#centers)
   if scenario:match('^leftfixtureexplosion') then bottomIndex=bottomIndex+math.floor((logic-1)/(#centers*(#geometries/2))) end
   if scenario:match('^leftfixtureflame') then bottomIndex=math.floor((logic-1)/(#centers*3)) end
   emu.write16(a+2,bottoms[bottomIndex%#bottoms+1],mt)
   local phase=(scenario:match('^leftfixtureflame') and g[1]==31) and math.floor((logic-1)/#centers)%3 or 0
   emu.write(a+4,g[2],mt);emu.write(a+5,g[3],mt);emu.write(a+6,g[1],mt);emu.write(a+7,phase,mt);emu.write16(a+8,i,mt)
  end
  end
 end
 if scenario:match('^flipfixture') then
  local assets={6,7,8,37};local sizes={6,16,32,48,62}
  local size=sizes[math.floor((logic-1)/12)%5+1]
  local flags=(math.floor((logic-1)/3)%4)*16+(logic-1)%3
  local centers={-2,254,128,64};local bottoms={120,200,30,160}
  word('_fx_packet_count',4)
  for i=1,4 do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[i]&65535,mt);emu.write16(a+2,bottoms[i],mt)
   emu.write(a+4,size,mt);emu.write(a+5,size,mt);emu.write(a+6,assets[i],mt);emu.write(a+7,flags,mt)
   emu.write16(a+8,0,mt)
  end
 end
 if packetOffload and (scenario:match('^flipfixture') or scenario:match('^leftfixture')) then
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels._fx_packet_count,mt)
  byte('_fx_draw_count',n)
  for i=0,n*10-1 do emu.write(0x7e0000+labels._fx_draw+i,emu.read(0x7e0000+labels._fx_packet+i,mt),mt)end
 end
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 local activeParts={};for name,v in pairs(cpuActiveParts)do activeParts[#activeParts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"activeLogicMs":%.6f,"parts":{%s},"activeParts":{%s}}',field,logicMs,(activeClock()-activeBegin)/21477.272,table.concat(parts,','),table.concat(activeParts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.cpu_dirty_prepare and labels.cpu_dirty_done then
 local f=assert(io.open(output..'/cpu_dirty.jsonl','w'))
 local t,a=0,0
 cb('cpu_dirty_prepare',function()t=emu.getState().masterClock;a=activeClock()end)
 cb('cpu_dirty_done',function()
  f:write(string.format('{"logic":%d,"field":%d,"ms":%.6f,"activeMs":%.6f}\n',logic,field,(emu.getState().masterClock-t)/21477.272,(activeClock()-a)/21477.272));f:flush()
 end)
end
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.flame_direct_row then
 local active=false;local f=assert(io.open(output..'/flame_direct.jsonl','w'))
 cb('sa1_left_hint_draw',function()active=emu.read16(0x3e,emu.memType.sa1Memory)==31 end,emu.cpuType.sa1)
 cb('flame_direct_row',function()
  if not active then return end
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"row":%d,"width":%d,"cur":%d}\n',#times+1,emu.read16(0xa0,mt),emu.read16(0x34,mt),emu.read16(0x90,mt)));f:flush()
 end,emu.cpuType.sa1)
 cb('left_hint_finished',function()active=false end,emu.cpuType.sa1)
end
if labels.direct_left_row then
 local active=false;local f=assert(io.open(output..'/direct_left.jsonl','w'))
 cb('sa1_left_hint_draw',function()active=true end,emu.cpuType.sa1)
 cb('direct_left_row',function()
  if not active then return end
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"row":%d,"asset":%d,"width":%d,"cur":%d}\n',#times+1,emu.read16(0xa0,mt),emu.read16(0x3e,mt),emu.read16(0x34,mt),emu.read16(0x90,mt)));f:flush()
 end,emu.cpuType.sa1)
 cb('left_hint_finished',function()active=false end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()
 local n=0
 if prebankDma then
  local mt=emu.memType.sa1Memory;local count=emu.read16(0x11a,mt)
  local base=emu.read16(0x19a,mt);local gen=emu.read16(0x198,mt)
  local page=gen%2==1 and 0x3000 or 0;local bytes,cost=0,0
  local table=(emu.read16(0x102,mt)&255)*65536+base+0x6600
  assert(count<=48,'prebank descriptor overflow')
  for i=0,count-1 do
   local a=0x430800+i*6;local len=emu.read16(a,mt);local src=(emu.read16(a+2,mt)-base)&65535
   local dst=emu.read16(a+4,mt)
   assert(len>0 and len%32==0 and src>=1024 and src+len<=24576,'prebank source extent invalid')
   assert(dst==page+src//2-496 and dst+len//2<=page+0x3000,'prebank absolute destination invalid')
   bytes=bytes+len
   cost=cost+len+len//32+len//128+(prefixRefreshSixteenth and len//16 or 0)+57
   assert(emu.read16(table+i*4,mt)==bytes and emu.read16(table+i*4+2,mt)==cost,'prebank cumulative cost differs from independent formula')
  end
  assert(bytes==emu.read16(0x118,mt),'prebank transfer bytes differ')
 end
 if splitViewports then
  local mt=emu.memType.sa1Memory;n=emu.read16(0x11a,mt)
  assert(n<=48,'split DMA metadata overflow')
  assert(emu.read16(0x19a,mt)==0x400,'split base was not restored')
  local bytes=0
  for i=0,n-1 do
   local a=0x430800+i*6;local len=emu.read16(a,mt);local src=emu.read16(a+2,mt);local dst=emu.read16(a+4,mt)
   local pos=src&0x3ff
   assert(len>0 and pos>=0x100 and pos+len<=0x300 and len%32==0,'split descriptor crosses viewport half')
   local original=(src&0x7c00)-0x400+pos-0x100+((src&0x8000)~=0 and 0x200 or 0)
   assert(original>=1024 and original+len<=24576 and dst*2+992==original,'split descriptor source/VRAM mismatch')
   bytes=bytes+len
  end
  assert(bytes==emu.read16(0x118,mt),'split transfer bytes differ')
 end
 outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f,"splitDescriptorsVerified":%d}',field,(emu.getState().masterClock-sa1begin)/21477.272,n)
end,emu.cpuType.sa1)end
if prebankDma then
 local f=assert(io.open(output..'/prebank_dma_verified.jsonl','w'))
 cb('pipe_setup_transfer',function()
  local mt=emu.memType.snesMemory;local b=0x7e0000
  local r=b+labels.pipe_records+emu.read16(b+labels.pipe_record_offset,mt)
  local gen=emu.read16(r+8,mt);local page=gen%2==1 and 0x3000 or 0
  assert(emu.read16(r+6,mt)==page,'prebank generation/page ownership mismatch')
  assert(emu.read16(b+labels.fx4_page,mt)~=page,'prebank transfer targets visible page')
  local base=emu.read16(r,mt)&0x8400;local cursor=emu.read16(r+4,mt)
  local finish=emu.read16(r+2,mt)
  assert(cursor<=finish and finish<=48*6,'prebank WRAM extent invalid')
  for i=cursor,finish-1,6 do
   local a=r+208+i;local len=emu.read16(a,mt);local src=(emu.read16(a+2,mt)-base)&65535
   assert(emu.read16(a+4,mt)==page+src//2-496,'prebank resumed destination invalid')
   assert(src>=1024 and src+len<=24576,'prebank resumed source invalid')
  end
  f:write(string.format('{"generation":%d,"page":%d,"cursor":%d,"descriptors":%d}\n',gen,page,cursor,finish//6));f:flush()
 end)
 if dmaShortIo then cb('pipe_fast_groups_done',function()
  local s=emu.getState()
  assert(s['cpu.dbr']==0x7e and s['cpu.d']==0,'DMA short I/O did not restore DB/D')
 end)end
end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
if labels.sa1_mask_clear then
 local f=assert(io.open(output..'/mask_clear.jsonl','w'))
 cb('sa1_clear_done',function()
  local mt=emu.memType.sa1Memory
  local bytes=emu.read16(0x1ac,mt);local bounds=0
  for r=0,23 do local a=0x120+r*4;bounds=bounds+math.max(0,emu.read16(a+2,mt)-emu.read16(a,mt))*8 end
  f:write(string.format('{"generation":%d,"bytes":%d,"boundsBytes":%d,"ms":%.6f}\n',emu.read16(0x198,mt),bytes,bounds,clearMs));f:flush()
 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if true and (captureGeneration(gen) or boundsFrames) then
   local bank=emu.read16(0x102,mt);local base=emu.read16(0x19a,mt);local t={}
   if splitViewports then
    bank=bank&255
    assert(base==0x400 and bank>=0x40 and bank<=0x42,'split framebuffer bank/base invalid bank='..bank..' base='..base)
    for y=0,191 do for half=0,1 do for x=32,95 do t[#t+1]=string.char(emu.read(bank*65536+base+half*0x8000+y*128+x,mt))end end end
   else for i=0,24575 do t[#t+1]=string.char(emu.read((bank&255)*65536+base+i,mt))end end
   local fb=table.concat(t)
   if boundsFrames then boundsFrames:write(string.char(gen&255,gen>>8)..fb);boundsFrames:flush()end
   if captureGeneration(gen) then completedFrames[gen]=fb end
  end
  if captureGeneration(gen) then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 local rejectedLog=assert(io.open(output..'/rejected_dma.jsonl','w'))
 cb('pipe_fast_unavailable',function()
  local mt=emu.memType.snesMemory;local base=0x7e0000
  local record=base+labels.pipe_records+emu.read16(base+labels.pipe_record_offset,mt)
  rejectedLog:write(string.format('{"field":%d,"gen":%d,"bytes":%d,"count":%d,"cost":%d,"available":%d}\n',field,emu.read16(record+8,mt),emu.read16(record+34,mt),(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6,emu.read16(base+labels.pipe_dma_chunk,mt),emu.read16(base+labels.pipe_available,mt)));rejectedLog:flush()
 end)
 cb('pipe_fast_begin',function()
  local st=emu.getState();assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA began outside actual blank period')
  if scenario:match('tracedma') then
   local st=emu.getState();local f=assert(io.open(output..'/cc_state.jsonl','a'))
   f:write(string.format('{"field":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',field,st['cart.coprocessor.dmaSrcAddr'],st['cart.coprocessor.dmaDestAddr'],tostring(st['cart.coprocessor.charConvDmaActive']),tostring(st['ppu.forcedBlank']),st['ppu.scanline']));f:close()
   if presents==0 then
    local f=assert(io.open(output..'/before_dma_bw.bin','wb'));local a={}
    for i=0,24575 do a[#a+1]=string.char(emu.read(1024+i,emu.memType.snesSaveRam))end
    f:write(table.concat(a));f:close()
   end
  end
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA ended outside actual blank period')
  if scenario:match('tracedma') and presents==0 then
   local f=assert(io.open(output..'/beforeflip_vram.bin','wb'));local a={}
   for i=0,65535 do a[#a+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
   f:write(table.concat(a));f:close()
  end
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.fx_obj_upload_done then cb('fx_obj_upload_done',function()
 if field>90 then
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'OAM DMA ended outside actual blank period')
 end
end)end
if labels.dense_vram_overflow then cb('dense_vram_overflow',function()error('packed image exceeds one VRAM page')end,emu.cpuType.sa1)end
if vramPrefetch3 then
 emu.addMemoryCallback(function(address,value)
  if field>85 then
   local st=emu.getState()
   assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'BG1 map changed outside actual blank period')
  end
 end,emu.callbackType.write,0x2107,0x2107,emu.cpuType.snes,emu.memType.snesMemory)
end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock;pageCommit=nil end)end
if labels.pipe_flip_prepared then
 local f=assert(io.open(output..'/flip_preparation.jsonl','w'))
 local prepared=nil
 cb('pipe_flip_prepared',function()
  local s=emu.getState();local channels={}
  for c=1,7 do
   local p='dmaController.channel['..c..'].'
   local bank=s[p..'srcBank'];local address=s[p..'hdmaTableAddress']
   assert(type(bank)=='number' and type(address)=='number','HDMA state fields missing')
   if bank==0x7e then assert(address<0x1c00 or address>=0x1e00,'HDMA table aliases flip metadata')end
   if s[p..'hdmaIndirectAddressing'] then
    local indirectBank=s[p..'hdmaBank'];local indirect=s[p..'transferSize']
    assert(type(indirectBank)=='number' and type(indirect)=='number','indirect HDMA state fields missing')
    if indirectBank==0x7e then assert(indirect<0x1c00 or indirect>=0x1e00,'indirect HDMA data aliases flip metadata')end
   end
   channels[#channels+1]=string.format('{"channel":%d,"bank":%d,"table":%d}',c,bank,address)
  end
  prepared={clock=s.masterClock,line=s['ppu.scanline'],field=field,channels=table.concat(channels,',')}
 end)
 cb('pipe_flip_ppu',function()
  assert(prepared,'flip PPU update before preparation')
  local s=emu.getState();local line=s['ppu.scanline']
  assert((line>=203 or line<=21) and (s['ppu.forcedBlank'] or line>=225),'early flip PPU update outside reserved blank')
  f:write(string.format('{"field":%d,"prepareField":%d,"prepareLine":%d,"ppuLine":%d,"waitTicks":%d,"channels":[%s]}\n',field,prepared.field,prepared.line,line,s.masterClock-prepared.clock,prepared.channels));f:flush();prepared=nil
 end)
end
if labels.fd_flip then
 local f=assert(io.open(output..'/map_delta.jsonl','w'))
 local begin=0;local count=0
 cb('fd_flip',function()
  local st=emu.getState();begin=st.masterClock
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,emu.memType.snesMemory)
  count=emu.read16(0x7e0000+labels.pipe_records+slot*512+62,emu.memType.snesMemory)
  if count>0 then assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'map update started outside actual blank')end
 end)
 cb('fd_flip_done',function()
  local st=emu.getState()
  if count>0 then assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'map update ended outside actual blank')end
  f:write(string.format('{"field":%d,"count":%d,"ms":%.6f,"line":%d}\n',field,count,(st.masterClock-begin)/21477.272,st['ppu.scanline']));f:flush()
 end)
end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=(pageCommit and pageCommit.line) or state['ppu.scanline']
 local commitField=(pageCommit and pageCommit.field) or field
 local visibleField=commitField+(line>=203 and line<225 and 1 or 0)
 assert(line<=21 or line>=203,'page flip occurred during visible lines field='..field..' line='..line)
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if captureGeneration(presents) then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   local page=emu.read16(record+6,mt)*2
   local bg1Chr=state['ppu.layers[0].chrAddress']*2
   local bg1Map=state['ppu.layers[0].tilemapAddress']*2
   local bg2Chr=state['ppu.layers[1].chrAddress']*2
   local bg2Map=state['ppu.layers[1].tilemapAddress']*2
   assert(bg1Chr==math.floor(page/8192)*8192,'PPU BG1 CHR base differs from the rendered page')
   assert(bg1Map==(vramFourOwned and page+0x2800 or fixedMap and 0xc000 or vramFourShared and 0xc000 or vramPrefetch3 and page+0x800 or 0xc000),'PPU BG1 map base differs')
   assert(bg2Chr==(vramFourOwned and 0xc000 or (fixedMap or vramFifo) and 0xa000 or vramFourShared and 0x8000 or true and 0 or 0xc000),'PPU BG2 CHR base differs')
   assert(bg2Map==0xc000,'PPU BG2 map base differs')
   local p=assert(io.open(output..'/'..n..'_ppu.json','w'))
   p:write(string.format('{"bg1Chr":%d,"bg1Map":%d,"bg2Chr":%d,"bg2Map":%d}',bg1Chr,bg1Map,bg2Chr,bg2Map));p:close()
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   if fixedMapDelta then dump(n..'_map_delta.bin',emu.memType.snesMemory,0x7e0000+labels.fdStorage+slot*1472,1472)end
   if true then dump(n..'_ground_h.bin',emu.memType.snesMemory,0x7e0000+emu.read16(record+26,mt),270)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs field='..field..' gen='..presents..' byte='..i..' actual='..emu.read(i,emu.memType.snesSpriteRam)..' expected='..emu.read(record+64+i,mt))end
   if true then
    local expected=emu.read16(record+192,mt)|0x0aaa
    local actual=emu.read16(512,emu.memType.snesSpriteRam)
    assert((actual&0x0fff)==(expected&0x0fff),'player high OAM differs')
    dump(n..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    dump(n..'_palette.bin',emu.memType.snesCgRam,0,512)
   else
    for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 if true and presents>0 then
  for i=0,31 do
   local fx=emu.read(32+i,emu.memType.snesCgRam)
   local near=emu.read(480+i,emu.memType.snesCgRam)
   if fx~=expectedPalette[i+1] or near~=expectedPalette[i+1] then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('CGRAM changed field='..field..' byte='..i..' fx='..fx..' near='..near..' expected='..expectedPalette[i+1]);f:close();emu.stop(1);return
   end
  end
 end
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if finished then
  local f=assert(io.open(output..'/final_state.txt','w'));for k,v in pairs(emu.getState())do f:write(tostring(k)..'='..tostring(v)..'\n')end;f:close()
 end
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  finishedCapture=true
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s],"cpuStageJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,','),table.concat(cpuStageJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
