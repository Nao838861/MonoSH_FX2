local labels={["LoadAudioData"]=35153,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=35756,["Tad_GetSong"]=35860,["Tad_GlobalVolumesPersist"]=35888,["Tad_GlobalVolumesResetOnSongStart"]=35882,["Tad_Init"]=35372,["Tad_IsLoaderActive"]=35914,["Tad_IsSfxPlaying"]=35928,["Tad_IsSongLoaded"]=35922,["Tad_IsSongPlaying"]=35934,["Tad_LoadSong"]=35815,["Tad_LoadSongIfChanged"]=35848,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=35499,["Tad_QueueCommand"]=35772,["Tad_QueueCommandOverride"]=35777,["Tad_QueuePannedSoundEffect"]=35794,["Tad_QueueSoundEffect"]=35804,["Tad_ReloadCommonAudioData"]=35864,["Tad_SetTransferSize"]=35894,["Tad_SongsStartImmediately"]=35870,["Tad_SongsStartPaused"]=35876,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=7,["Tad_sfxQueue_sfx"]=6,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5747,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=61851,["__DATA_LOAD__"]=12764155,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__SA1_LOAD__"]=36186,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=1015,["__STARTUP__"]=1,["_abs"]=61482,["_boss_age"]=63363,["_boss_attribute_cache"]=63198,["_boss_attribute_cache_count"]=63360,["_boss_attribute_z_cache"]=63342,["_boss_dda_phase"]=63581,["_boss_dda_x"]=63587,["_boss_dda_y"]=63593,["_boss_death_parts"]=63365,["_boss_death_timer"]=63364,["_boss_fire_gap"]=63374,["_boss_fire_round"]=63371,["_boss_fire_shots"]=63373,["_boss_fire_state"]=63370,["_boss_fire_volley"]=63372,["_boss_history_x"]=62814,["_boss_history_y"]=62942,["_boss_history_z"]=63070,["_boss_last_vblank"]=62750,["_boss_motion_steps"]=63369,["_boss_part_active"]=62778,["_boss_part_bottom"]=62760,["_boss_part_fall_fraction"]=62805,["_boss_part_fall_velocity"]=62796,["_boss_part_timer"]=62787,["_boss_part_x"]=62751,["_boss_part_z"]=62769,["_boss_path_half"]=63368,["_boss_player_bottom"]=63377,["_boss_player_x"]=63375,["_boss_render_camera_delta"]=63361,["_boss_restart_timer"]=63366,["_boss_z_phase"]=63367,["_death_accel_fraction"]=63615,["_death_timer"]=63613,["_death_vy"]=63612,["_enemy_p0_samples"]=47679,["_enemy_p1_samples"]=48414,["_enemy_p2_samples"]=49119,["_enemy_p3_samples"]=49824,["_enemy_p4_samples"]=50529,["_enemy_p5_samples"]=51246,["_enemy_p6_samples"]=51963,["_enemy_p7_samples"]=52530,["_enemy_p8_samples"]=53097,["_fx4_explosion_lift"]=804,["_fx_asset_bank"]=27512,["_fx_asset_height"]=27468,["_fx_asset_width"]=27424,["_fx_audio_events"]=5648,["_fx_boss_hits"]=11930,["_fx_boss_project"]=12504,["_fx_build_ground"]=1493,["_fx_build_packet"]=28425,["_fx_buttons"]=60972,["_fx_draw"]=59048,["_fx_draw_count"]=59688,["_fx_em0_geometry"]=14431,["_fx_enemy_collisions"]=13898,["_fx_enemy_em1_update"]=15650,["_fx_enemy_em1_update_reference"]=24319,["_fx_enemy_fire_em1"]=24257,["_fx_enemy_remove"]=24246,["_fx_enemy_render"]=14569,["_fx_enemy_render_bullets"]=14848,["_fx_far_d_acc"]=60984,["_fx_far_u_acc"]=60982,["_fx_fire_actions"]=60975,["_fx_frame"]=15944,["_fx_ground_c1ptr"]=62740,["_fx_ground_c3ptr"]=62742,["_fx_ground_camera"]=27556,["_fx_ground_color1"]=60991,["_fx_ground_color3"]=61441,["_fx_ground_depth_rows"]=27701,["_fx_ground_far_x"]=62706,["_fx_ground_far_xptr"]=62736,["_fx_ground_far_y"]=62746,["_fx_ground_greens"]=33047,["_fx_ground_horizon"]=62744,["_fx_ground_horizontal"]=61891,["_fx_ground_hptr"]=62701,["_fx_ground_native"]=1578,["_fx_ground_palette_record"]=62704,["_fx_ground_phase"]=60971,["_fx_ground_vptr"]=62738,["_fx_ground_width"]=32966,["_fx_ground_world_phase"]=62703,["_fx_init"]=16707,["_fx_input"]=60974,["_fx_open_size"]=58165,["_fx_packet"]=59691,["_fx_packet_count"]=59689,["_fx_present"]=328,["_fx_read_input"]=64,["_fx_send_ground"]=124,["_fx_sky_color"]=33055,["_fx_stage_contact"]=60028,["_fx_stage_render"]=59318,["_fx_stage_update"]=60359,["_fx_submit"]=60712,["_ground_irq_vblank_count"]=60979,["_history_head"]=63362,["_hit_pending"]=60986,["_intro_timer"]=63616,["_legacy_enemy_fire_boss_at"]=22851,["_main"]=16744,["_memcpy"]=61313,["_monosh_bom_geometry"]=43312,["_monosh_boss_body_geometry"]=39055,["_monosh_boss_bom_depth_by_size"]=39499,["_monosh_boss_bom_geometry"]=39277,["_monosh_boss_bullet_velocity"]=39737,["_monosh_boss_draw_order_base"]=34513,["_monosh_boss_draw_order_mid"]=36673,["_monosh_boss_explosion_ground_bottom"]=39626,["_monosh_boss_explosion_scale_low"]=39515,["_monosh_boss_face_geometry"]=38833,["_monosh_boss_frame"]=16933,["_monosh_boss_hp"]=62749,["_monosh_boss_init"]=16776,["_monosh_boss_path_center_y"]=33553,["_monosh_boss_path_center_y_mid"]=34273,["_monosh_boss_path_x"]=33313,["_monosh_boss_path_x_mid"]=34033,["_monosh_boss_path_z"]=33073,["_monosh_boss_path_z_mid"]=33793,["_monosh_boss_prepare_fire"]=18832,["_monosh_boss_prepare_render"]=16969,["_monosh_boss_render_only"]=12284,["_monosh_boss_should_restart"]=16755,["_monosh_boss_state"]=62748,["_monosh_bullet_reflect_rng"]=63419,["_monosh_collision_bullet_bands"]=63411,["_monosh_combat_build_collision_bands"]=19014,["_monosh_combat_fast_cache_reset"]=13483,["_monosh_combat_fast_frame"]=12699,["_monosh_combat_fast_render"]=12829,["_monosh_combat_fast_render_cached"]=13490,["_monosh_combat_fire_cooldown"]=63420,["_monosh_combat_half_frame"]=63421,["_monosh_combat_init"]=18858,["_monosh_combat_reflect_bullet"]=13128,["_monosh_combat_render"]=19011,["_monosh_combat_update"]=18953,["_monosh_ebullet4_geometry"]=44119,["_monosh_ebullet_animation_geometry"]=43897,["_monosh_ebullet_geometry"]=44341,["_monosh_ebullet_velocity"]=44351,["_monosh_em1_animation_assets_ready"]=63576,["_monosh_em1_closed_geometry"]=43534,["_monosh_em1_open_geometry"]=43756,["_monosh_enemies"]=63425,["_monosh_enemy_active_count"]=19774,["_monosh_enemy_active_count_value"]=63423,["_monosh_enemy_bullet_count"]=63422,["_monosh_enemy_bullets"]=63505,["_monosh_enemy_camera_delta_cached"]=63574,["_monosh_enemy_collision_cursor"]=63579,["_monosh_enemy_draw_cache_valid"]=63577,["_monosh_enemy_em1_count"]=63575,["_monosh_enemy_em1_phase"]=63550,["_monosh_enemy_em1_shrink"]=63566,["_monosh_enemy_fast_advance"]=15242,["_monosh_enemy_fast_check_player_bullets"]=20864,["_monosh_enemy_fast_render"]=20349,["_monosh_enemy_fast_render_bullets"]=21814,["_monosh_enemy_fast_spawn_due"]=22190,["_monosh_enemy_fast_update_bullets"]=13568,["_monosh_enemy_fire_at"]=19786,["_monosh_enemy_fire_boss_at"]=19815,["_monosh_enemy_fire_em0_fast"]=23249,["_monosh_enemy_frame"]=19577,["_monosh_enemy_geometry"]=43090,["_monosh_enemy_ground_bottom"]=43786,["_monosh_enemy_half_frame"]=63578,["_monosh_enemy_init"]=19428,["_monosh_enemy_path_fire_frames"]=53709,["_monosh_enemy_path_frames"]=53700,["_monosh_enemy_paths"]=53664,["_monosh_enemy_player_hit"]=63580,["_monosh_enemy_render_only"]=19607,["_monosh_enemy_spawn_index"]=63547,["_monosh_enemy_spawn_wait"]=63548,["_monosh_enemy_spawns"]=53718,["_monosh_enemy_stage_complete"]=19780,["_monosh_enemy_stage_complete_flag"]=63424,["_monosh_ground_depth_pointer"]=60989,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=63603,["_monosh_player_bullet_count"]=63394,["_monosh_player_bullet_sizes"]=43065,["_monosh_player_bullets"]=63379,["_monosh_player_can_fire"]=26077,["_monosh_player_draw_asset"]=26093,["_monosh_player_draw_flags"]=26035,["_monosh_player_init"]=25972,["_monosh_player_invuln"]=63606,["_monosh_player_pose"]=63608,["_monosh_player_state"]=63605,["_monosh_player_stumble"]=63607,["_monosh_player_update"]=28732,["_monosh_player_update_reference"]=27302,["_monosh_player_world_active"]=26071,["_monosh_player_x"]=63601,["_monosh_project_x"]=29342,["_monosh_reflected_bullet_count"]=63410,["_monosh_reflected_bullets"]=63395,["_monosh_runtime_fire_actions"]=60976,["_monosh_runtime_frame_counter"]=60977,["_monosh_runtime_paused"]=60981,["_monosh_stage1_spawn_count"]=54860,["_monosh_stage1_spawns"]=53924,["_monosh_stage_collision_bullet_cursor"]=63855,["_monosh_stage_collision_bullet_index"]=63856,["_monosh_stage_contact_result"]=63853,["_monosh_stage_draw_cache_valid"]=63854,["_monosh_stage_frame"]=27577,["_monosh_stage_frame_counter"]=63717,["_monosh_stage_geometry"]=57526,["_monosh_stage_half_frame"]=63721,["_monosh_stage_hitbox_count"]=63851,["_monosh_stage_hitboxes"]=63723,["_monosh_stage_init"]=27542,["_monosh_stage_is_clear"]=27626,["_monosh_stage_lift"]=58315,["_monosh_stage_near_count"]=63722,["_monosh_stage_need_hitboxes"]=63852,["_monosh_stage_object_count"]=63715,["_monosh_stage_objects"]=63619,["_monosh_stage_render_only"]=27623,["_monosh_stage_spawn_index"]=63716,["_monosh_stage_spawn_wait"]=63719,["_monosh_stage_title_timer"]=63609,["_monosh_title_draw"]=16733,["_monosh_title_visible"]=58365,["_movement_fraction"]=63614,["_old_buttons"]=60987,["_player_flip"]=63617,["_player_fy"]=63610,["_player_run_phase"]=63618,["_pose_x_01"]=53862,["_pose_x_12"]=53881,["_pose_x_23"]=53900,["_stage_bom0_geometry"]=57082,["_stage_bush0_geometry"]=54862,["_stage_bush1_geometry"]=55306,["_stage_em0_geometry"]=56194,["_stage_flystone_geometry"]=55750,["_stage_lift_0"]=57538,["_stage_lift_1"]=57649,["_stage_lift_2"]=57760,["_stage_lift_3"]=57871,["_stage_lift_4"]=57982,["_stage_lift_5"]=58093,["_stage_lift_6"]=58204,["_stage_tree0_geometry"]=56638,["_v9968_copy_to_vram_linear"]=13484,["addeq0sp"]=60952,["addeqysp"]=60954,["addysp"]=60970,["addysp1"]=60969,["aslax2"]=60983,["aslax3"]=60994,["aslax4"]=61008,["asrax1"]=61025,["asrax2"]=61035,["asrax3"]=61050,["audio4_first_done"]=491,["audio4_second_done"]=491,["background_done"]=98722,["booleq"]=61275,["boolge"]=61292,["boolgt"]=61290,["boolle"]=61282,["boollt"]=61284,["boolne"]=61269,["booluge"]=61308,["boolugt"]=61306,["boolule"]=61298,["boolult"]=61300,["bullet_render4"]=99584,["c_sp"]=66,["clip_left_found"]=1326,["decsp1"]=61070,["decsp2"]=61079,["decsp3"]=61092,["decsp4"]=61105,["decsp5"]=61118,["dispatch_nonzero"]=98752,["dma_finished"]=738,["dma_started"]=659,["fx4_build_skip"]=58368,["fx4_desc_count"]=58380,["fx4_dma_bytes"]=58376,["fx4_generation"]=58374,["fx4_half_bytes"]=58378,["fx4_page"]=58372,["fx4_wait_obj_blank"]=783,["fx_add_next_bounds"]=13567,["fx_audio_init"]=35940,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=35991,["fx_audio_sent"]=5653,["fx_build_obj"]=938,["fx_commit_dma"]=13567,["fx_dma_bytes"]=58918,["fx_dma_count"]=58916,["fx_dma_desc"]=58920,["fx_em1_open_sizes"]=58208,["fx_emit_native"]=15105,["fx_is_obj"]=890,["fx_latch_obj"]=1286,["fx_obj_build_done"]=1284,["fx_obj_count"]=58658,["fx_obj_dma_bytes"]=58664,["fx_obj_next"]=58386,["fx_obj_overflow"]=58662,["fx_obj_present"]=58522,["fx_obj_present_count"]=58660,["fx_obj_upload_done"]=1491,["fx_plan_dma"]=13548,["fx_project16"]=29372,["fx_read_gsu_spans"]=13493,["fx_reset_next_bounds"]=13567,["fx_sky_colors"]=16972,["fx_sky_colors_end"]=17056,["fx_sky_pointer"]=58690,["fx_upload_ground"]=1871,["fx_upload_obj"]=1332,["game_started"]=0,["generic"]=99536,["ground_done"]=1824,["ground_empty"]=1965,["gsu_uv_cache"]=99207,["half_dma_finished"]=665,["incsp1"]=61198,["incsp2"]=61213,["incsp3"]=61227,["incsp4"]=61232,["incsp5"]=61237,["incsp6"]=61242,["incsp7"]=61247,["incsp8"]=61252,["initialized"]=28493,["integer_render4"]=100384,["invoke_row"]=1370,["ldaidx"]=61257,["margin_render"]=99600,["math4_lift_result"]=881,["memcpy_getparams"]=61354,["memcpy_upwards"]=61316,["mulax10"]=61373,["mulax3"]=61398,["mulax5"]=61415,["mulax6"]=61435,["mulax7"]=61457,["negax"]=61486,["order"]=63857,["packet_done"]=28580,["packet_work"]=28,["player4_present"]=58668,["player4_upload_bytes"]=58672,["popax"]=61205,["popptr1"]=61500,["popsargsudiv16"]=61590,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=61536,["pusha"]=61518,["pusha0"]=61538,["pusha0sp"]=61514,["pushax"]=61540,["pushaysp"]=61516,["pushw0sp"]=61562,["pushwysp"]=61564,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=487,["render_second_finished"]=487,["render_second_started"]=487,["render_started"]=467,["render_stop"]=99754,["reset"]=32768,["row_done"]=1433,["sa1_clear_done"]=655,["sa1_clear_start"]=551,["sa1_compact"]=34993,["sa1_cover_row"]=34573,["sa1_draw_done"]=1461,["sa1_draw_start"]=674,["sa1_entry"]=512,["sa1_plan_dirty"]=33765,["sa1_prepare_transfer"]=34268,["sa1_select_cover"]=34423,["sa1_try_fast"]=34660,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=60983,["shlax3"]=60994,["shlax4"]=61008,["shrax1"]=61622,["shrax3"]=61630,["shrax4"]=61644,["sorted"]=28559,["sreg"]=68,["stage_update_done"]=60710,["staspidx"]=61661,["stax0sp"]=61683,["staxspidx"]=61694,["staxysp"]=61685,["subysp"]=61742,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=60924,["tosaddax"]=60926,["tosdiva0"]=61131,["tosdivax"]=61133,["tosicmp"]=61154,["tosicmp0"]=61152,["tossuba0"]=61721,["tossubax"]=61723,["tosudiva0"]=61755,["tosudivax"]=61757,["tosumoda0"]=61834,["tosumodax"]=61836,["udiv16"]=61772,["L1"]=61806,["@L1"]=61824,["Pos"]=61149,["@L3"]=61190,["@L4"]=61191,["@L2"]=61828,["L0"]=61782,["ret0"]=61271,["ret1"]=61277,["L3"]=61343,["done"]=61351,["L2"]=61615,["@L0"]=61813,["udiv16by8a"]=61813}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/play"
local maxframe=600
local scenario="play"
local padded=true
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local times={}
local presentationTimes={}
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local a=labels[name]+(cpu==emu.cpuType.snes and 0x7f0000 or 0)
 emu.addMemoryCallback(fn,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 if scenario=='boss' then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272)
end,emu.cpuType.sa1)
cb('dma_finished',function()
 presents=presents+1
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"clock":%d,"dmaBytes":%d}',field,emu.getState().masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory))
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  if padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  for _,a in ipairs({0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page})do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 if field==120 or field==maxframe then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if field==maxframe then
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
