local labels={["LoadAudioData"]=38553,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=39156,["Tad_GetSong"]=39260,["Tad_GlobalVolumesPersist"]=39288,["Tad_GlobalVolumesResetOnSongStart"]=39282,["Tad_Init"]=38772,["Tad_IsLoaderActive"]=39314,["Tad_IsSfxPlaying"]=39328,["Tad_IsSongLoaded"]=39322,["Tad_IsSongPlaying"]=39334,["Tad_LoadSong"]=39215,["Tad_LoadSongIfChanged"]=39248,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=38899,["Tad_QueueCommand"]=39172,["Tad_QueueCommandOverride"]=39177,["Tad_QueuePannedSoundEffect"]=39194,["Tad_QueueSoundEffect"]=39204,["Tad_ReloadCommonAudioData"]=39264,["Tad_SetTransferSize"]=39294,["Tad_SongsStartImmediately"]=39270,["Tad_SongsStartPaused"]=39276,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=45,["Tad_sfxQueue_sfx"]=44,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5859,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=63198,["__COLORBSS_LOAD__"]=1024,["__COLORBSS_RUN__"]=1024,["__COLORBSS_SIZE__"]=3720,["__DATA_LOAD__"]=12764155,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__SA1SORT_LOAD__"]=39807,["__SA1SORT_RUN__"]=1792,["__SA1SORT_SIZE__"]=68,["__SA1_LOAD__"]=39586,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=221,["__STARTUP__"]=1,["_abs"]=62829,["_boss_age"]=63731,["_boss_attribute_cache"]=63566,["_boss_attribute_cache_count"]=63728,["_boss_attribute_z_cache"]=63710,["_boss_dda_phase"]=63949,["_boss_dda_x"]=63955,["_boss_dda_y"]=63961,["_boss_death_parts"]=63733,["_boss_death_timer"]=63732,["_boss_fire_gap"]=63742,["_boss_fire_round"]=63739,["_boss_fire_shots"]=63741,["_boss_fire_state"]=63738,["_boss_fire_volley"]=63740,["_boss_history_x"]=63182,["_boss_history_y"]=63310,["_boss_history_z"]=63438,["_boss_last_vblank"]=63118,["_boss_motion_steps"]=63737,["_boss_part_active"]=63146,["_boss_part_bottom"]=63128,["_boss_part_fall_fraction"]=63173,["_boss_part_fall_velocity"]=63164,["_boss_part_timer"]=63155,["_boss_part_x"]=63119,["_boss_part_z"]=63137,["_boss_path_half"]=63736,["_boss_player_bottom"]=63745,["_boss_player_x"]=63743,["_boss_render_camera_delta"]=63729,["_boss_restart_timer"]=63734,["_boss_z_phase"]=63735,["_death_accel_fraction"]=63983,["_death_timer"]=63981,["_death_vy"]=63980,["_enemy_p0_samples"]=47713,["_enemy_p1_samples"]=48448,["_enemy_p2_samples"]=49153,["_enemy_p3_samples"]=49858,["_enemy_p4_samples"]=50563,["_enemy_p5_samples"]=51280,["_enemy_p6_samples"]=51997,["_enemy_p7_samples"]=52564,["_enemy_p8_samples"]=53131,["_fx4_explosion_lift"]=1897,["_fx_asset_bank"]=27546,["_fx_asset_height"]=27502,["_fx_asset_width"]=27458,["_fx_audio_events"]=5648,["_fx_boss_hits"]=13584,["_fx_boss_project"]=14158,["_fx_build_ground"]=2905,["_fx_build_packet"]=1983,["_fx_buttons"]=61340,["_fx_draw"]=59416,["_fx_draw_count"]=60056,["_fx_em0_geometry"]=16085,["_fx_enemy_collisions"]=15552,["_fx_enemy_em1_update"]=17304,["_fx_enemy_em1_update_reference"]=25973,["_fx_enemy_fire_em1"]=25911,["_fx_enemy_remove"]=25900,["_fx_enemy_render"]=16223,["_fx_enemy_render_bullets"]=16502,["_fx_far_d_acc"]=61352,["_fx_far_u_acc"]=61350,["_fx_fire_actions"]=61343,["_fx_frame"]=17598,["_fx_ground_c1ptr"]=63108,["_fx_ground_c3ptr"]=63110,["_fx_ground_camera"]=27590,["_fx_ground_color1"]=61359,["_fx_ground_color3"]=61809,["_fx_ground_depth_rows"]=27735,["_fx_ground_far_x"]=63074,["_fx_ground_far_xptr"]=63104,["_fx_ground_far_y"]=63114,["_fx_ground_greens"]=33081,["_fx_ground_horizon"]=63112,["_fx_ground_horizontal"]=62259,["_fx_ground_hptr"]=63069,["_fx_ground_native"]=2993,["_fx_ground_palette_record"]=63072,["_fx_ground_phase"]=61339,["_fx_ground_vptr"]=63106,["_fx_ground_width"]=33000,["_fx_ground_world_phase"]=63071,["_fx_init"]=18361,["_fx_input"]=61342,["_fx_open_size"]=59512,["_fx_packet"]=60059,["_fx_packet_count"]=60057,["_fx_present"]=334,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=33089,["_fx_stage_contact"]=61375,["_fx_stage_render"]=60665,["_fx_stage_update"]=61706,["_fx_submit"]=62059,["_ground_irq_vblank_count"]=61347,["_history_head"]=63730,["_hit_pending"]=61354,["_intro_timer"]=63984,["_legacy_enemy_fire_boss_at"]=24505,["_main"]=18398,["_memcpy"]=62660,["_monosh_bom_geometry"]=43346,["_monosh_boss_body_geometry"]=39089,["_monosh_boss_bom_depth_by_size"]=39533,["_monosh_boss_bom_geometry"]=39311,["_monosh_boss_bullet_velocity"]=39771,["_monosh_boss_draw_order_base"]=34547,["_monosh_boss_draw_order_mid"]=36707,["_monosh_boss_explosion_ground_bottom"]=39660,["_monosh_boss_explosion_scale_low"]=39549,["_monosh_boss_face_geometry"]=38867,["_monosh_boss_frame"]=18587,["_monosh_boss_hp"]=63117,["_monosh_boss_init"]=18430,["_monosh_boss_path_center_y"]=33587,["_monosh_boss_path_center_y_mid"]=34307,["_monosh_boss_path_x"]=33347,["_monosh_boss_path_x_mid"]=34067,["_monosh_boss_path_z"]=33107,["_monosh_boss_path_z_mid"]=33827,["_monosh_boss_prepare_fire"]=20486,["_monosh_boss_prepare_render"]=18623,["_monosh_boss_render_only"]=13938,["_monosh_boss_should_restart"]=18409,["_monosh_boss_state"]=63116,["_monosh_bullet_reflect_rng"]=63787,["_monosh_collision_bullet_bands"]=63779,["_monosh_combat_build_collision_bands"]=20668,["_monosh_combat_fast_cache_reset"]=15137,["_monosh_combat_fast_frame"]=14353,["_monosh_combat_fast_render"]=14483,["_monosh_combat_fast_render_cached"]=15144,["_monosh_combat_fire_cooldown"]=63788,["_monosh_combat_half_frame"]=63789,["_monosh_combat_init"]=20512,["_monosh_combat_reflect_bullet"]=14782,["_monosh_combat_render"]=20665,["_monosh_combat_update"]=20607,["_monosh_ebullet4_geometry"]=44153,["_monosh_ebullet_animation_geometry"]=43931,["_monosh_ebullet_geometry"]=44375,["_monosh_ebullet_velocity"]=44385,["_monosh_em1_animation_assets_ready"]=63944,["_monosh_em1_closed_geometry"]=43568,["_monosh_em1_open_geometry"]=43790,["_monosh_enemies"]=63793,["_monosh_enemy_active_count"]=21428,["_monosh_enemy_active_count_value"]=63791,["_monosh_enemy_bullet_count"]=63790,["_monosh_enemy_bullets"]=63873,["_monosh_enemy_camera_delta_cached"]=63942,["_monosh_enemy_collision_cursor"]=63947,["_monosh_enemy_draw_cache_valid"]=63945,["_monosh_enemy_em1_count"]=63943,["_monosh_enemy_em1_phase"]=63918,["_monosh_enemy_em1_shrink"]=63934,["_monosh_enemy_fast_advance"]=16896,["_monosh_enemy_fast_check_player_bullets"]=22518,["_monosh_enemy_fast_render"]=22003,["_monosh_enemy_fast_render_bullets"]=23468,["_monosh_enemy_fast_spawn_due"]=23844,["_monosh_enemy_fast_update_bullets"]=15222,["_monosh_enemy_fire_at"]=21440,["_monosh_enemy_fire_boss_at"]=21469,["_monosh_enemy_fire_em0_fast"]=24903,["_monosh_enemy_frame"]=21231,["_monosh_enemy_geometry"]=43124,["_monosh_enemy_ground_bottom"]=43820,["_monosh_enemy_half_frame"]=63946,["_monosh_enemy_init"]=21082,["_monosh_enemy_path_fire_frames"]=53743,["_monosh_enemy_path_frames"]=53734,["_monosh_enemy_paths"]=53698,["_monosh_enemy_player_hit"]=63948,["_monosh_enemy_render_only"]=21261,["_monosh_enemy_spawn_index"]=63915,["_monosh_enemy_spawn_wait"]=63916,["_monosh_enemy_spawns"]=53752,["_monosh_enemy_stage_complete"]=21434,["_monosh_enemy_stage_complete_flag"]=63792,["_monosh_ground_depth_pointer"]=61357,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=63971,["_monosh_player_bullet_count"]=63762,["_monosh_player_bullet_sizes"]=43099,["_monosh_player_bullets"]=63747,["_monosh_player_can_fire"]=27731,["_monosh_player_draw_asset"]=27747,["_monosh_player_draw_flags"]=27689,["_monosh_player_init"]=27626,["_monosh_player_invuln"]=63974,["_monosh_player_pose"]=63976,["_monosh_player_state"]=63973,["_monosh_player_stumble"]=63975,["_monosh_player_update"]=30079,["_monosh_player_update_reference"]=28956,["_monosh_player_world_active"]=27725,["_monosh_player_x"]=63969,["_monosh_project_x"]=30689,["_monosh_reflected_bullet_count"]=63778,["_monosh_reflected_bullets"]=63763,["_monosh_runtime_fire_actions"]=61344,["_monosh_runtime_frame_counter"]=61345,["_monosh_runtime_paused"]=61349,["_monosh_stage1_spawn_count"]=54894,["_monosh_stage1_spawns"]=53958,["_monosh_stage_collision_bullet_cursor"]=64223,["_monosh_stage_collision_bullet_index"]=64224,["_monosh_stage_contact_result"]=64221,["_monosh_stage_draw_cache_valid"]=64222,["_monosh_stage_frame"]=29231,["_monosh_stage_frame_counter"]=64085,["_monosh_stage_geometry"]=57560,["_monosh_stage_half_frame"]=64089,["_monosh_stage_hitbox_count"]=64219,["_monosh_stage_hitboxes"]=64091,["_monosh_stage_init"]=29196,["_monosh_stage_is_clear"]=29280,["_monosh_stage_lift"]=58349,["_monosh_stage_near_count"]=64090,["_monosh_stage_need_hitboxes"]=64220,["_monosh_stage_object_count"]=64083,["_monosh_stage_objects"]=63987,["_monosh_stage_render_only"]=29277,["_monosh_stage_spawn_index"]=64084,["_monosh_stage_spawn_wait"]=64087,["_monosh_stage_title_timer"]=63977,["_monosh_title_draw"]=18387,["_monosh_title_visible"]=58365,["_movement_fraction"]=63982,["_old_buttons"]=61355,["_player_flip"]=63985,["_player_fy"]=63978,["_player_run_phase"]=63986,["_pose_x_01"]=53896,["_pose_x_12"]=53915,["_pose_x_23"]=53934,["_stage_bom0_geometry"]=57116,["_stage_bush0_geometry"]=54896,["_stage_bush1_geometry"]=55340,["_stage_em0_geometry"]=56228,["_stage_flystone_geometry"]=55784,["_stage_lift_0"]=57572,["_stage_lift_1"]=57683,["_stage_lift_2"]=57794,["_stage_lift_3"]=57905,["_stage_lift_4"]=58016,["_stage_lift_5"]=58127,["_stage_lift_6"]=58238,["_stage_tree0_geometry"]=56672,["_v9968_copy_to_vram_linear"]=15138,["addeq0sp"]=62299,["addeqysp"]=62301,["addysp"]=62317,["addysp1"]=62316,["aslax2"]=62330,["aslax3"]=62341,["aslax4"]=62355,["asrax1"]=62372,["asrax2"]=62382,["asrax3"]=62397,["audio4_first_done"]=741,["audio4_second_done"]=741,["background_done"]=98722,["booleq"]=62622,["boolge"]=62639,["boolgt"]=62637,["boolle"]=62629,["boollt"]=62631,["boolne"]=62616,["booluge"]=62655,["boolugt"]=62653,["boolule"]=62645,["boolult"]=62647,["bullet_render4"]=99584,["c_sp"]=66,["clip_left_found"]=34234,["decsp1"]=62417,["decsp2"]=62426,["decsp3"]=62439,["decsp4"]=62452,["decsp5"]=62465,["dispatch_nonzero"]=98752,["dma_chunk_ready"]=1136,["dma_finished"]=1839,["dma_started"]=1241,["fast_base_ready"]=36743,["fast_fail"]=36785,["fast_tiles"]=36710,["fx4_build_skip"]=58368,["fx4_desc_count"]=58380,["fx4_dma_bytes"]=58376,["fx4_generation"]=58374,["fx4_half_bytes"]=58378,["fx4_page"]=58372,["fx4_wait_obj_blank"]=1876,["fx_add_next_bounds"]=15221,["fx_audio_init"]=39340,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=39391,["fx_audio_sent"]=5653,["fx_build_obj"]=2346,["fx_commit_dma"]=15221,["fx_dma_bytes"]=59286,["fx_dma_count"]=59284,["fx_dma_desc"]=59288,["fx_em1_open_sizes"]=59555,["fx_emit_native"]=16759,["fx_is_obj"]=2298,["fx_latch_obj"]=2694,["fx_obj_build_done"]=2692,["fx_obj_count"]=58992,["fx_obj_dma_bytes"]=58998,["fx_obj_next"]=58720,["fx_obj_overflow"]=58996,["fx_obj_present"]=58856,["fx_obj_present_count"]=58994,["fx_obj_upload_done"]=2903,["fx_plan_dma"]=15202,["fx_project16"]=30719,["fx_read_gsu_spans"]=15147,["fx_reset_next_bounds"]=15221,["fx_sky_colors"]=17006,["fx_sky_colors_end"]=17090,["fx_sky_pointer"]=59024,["fx_upload_ground"]=3324,["fx_upload_obj"]=2740,["game_started"]=0,["generic"]=99536,["ground_done"]=3277,["ground_empty"]=3418,["gsu_uv_cache"]=99207,["half_dma_finished"]=1247,["incsp1"]=62545,["incsp2"]=62560,["incsp3"]=62574,["incsp4"]=62579,["incsp5"]=62584,["incsp6"]=62589,["incsp7"]=62594,["incsp8"]=62599,["initialized"]=2051,["integer_render4"]=100384,["invoke_row"]=34278,["irq_game"]=33436,["keys"]=58592,["ldaidx"]=62604,["logic_finished"]=721,["margin_render"]=99600,["math4_lift_result"]=1974,["memcpy_getparams"]=62701,["memcpy_upwards"]=62663,["mulax10"]=62720,["mulax3"]=62745,["mulax5"]=62762,["mulax6"]=62782,["mulax7"]=62804,["negax"]=62833,["nmi_game"]=33458,["order"]=58464,["packet_done"]=2146,["packet_sort_attempts"]=59086,["packet_sort_jobs"]=59088,["packet_work"]=6,["pipe_bw_busy"]=58414,["pipe_collect"]=774,["pipe_complete"]=58410,["pipe_dma_measured_end"]=1268,["pipe_flip"]=1658,["pipe_front_slot"]=58404,["pipe_ground_extra"]=3584,["pipe_ground_extra_end"]=4744,["pipe_ground_wait"]=752,["pipe_irq"]=916,["pipe_irq_done"]=1369,["pipe_irq_exit"]=1392,["pipe_irq_transfer"]=938,["pipe_missed"]=58432,["pipe_obj_pointer"]=58454,["pipe_pending"]=58408,["pipe_presented_irq"]=58436,["pipe_records"]=1024,["pipe_render_slot"]=58402,["pipe_status"]=58420,["pipe_target_slot"]=58406,["pipe_wait_dma"]=974,["player4_next"]=59000,["player4_present"]=59002,["player4_upload_bytes"]=59006,["popax"]=62552,["popptr1"]=62847,["popsargsudiv16"]=62937,["prefetch_finished"]=1348,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=62883,["pusha"]=62865,["pusha0"]=62885,["pusha0sp"]=62861,["pushax"]=62887,["pushaysp"]=62863,["pushw0sp"]=62909,["pushwysp"]=62911,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=737,["render_second_finished"]=737,["render_second_started"]=737,["render_started"]=694,["render_stop"]=99754,["reset"]=32768,["row_done"]=34342,["sa1_clear_done"]=709,["sa1_clear_start"]=577,["sa1_compact"]=37332,["sa1_cover_row"]=36464,["sa1_dirty_done"]=588,["sa1_dma_begin"]=37821,["sa1_dma_end"]=37857,["sa1_dma_irq"]=38102,["sa1_dma_poll"]=37868,["sa1_draw_done"]=34366,["sa1_draw_rows"]=36787,["sa1_draw_start"]=728,["sa1_edge_cpu_restore"]=38330,["sa1_edge_cpu_save"]=38286,["sa1_edge_prepare"]=37040,["sa1_edge_restore"]=37237,["sa1_edge_save"]=37118,["sa1_entry"]=512,["sa1_fb_read"]=38090,["sa1_fb_write"]=38096,["sa1_find_shape"]=36207,["sa1_merge_dma"]=38400,["sa1_native_done"]=34366,["sa1_near_row"]=37492,["sa1_output_done"]=34374,["sa1_plan_dirty"]=34791,["sa1_prepare_transfer"]=35537,["sa1_select_cover"]=36314,["sa1_snapshot"]=37925,["sa1_sort_job"]=38154,["sa1_sprite_begin"]=33482,["sa1_sprite_done"]=34353,["sa1_tile_masks"]=35640,["sa1_tiles_clear"]=35772,["sa1_tiles_transfer"]=35787,["sa1_try_fast"]=36551,["sa1_try_packet_sort"]=13403,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=62330,["shlax3"]=62341,["shlax4"]=62355,["shrax1"]=62969,["shrax3"]=62977,["shrax4"]=62991,["sorted"]=2125,["sreg"]=68,["stage_update_done"]=62057,["staspidx"]=63008,["stax0sp"]=63030,["staxspidx"]=63041,["staxysp"]=63032,["subysp"]=63089,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=62271,["tosaddax"]=62273,["tosdiva0"]=62478,["tosdivax"]=62480,["tosicmp"]=62501,["tosicmp0"]=62499,["tossuba0"]=63068,["tossubax"]=63070,["tosudiva0"]=63102,["tosudivax"]=63104,["tosumoda0"]=63181,["tosumodax"]=63183,["transfer_chunk"]=1136,["udiv16"]=63119,["L1"]=63153,["@L1"]=63171,["Pos"]=62496,["@L3"]=62537,["@L4"]=62538,["@L2"]=63175,["L0"]=63129,["ret0"]=62618,["ret1"]=62624,["L3"]=62690,["done"]=62698,["L2"]=62962,["@L0"]=63160,["udiv16by8a"]=63160}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/offloadsort12"
local maxframe=600
local targetPresents=0
local scenario="offloadsort12"
local padded=false
local pipeline=true
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local completedPackets={}
local outputJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={17603},["_monosh_combat_fast_frame"]={17996},["_monosh_combat_render"]={18003},["_monosh_enemy_frame"]={18051},["_monosh_stage_frame"]={18073},["_monosh_boss_frame"]={18165},["_monosh_boss_prepare_render"]={18182},["_monosh_boss_render_only"]={18187,18206},["_fx_build_packet"]={18353},["_fx_build_ground"]={18356}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local irqName=name:match('^pipe_') or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(cpu==emu.cpuType.snes and (irqName and 0x7f0000 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
local packetClock,irqTicks,irqClock=0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 cb('pipe_irq',function()irqClock=emu.getState().masterClock end)
 cb('pipe_irq_exit',function()irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank-0x40)*65536+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()
  local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,5-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_sort_packet or labels.sa1_temporal_prepare then
 cb(labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare',function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability')end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock end)end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs')end
   for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
