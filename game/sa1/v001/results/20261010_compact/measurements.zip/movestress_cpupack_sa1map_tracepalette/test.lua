local labels={["LoadAudioData"]=63899,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64502,["Tad_GetSong"]=64606,["Tad_GlobalVolumesPersist"]=64634,["Tad_GlobalVolumesResetOnSongStart"]=64628,["Tad_Init"]=64118,["Tad_IsLoaderActive"]=64660,["Tad_IsSfxPlaying"]=64674,["Tad_IsSongLoaded"]=64668,["Tad_IsSongPlaying"]=64680,["Tad_LoadSong"]=64561,["Tad_LoadSongIfChanged"]=64594,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=64245,["Tad_QueueCommand"]=64518,["Tad_QueueCommandOverride"]=64523,["Tad_QueuePannedSoundEffect"]=64540,["Tad_QueueSoundEffect"]=64550,["Tad_ReloadCommonAudioData"]=64610,["Tad_SetTransferSize"]=64640,["Tad_SongsStartImmediately"]=64616,["Tad_SongsStartPaused"]=64622,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=48,["Tad_sfxQueue_sfx"]=47,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5951,["__BULLETJIT_LOAD__"]=98304,["__BULLETJIT_RUN__"]=768,["__BULLETJIT_SIZE__"]=362,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=64991,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=9436,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__DIRTYJIT_LOAD__"]=98666,["__DIRTYJIT_RUN__"]=768,["__DIRTYJIT_SIZE__"]=316,["__LEFTJIT_LOAD__"]=98982,["__LEFTJIT_RUN__"]=768,["__LEFTJIT_SIZE__"]=351,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=64932,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=207,["__STARTUP__"]=1,["_abs"]=64622,["_boss_age"]=40455,["_boss_attribute_cache"]=40290,["_boss_attribute_cache_count"]=40452,["_boss_attribute_z_cache"]=40434,["_boss_dda_phase"]=40673,["_boss_dda_x"]=40679,["_boss_dda_y"]=40685,["_boss_death_parts"]=40457,["_boss_death_timer"]=40456,["_boss_fire_gap"]=40466,["_boss_fire_round"]=40463,["_boss_fire_shots"]=40465,["_boss_fire_state"]=40462,["_boss_fire_volley"]=40464,["_boss_history_x"]=39906,["_boss_history_y"]=40034,["_boss_history_z"]=40162,["_boss_last_vblank"]=39842,["_boss_motion_steps"]=40461,["_boss_part_active"]=39870,["_boss_part_bottom"]=39852,["_boss_part_fall_fraction"]=39897,["_boss_part_fall_velocity"]=39888,["_boss_part_timer"]=39879,["_boss_part_x"]=39843,["_boss_part_z"]=39861,["_boss_path_half"]=40460,["_boss_player_bottom"]=40469,["_boss_player_x"]=40467,["_boss_render_camera_delta"]=40453,["_boss_restart_timer"]=40458,["_boss_z_phase"]=40459,["_death_accel_fraction"]=40707,["_death_timer"]=40705,["_death_vy"]=40704,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=3234,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=15377,["_fx_boss_project"]=15951,["_fx_build_ground"]=4248,["_fx_build_packet"]=3320,["_fx_buttons"]=38064,["_fx_draw"]=36140,["_fx_draw_count"]=36780,["_fx_em0_geometry"]=17878,["_fx_enemy_collisions"]=17345,["_fx_enemy_em1_update"]=19097,["_fx_enemy_em1_update_reference"]=27766,["_fx_enemy_fire_em1"]=27704,["_fx_enemy_remove"]=27693,["_fx_enemy_render"]=18016,["_fx_enemy_render_bullets"]=18295,["_fx_far_d_acc"]=38076,["_fx_far_u_acc"]=38074,["_fx_fire_actions"]=38067,["_fx_frame"]=19391,["_fx_ground_c1ptr"]=39832,["_fx_ground_c3ptr"]=39834,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38083,["_fx_ground_color3"]=38533,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39798,["_fx_ground_far_xptr"]=39828,["_fx_ground_far_y"]=39838,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39836,["_fx_ground_horizontal"]=38983,["_fx_ground_hptr"]=39793,["_fx_ground_native"]=4336,["_fx_ground_palette_record"]=39796,["_fx_ground_phase"]=38063,["_fx_ground_vptr"]=39830,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39795,["_fx_init"]=20154,["_fx_input"]=38066,["_fx_open_size"]=61305,["_fx_packet"]=36783,["_fx_packet_count"]=36781,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=63168,["_fx_stage_render"]=62458,["_fx_stage_update"]=63499,["_fx_submit"]=63852,["_ground_irq_vblank_count"]=38071,["_history_head"]=40454,["_hit_pending"]=38078,["_intro_timer"]=40708,["_legacy_enemy_fire_boss_at"]=26298,["_main"]=20191,["_memcpy"]=64453,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59579,["_monosh_boss_draw_order_mid"]=61739,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=20380,["_monosh_boss_hp"]=39841,["_monosh_boss_init"]=20223,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=22279,["_monosh_boss_prepare_render"]=20416,["_monosh_boss_render_only"]=15731,["_monosh_boss_should_restart"]=20202,["_monosh_boss_state"]=39840,["_monosh_bullet_reflect_rng"]=40511,["_monosh_collision_bullet_bands"]=40503,["_monosh_combat_build_collision_bands"]=22461,["_monosh_combat_fast_cache_reset"]=16930,["_monosh_combat_fast_frame"]=16146,["_monosh_combat_fast_render"]=16276,["_monosh_combat_fast_render_cached"]=16937,["_monosh_combat_fire_cooldown"]=40512,["_monosh_combat_half_frame"]=40513,["_monosh_combat_init"]=22305,["_monosh_combat_reflect_bullet"]=16575,["_monosh_combat_render"]=22458,["_monosh_combat_update"]=22400,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40668,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40517,["_monosh_enemy_active_count"]=23221,["_monosh_enemy_active_count_value"]=40515,["_monosh_enemy_bullet_count"]=40514,["_monosh_enemy_bullets"]=40597,["_monosh_enemy_camera_delta_cached"]=40666,["_monosh_enemy_collision_cursor"]=40671,["_monosh_enemy_draw_cache_valid"]=40669,["_monosh_enemy_em1_count"]=40667,["_monosh_enemy_em1_phase"]=40642,["_monosh_enemy_em1_shrink"]=40658,["_monosh_enemy_fast_advance"]=18689,["_monosh_enemy_fast_check_player_bullets"]=24311,["_monosh_enemy_fast_render"]=23796,["_monosh_enemy_fast_render_bullets"]=25261,["_monosh_enemy_fast_spawn_due"]=25637,["_monosh_enemy_fast_update_bullets"]=17015,["_monosh_enemy_fire_at"]=23233,["_monosh_enemy_fire_boss_at"]=23262,["_monosh_enemy_fire_em0_fast"]=26696,["_monosh_enemy_frame"]=23024,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40670,["_monosh_enemy_init"]=22875,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40672,["_monosh_enemy_render_only"]=23054,["_monosh_enemy_spawn_index"]=40639,["_monosh_enemy_spawn_wait"]=40640,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=23227,["_monosh_enemy_stage_complete_flag"]=40516,["_monosh_ground_depth_pointer"]=38081,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40695,["_monosh_player_bullet_count"]=40486,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40471,["_monosh_player_can_fire"]=29524,["_monosh_player_draw_asset"]=29540,["_monosh_player_draw_flags"]=29482,["_monosh_player_init"]=29419,["_monosh_player_invuln"]=40698,["_monosh_player_pose"]=40700,["_monosh_player_state"]=40697,["_monosh_player_stumble"]=40699,["_monosh_player_update"]=31872,["_monosh_player_update_reference"]=30749,["_monosh_player_world_active"]=29518,["_monosh_player_x"]=40693,["_monosh_project_x"]=32482,["_monosh_reflected_bullet_count"]=40502,["_monosh_reflected_bullets"]=40487,["_monosh_runtime_fire_actions"]=38068,["_monosh_runtime_frame_counter"]=38069,["_monosh_runtime_paused"]=38073,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40947,["_monosh_stage_collision_bullet_index"]=40948,["_monosh_stage_contact_result"]=40945,["_monosh_stage_draw_cache_valid"]=40946,["_monosh_stage_frame"]=31024,["_monosh_stage_frame_counter"]=40809,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40813,["_monosh_stage_hitbox_count"]=40943,["_monosh_stage_hitboxes"]=40815,["_monosh_stage_init"]=30989,["_monosh_stage_is_clear"]=31073,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40814,["_monosh_stage_need_hitboxes"]=40944,["_monosh_stage_object_count"]=40807,["_monosh_stage_objects"]=40711,["_monosh_stage_render_only"]=31070,["_monosh_stage_spawn_index"]=40808,["_monosh_stage_spawn_wait"]=40811,["_monosh_stage_title_timer"]=40701,["_monosh_title_draw"]=20180,["_monosh_title_visible"]=34997,["_movement_fraction"]=40706,["_old_buttons"]=38079,["_player_flip"]=40709,["_player_fy"]=40702,["_player_run_phase"]=40710,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=16931,["addeq0sp"]=64092,["addeqysp"]=64094,["addysp"]=64110,["addysp1"]=64109,["aslax2"]=64123,["aslax3"]=64134,["aslax4"]=64148,["asrax1"]=64165,["asrax2"]=64175,["asrax3"]=64190,["audio4_first_done"]=798,["audio4_second_done"]=798,["background_done"]=111506,["booleq"]=64415,["boolge"]=64432,["boolgt"]=64430,["boolle"]=64422,["boollt"]=64424,["boolne"]=64409,["booluge"]=64448,["boolugt"]=64446,["boolule"]=64438,["boolult"]=64440,["bullet_render4"]=112368,["c_sp"]=69,["clip_left_found"]=34354,["decsp1"]=64210,["decsp2"]=64219,["decsp3"]=64232,["decsp4"]=64245,["decsp5"]=64258,["dispatch_nonzero"]=111536,["dma_chunk_ready"]=1255,["dma_finished"]=2278,["dma_started"]=1523,["fast_base_ready"]=36860,["fast_fail"]=36909,["fast_tiles"]=36827,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=3213,["fx_add_next_bounds"]=17014,["fx_audio_init"]=64686,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64737,["fx_audio_sent"]=5653,["fx_build_obj"]=3686,["fx_commit_dma"]=17014,["fx_dma_bytes"]=36010,["fx_dma_count"]=36008,["fx_dma_desc"]=36012,["fx_em1_open_sizes"]=61348,["fx_emit_native"]=18552,["fx_is_obj"]=3638,["fx_latch_obj"]=4034,["fx_obj_build_done"]=4032,["fx_obj_count"]=35670,["fx_obj_dma_bytes"]=35676,["fx_obj_next"]=35398,["fx_obj_overflow"]=35674,["fx_obj_present"]=35534,["fx_obj_present_count"]=35672,["fx_obj_upload_done"]=4246,["fx_plan_dma"]=16995,["fx_project16"]=32512,["fx_read_gsu_spans"]=16940,["fx_reset_next_bounds"]=17014,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35702,["fx_upload_ground"]=4606,["fx_upload_obj"]=4080,["game_started"]=0,["generic"]=112320,["ground_done"]=4559,["ground_empty"]=4700,["gsu_uv_cache"]=111991,["half_dma_finished"]=1529,["incsp1"]=64338,["incsp2"]=64353,["incsp3"]=64367,["incsp4"]=64372,["incsp5"]=64377,["incsp6"]=64382,["incsp7"]=64387,["incsp8"]=64392,["initialized"]=3388,["integer_render4"]=113168,["invoke_row"]=34398,["irq_game"]=33470,["keys"]=35270,["ldaidx"]=64397,["logic_finished"]=775,["margin_render"]=112384,["math4_lift_result"]=3311,["memcpy_getparams"]=64494,["memcpy_upwards"]=64456,["mulax10"]=64513,["mulax3"]=64538,["mulax5"]=64555,["mulax6"]=64575,["mulax7"]=64597,["negax"]=64626,["nmi_game"]=33506,["order"]=35142,["packet_done"]=3486,["packet_work"]=6,["pipe_available"]=35096,["pipe_bw_busy"]=35046,["pipe_collect"]=841,["pipe_complete"]=35042,["pipe_dma_chunk"]=35106,["pipe_dma_measured_end"]=1550,["pipe_fast_begin"]=2020,["pipe_fast_done"]=2081,["pipe_fast_unavailable"]=2089,["pipe_flip"]=2091,["pipe_front_slot"]=35036,["pipe_ground_extra"]=45056,["pipe_ground_extra_end"]=47956,["pipe_ground_wait"]=814,["pipe_irq"]=1020,["pipe_irq_checked"]=1646,["pipe_irq_done"]=1638,["pipe_irq_exit"]=1657,["pipe_irq_transfer"]=1042,["pipe_main_offset"]=35088,["pipe_missed"]=35078,["pipe_near_build"]=14821,["pipe_near_prepare_next"]=14715,["pipe_near_prepared"]=35812,["pipe_near_present"]=35810,["pipe_near_select"]=15158,["pipe_next_slot"]=35090,["pipe_obj_pointer"]=35102,["pipe_pending"]=35040,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_stage_convert"]=2631,["pipe_stage_done"]=3173,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_wait_dma"]=1051,["pipe_write_slot"]=35030,["player4_next"]=35678,["player4_present"]=35680,["player4_upload_bytes"]=35684,["player4_uploaded"]=35682,["popax"]=64345,["popptr1"]=64640,["popsargsudiv16"]=64730,["prefetch_finished"]=1630,["ptr1"]=77,["ptr2"]=79,["ptr3"]=81,["ptr4"]=83,["push0"]=64676,["pusha"]=64658,["pusha0"]=64678,["pusha0sp"]=64654,["pushax"]=64680,["pushaysp"]=64656,["pushw0sp"]=64702,["pushwysp"]=64704,["regbank"]=89,["regsave"]=73,["render_entry"]=111088,["render_finished"]=794,["render_second_finished"]=794,["render_second_started"]=794,["render_started"]=748,["render_stop"]=112538,["reset"]=32768,["row_done"]=34462,["sa1_background_cache"]=57960,["sa1_background_initialize"]=58278,["sa1_bullet_cache_init"]=100691,["sa1_bullet_cache_prepare"]=100692,["sa1_clear_done"]=695,["sa1_clear_start"]=526,["sa1_clear_wide_band"]=59043,["sa1_compact"]=37517,["sa1_cover_row"]=36547,["sa1_deep_rebase"]=57925,["sa1_dirty_done"]=546,["sa1_dirty_iram_load"]=100624,["sa1_dirty_row_rect"]=35717,["sa1_dirty_rows"]=768,["sa1_dma_begin"]=57088,["sa1_dma_end"]=57124,["sa1_dma_irq"]=57369,["sa1_dma_poll"]=57135,["sa1_dma_try_begin"]=57054,["sa1_draw_done"]=34486,["sa1_draw_rows"]=36911,["sa1_draw_start"]=714,["sa1_edge_cpu_restore"]=58602,["sa1_edge_cpu_save"]=58558,["sa1_edge_prepare"]=37176,["sa1_edge_restore"]=37400,["sa1_edge_save"]=37258,["sa1_entry"]=512,["sa1_fb_read"]=57357,["sa1_fb_write"]=57363,["sa1_find_shape"]=36288,["sa1_ground_compiled"]=15331,["sa1_left_hint_draw"]=102830,["sa1_list_sort"]=15181,["sa1_merge_dma"]=59426,["sa1_native_done"]=34486,["sa1_near_patch"]=58487,["sa1_near_patch_bounds"]=58401,["sa1_near_row"]=37677,["sa1_occupancy_capture"]=57421,["sa1_output_done"]=34498,["sa1_plan_dirty"]=34900,["sa1_prepare_transfer"]=35614,["sa1_select_cover"]=36397,["sa1_small_edge_prepare"]=58867,["sa1_small_edge_restore"]=59032,["sa1_small_edge_save"]=59021,["sa1_snapshot"]=57192,["sa1_sparse_map_prepare"]=101194,["sa1_sprite_begin"]=33588,["sa1_sprite_done"]=34473,["sa1_stack_clear_band"]=59105,["sa1_stack_clear_line"]=59280,["sa1_stack_clear_prepare"]=59088,["sa1_tile_masks"]=35721,["sa1_tiles_clear"]=35853,["sa1_tiles_transfer"]=35868,["sa1_transfer_mask_capture"]=57654,["sa1_transfer_mask_prepare"]=57709,["sa1_try_fast"]=36634,["scaled_render4"]=112896,["scaled_unpacked4"]=113056,["shlax2"]=64123,["shlax3"]=64134,["shlax4"]=64148,["shrax1"]=64762,["shrax3"]=64770,["shrax4"]=64784,["sorted"]=3465,["sreg"]=71,["stage_busy"]=35120,["stage_converted"]=3026,["stage_record"]=35122,["stage_time_ok"]=2806,["stage_too_large"]=3176,["stage_update_done"]=63850,["staspidx"]=64801,["stax0sp"]=64823,["staxspidx"]=64834,["staxysp"]=64825,["subysp"]=64882,["tmp1"]=85,["tmp2"]=86,["tmp3"]=87,["tmp4"]=88,["tosadda0"]=64064,["tosaddax"]=64066,["tosdiva0"]=64271,["tosdivax"]=64273,["tosicmp"]=64294,["tosicmp0"]=64292,["tossuba0"]=64861,["tossubax"]=64863,["tosudiva0"]=64895,["tosudivax"]=64897,["tosumoda0"]=64974,["tosumodax"]=64976,["transfer_chunk"]=1255,["udiv16"]=64912,["L1"]=64946,["@L1"]=64964,["Pos"]=64289,["@L3"]=64330,["@L4"]=64331,["@L2"]=64968,["L0"]=64922,["ret0"]=64411,["ret1"]=64417,["L3"]=64483,["done"]=64491,["L2"]=64755,["@L0"]=64953,["udiv16by8a"]=64953}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/movestress_cpupack_sa1map_tracepalette"
local maxframe=800
local targetPresents=0
local scenario="movestress_cpupack_sa1map_tracepalette"
local padded=false
local pipeline=true
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local finishedCapture=false
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local pageCommit=nil
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local expectedPalette={0,0,154,119,254,82,94,10,101,15,113,55,83,90,141,61,1,6,74,38,76,8,53,0,0,4,55,101,109,97,120,45}
if scenario:match('tracepalette') then
 local z=assert(io.open(output..'/palette_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  if field>90 then
   local s=emu.getState()
   z:write(string.format('{"field":%d,"line":%d,"hclock":%d,"address":%d,"value":%d,"cgadd":%d,"pc":%d}\n',field,s['ppu.scanline'],s['memoryManager.hClock'],address,value,s['ppu.cgramAddress'],s['cpu.pc']));z:flush()
  end
 end,emu.callbackType.write,32,63,emu.cpuType.snes,emu.memType.snesCgRam)
end
if scenario:match('tracedma') then
 local z=assert(io.open(output..'/sa1_dma_writes.jsonl','w'))
 local blankLog=assert(io.open(output..'/blank_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local st=emu.getState()
  blankLog:write(string.format('{"field":%d,"line":%d,"value":%d,"pc":%d,"hdmaAddress":%d,"hdmaCount":%d}\n',field,st['ppu.scanline'],value,st['cpu.pc'],st['dmaController.channel[1].hdmaTableAddress'],st['dmaController.channel[1].hdmaLineCounterAndRepeat']));blankLog:flush()
 end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
 local reads=assert(io.open(output..'/cpu_dma_reads.jsonl','w'));local readCount=0
 emu.addMemoryCallback(function(address,value)
  if presents==0 and emu.read16(0x311e,emu.memType.snesMemory)==1 and readCount<800 then
   readCount=readCount+1;local s=emu.getState()
   reads:write(string.format('{"address":%d,"value":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',address,value,s['cart.coprocessor.dmaSrcAddr'],s['cart.coprocessor.dmaDestAddr'],tostring(s['cart.coprocessor.charConvDmaActive']),tostring(s['ppu.forcedBlank']),s['ppu.scanline']));reads:flush()
  end
 end,emu.callbackType.read,0x400000,0x43ffff,emu.cpuType.snes,emu.memType.snesMemory)
 emu.addMemoryCallback(function(address,value)
  if emu.read16(0x11e,emu.memType.sa1Memory)==1 then
   local s=emu.getState()
   z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,emu.memType.sa1Memory),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
  end
 end,emu.callbackType.write,0x2230,0x2239,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local cpuStageJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={19396},["_monosh_combat_fast_frame"]={19789},["_monosh_combat_render"]={19796},["_monosh_enemy_frame"]={19844},["_monosh_stage_frame"]={19866},["_monosh_boss_frame"]={19958},["_monosh_boss_prepare_render"]={19975},["_monosh_boss_render_only"]={19980,19999},["_fx_build_packet"]={20146},["_fx_build_ground"]={20149}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local irqName=name:match('^pipe_') or name=='stage_time_ok' or name=='stage_converted' or name=='stage_too_large' or name=='fx_obj_upload_done' or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(cpu==emu.cpuType.snes and labels[name]<65536 and (irqName and 12648448 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()if finishedCapture then return end;local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
emu.addMemoryCallback(function(address,value)
 local line=emu.getState()['ppu.scanline']
 if field>85 and (line>=203 or line<21) and line<225 and (value&0x80)==0 then
  local f=assert(io.open(output..'/failure.txt','w'));f:write('HDMA unblanked reserved DMA lines field='..field..' line='..line);f:close();emu.stop(1)
 end
end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
-- VRAM/OAM?????????????????VBLANK???????
emu.addMemoryCallback(function(address,value)
 if field>90 and (value&1)~=0 then
  local bb=emu.read(0x4301,emu.memType.snesMemory)
  if bb==0x18 or bb==4 then
   local st=emu.getState()
   if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('VRAM/OAM DMA started outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
   end
  end
 end
end,emu.callbackType.write,0x420b,0x420b,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(function(address,value)
 if field>90 then
  local st=emu.getState()
  if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write('BG1 page changed outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
  end
  pageCommit={field=field,line=st['ppu.scanline'],clock=st.masterClock}
 end
end,emu.callbackType.write,0x210b,0x210b,emu.cpuType.snes,emu.memType.snesMemory)
local packetClock,irqTicks,irqClock=0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 cb('pipe_irq',function()irqClock=emu.getState().masterClock end)
 cb('pipe_irq_exit',function()irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  if true then return end
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb(labels.pipe_irq_checked and 'pipe_irq_checked' or 'pipe_irq_done',function()
  -- IRQ�����̃L���[�Ǘ��͕\���������s�ł���BPPU�̎��]���E�ؑֈʒu��ʁX�Ɍ�������B
  local line=emu.getState()['ppu.scanline']
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_list_sort or labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_list_sort and 'sa1_list_sort' or labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.stage_too_large then cb('stage_too_large',function()error('compact WRAM staging capacity exceeded field='..field)end)end
if labels.stage_time_ok then
 local started=0;local bytes=0;local count=0;local line=0
 cb('stage_time_ok',function()
  local st=emu.getState();local mt=emu.memType.snesMemory
  local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.stage_record,mt)
  started=st.masterClock;line=st['ppu.scanline'];bytes=emu.read16(record+34,mt);count=emu.read16(record+2,mt)//6
 end)
 cb('stage_converted',function()
  local st=emu.getState()
  cpuStageJobs[#cpuStageJobs+1]=string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}',field,bytes,count,line,st['ppu.scanline'],(st.masterClock-started)/21477.272)
 end)
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
if labels.cache_miss then
 local f=assert(io.open(output..'/bullet_cache.jsonl','w'));local start=0;local missed=false
 cb('sa1_bullet_cache_prepare',function()start=emu.getState().masterClock;missed=false end,emu.cpuType.sa1)
 cb('cache_miss',function()missed=true end,emu.cpuType.sa1)
 cb('cache_ready',function()
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"field":%d,"asset":%d,"width":%d,"height":%d,"flags":%d,"miss":%s,"ms":%.6f}\n',#times+1,field,emu.read16(0x3e,mt),emu.read16(0x34,mt),emu.read16(0x36,mt),emu.read16(0x3c,mt),missed and 'true' or 'false',(emu.getState().masterClock-start)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 if scenario:match('^leftfixture') then
  local geometries={{0,90,48},{3,90,47},{0,93,50},{3,93,49},{0,97,52},{3,96,51},{0,104,55},{3,100,53},{0,107,57},{3,103,55},{0,114,61},{3,110,58}}
  local centers={-40,0,16,30,64,128,250}
  local bottoms={40,120,205}
  word('_fx_packet_count',2)
  for i=1,2 do
   local g=geometries[math.floor((logic-1)/7)*2%#geometries+i]
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[(logic+i-2)%#centers+1]&65535,mt)
   emu.write16(a+2,bottoms[math.floor((logic-1)/#centers)%#bottoms+1],mt)
   emu.write(a+4,g[2],mt);emu.write(a+5,g[3],mt);emu.write(a+6,g[1],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^flipfixture') then
  local assets={6,7,8,37};local sizes={6,16,32,48,62}
  local size=sizes[math.floor((logic-1)/12)%5+1]
  local flags=(math.floor((logic-1)/3)%4)*16+(logic-1)%3
  local centers={-2,254,128,64};local bottoms={120,200,30,160}
  word('_fx_packet_count',4)
  for i=1,4 do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[i]&65535,mt);emu.write16(a+2,bottoms[i],mt)
   emu.write(a+4,size,mt);emu.write(a+5,size,mt);emu.write(a+6,assets[i],mt);emu.write(a+7,flags,mt)
   emu.write16(a+8,0,mt)
  end
 end
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if true and (gen<=120 or gen%60==0) then
   local bank=emu.read16(0x102,mt);local base=emu.read16(0x19a,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank&255)*65536+base+i,mt))end
   completedFrames[gen]=table.concat(t)
  end
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 local rejectedLog=assert(io.open(output..'/rejected_dma.jsonl','w'))
 cb('pipe_fast_unavailable',function()
  local mt=emu.memType.snesMemory;local base=0x7e0000
  local record=base+labels.pipe_records+emu.read16(base+labels.pipe_record_offset,mt)
  rejectedLog:write(string.format('{"field":%d,"gen":%d,"bytes":%d,"count":%d,"cost":%d,"available":%d}\n',field,emu.read16(record+8,mt),emu.read16(record+34,mt),(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6,emu.read16(base+labels.pipe_dma_chunk,mt),emu.read16(base+labels.pipe_available,mt)));rejectedLog:flush()
 end)
 cb('pipe_fast_begin',function()
  local st=emu.getState();assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA began outside actual blank period')
  if scenario:match('tracedma') then
   local st=emu.getState();local f=assert(io.open(output..'/cc_state.jsonl','a'))
   f:write(string.format('{"field":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',field,st['cart.coprocessor.dmaSrcAddr'],st['cart.coprocessor.dmaDestAddr'],tostring(st['cart.coprocessor.charConvDmaActive']),tostring(st['ppu.forcedBlank']),st['ppu.scanline']));f:close()
   if presents==0 then
    local f=assert(io.open(output..'/before_dma_bw.bin','wb'));local a={}
    for i=0,24575 do a[#a+1]=string.char(emu.read(1024+i,emu.memType.snesSaveRam))end
    f:write(table.concat(a));f:close()
   end
  end
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA ended outside actual blank period')
  if scenario:match('tracedma') and presents==0 then
   local f=assert(io.open(output..'/beforeflip_vram.bin','wb'));local a={}
   for i=0,65535 do a[#a+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
   f:write(table.concat(a));f:close()
  end
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.fx_obj_upload_done then cb('fx_obj_upload_done',function()
 if field>90 then
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'OAM DMA ended outside actual blank period')
 end
end)end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock;pageCommit=nil end)end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=(pageCommit and pageCommit.line) or state['ppu.scanline']
 local commitField=(pageCommit and pageCommit.field) or field
 local visibleField=commitField+(line>=203 and line<225 and 1 or 0)
 assert(line<=21 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   if true then dump(n..'_ground_h.bin',emu.memType.snesMemory,0x7e0000+emu.read16(record+26,mt),270)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs field='..field..' gen='..presents..' byte='..i..' actual='..emu.read(i,emu.memType.snesSpriteRam)..' expected='..emu.read(record+64+i,mt))end
   if true then
    local expected=emu.read16(record+192,mt)|0x0aaa
    local actual=emu.read16(512,emu.memType.snesSpriteRam)
    assert((actual&0x0fff)==(expected&0x0fff),'player high OAM differs')
    dump(n..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    dump(n..'_palette.bin',emu.memType.snesCgRam,0,512)
   else
    for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 if true and field>90 then
  for i=0,31 do
   local fx=emu.read(32+i,emu.memType.snesCgRam)
   local near=emu.read(480+i,emu.memType.snesCgRam)
   if fx~=expectedPalette[i+1] or near~=expectedPalette[i+1] then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('CGRAM changed field='..field..' byte='..i..' fx='..fx..' near='..near..' expected='..expectedPalette[i+1]);f:close();emu.stop(1);return
   end
  end
 end
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if finished then
  local f=assert(io.open(output..'/final_state.txt','w'));for k,v in pairs(emu.getState())do f:write(tostring(k)..'='..tostring(v)..'\n')end;f:close()
 end
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  finishedCapture=true
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s],"cpuStageJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,','),table.concat(cpuStageJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
