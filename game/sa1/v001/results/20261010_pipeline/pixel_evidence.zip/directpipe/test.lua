local labels={["LoadAudioData"]=37070,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=37673,["Tad_GetSong"]=37777,["Tad_GlobalVolumesPersist"]=37805,["Tad_GlobalVolumesResetOnSongStart"]=37799,["Tad_Init"]=37289,["Tad_IsLoaderActive"]=37831,["Tad_IsSfxPlaying"]=37845,["Tad_IsSongLoaded"]=37839,["Tad_IsSongPlaying"]=37851,["Tad_LoadSong"]=37732,["Tad_LoadSongIfChanged"]=37765,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=37416,["Tad_QueueCommand"]=37689,["Tad_QueueCommandOverride"]=37694,["Tad_QueuePannedSoundEffect"]=37711,["Tad_QueueSoundEffect"]=37721,["Tad_ReloadCommonAudioData"]=37781,["Tad_SetTransferSize"]=37811,["Tad_SongsStartImmediately"]=37787,["Tad_SongsStartPaused"]=37793,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=45,["Tad_sfxQueue_sfx"]=44,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5815,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62608,["__COLORBSS_LOAD__"]=1024,["__COLORBSS_RUN__"]=1024,["__COLORBSS_SIZE__"]=1536,["__DATA_LOAD__"]=12764155,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__SA1_LOAD__"]=38103,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=800,["__STARTUP__"]=1,["_abs"]=62239,["_boss_age"]=63687,["_boss_attribute_cache"]=63522,["_boss_attribute_cache_count"]=63684,["_boss_attribute_z_cache"]=63666,["_boss_dda_phase"]=63905,["_boss_dda_x"]=63911,["_boss_dda_y"]=63917,["_boss_death_parts"]=63689,["_boss_death_timer"]=63688,["_boss_fire_gap"]=63698,["_boss_fire_round"]=63695,["_boss_fire_shots"]=63697,["_boss_fire_state"]=63694,["_boss_fire_volley"]=63696,["_boss_history_x"]=63138,["_boss_history_y"]=63266,["_boss_history_z"]=63394,["_boss_last_vblank"]=63074,["_boss_motion_steps"]=63693,["_boss_part_active"]=63102,["_boss_part_bottom"]=63084,["_boss_part_fall_fraction"]=63129,["_boss_part_fall_velocity"]=63120,["_boss_part_timer"]=63111,["_boss_part_x"]=63075,["_boss_part_z"]=63093,["_boss_path_half"]=63692,["_boss_player_bottom"]=63701,["_boss_player_x"]=63699,["_boss_render_camera_delta"]=63685,["_boss_restart_timer"]=63690,["_boss_z_phase"]=63691,["_death_accel_fraction"]=63939,["_death_timer"]=63937,["_death_vy"]=63936,["_enemy_p0_samples"]=47713,["_enemy_p1_samples"]=48448,["_enemy_p2_samples"]=49153,["_enemy_p3_samples"]=49858,["_enemy_p4_samples"]=50563,["_enemy_p5_samples"]=51280,["_enemy_p6_samples"]=51997,["_enemy_p7_samples"]=52564,["_enemy_p8_samples"]=53131,["_fx4_explosion_lift"]=1520,["_fx_asset_bank"]=27546,["_fx_asset_height"]=27502,["_fx_asset_width"]=27458,["_fx_audio_events"]=5648,["_fx_boss_hits"]=12994,["_fx_boss_project"]=13568,["_fx_build_ground"]=2516,["_fx_build_packet"]=1606,["_fx_buttons"]=61296,["_fx_draw"]=59372,["_fx_draw_count"]=60012,["_fx_em0_geometry"]=15495,["_fx_enemy_collisions"]=14962,["_fx_enemy_em1_update"]=16714,["_fx_enemy_em1_update_reference"]=25383,["_fx_enemy_fire_em1"]=25321,["_fx_enemy_remove"]=25310,["_fx_enemy_render"]=15633,["_fx_enemy_render_bullets"]=15912,["_fx_far_d_acc"]=61308,["_fx_far_u_acc"]=61306,["_fx_fire_actions"]=61299,["_fx_frame"]=17008,["_fx_ground_c1ptr"]=63064,["_fx_ground_c3ptr"]=63066,["_fx_ground_camera"]=27590,["_fx_ground_color1"]=61315,["_fx_ground_color3"]=61765,["_fx_ground_depth_rows"]=27735,["_fx_ground_far_x"]=63030,["_fx_ground_far_xptr"]=63060,["_fx_ground_far_y"]=63070,["_fx_ground_greens"]=33081,["_fx_ground_horizon"]=63068,["_fx_ground_horizontal"]=62215,["_fx_ground_hptr"]=63025,["_fx_ground_native"]=2604,["_fx_ground_palette_record"]=63028,["_fx_ground_phase"]=61295,["_fx_ground_vptr"]=63062,["_fx_ground_width"]=33000,["_fx_ground_world_phase"]=63027,["_fx_init"]=17771,["_fx_input"]=61298,["_fx_open_size"]=58922,["_fx_packet"]=60015,["_fx_packet_count"]=60013,["_fx_present"]=334,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=33089,["_fx_stage_contact"]=60785,["_fx_stage_render"]=60075,["_fx_stage_update"]=61116,["_fx_submit"]=61469,["_ground_irq_vblank_count"]=61303,["_history_head"]=63686,["_hit_pending"]=61310,["_intro_timer"]=63940,["_legacy_enemy_fire_boss_at"]=23915,["_main"]=17808,["_memcpy"]=62070,["_monosh_bom_geometry"]=43346,["_monosh_boss_body_geometry"]=39089,["_monosh_boss_bom_depth_by_size"]=39533,["_monosh_boss_bom_geometry"]=39311,["_monosh_boss_bullet_velocity"]=39771,["_monosh_boss_draw_order_base"]=34547,["_monosh_boss_draw_order_mid"]=36707,["_monosh_boss_explosion_ground_bottom"]=39660,["_monosh_boss_explosion_scale_low"]=39549,["_monosh_boss_face_geometry"]=38867,["_monosh_boss_frame"]=17997,["_monosh_boss_hp"]=63073,["_monosh_boss_init"]=17840,["_monosh_boss_path_center_y"]=33587,["_monosh_boss_path_center_y_mid"]=34307,["_monosh_boss_path_x"]=33347,["_monosh_boss_path_x_mid"]=34067,["_monosh_boss_path_z"]=33107,["_monosh_boss_path_z_mid"]=33827,["_monosh_boss_prepare_fire"]=19896,["_monosh_boss_prepare_render"]=18033,["_monosh_boss_render_only"]=13348,["_monosh_boss_should_restart"]=17819,["_monosh_boss_state"]=63072,["_monosh_bullet_reflect_rng"]=63743,["_monosh_collision_bullet_bands"]=63735,["_monosh_combat_build_collision_bands"]=20078,["_monosh_combat_fast_cache_reset"]=14547,["_monosh_combat_fast_frame"]=13763,["_monosh_combat_fast_render"]=13893,["_monosh_combat_fast_render_cached"]=14554,["_monosh_combat_fire_cooldown"]=63744,["_monosh_combat_half_frame"]=63745,["_monosh_combat_init"]=19922,["_monosh_combat_reflect_bullet"]=14192,["_monosh_combat_render"]=20075,["_monosh_combat_update"]=20017,["_monosh_ebullet4_geometry"]=44153,["_monosh_ebullet_animation_geometry"]=43931,["_monosh_ebullet_geometry"]=44375,["_monosh_ebullet_velocity"]=44385,["_monosh_em1_animation_assets_ready"]=63900,["_monosh_em1_closed_geometry"]=43568,["_monosh_em1_open_geometry"]=43790,["_monosh_enemies"]=63749,["_monosh_enemy_active_count"]=20838,["_monosh_enemy_active_count_value"]=63747,["_monosh_enemy_bullet_count"]=63746,["_monosh_enemy_bullets"]=63829,["_monosh_enemy_camera_delta_cached"]=63898,["_monosh_enemy_collision_cursor"]=63903,["_monosh_enemy_draw_cache_valid"]=63901,["_monosh_enemy_em1_count"]=63899,["_monosh_enemy_em1_phase"]=63874,["_monosh_enemy_em1_shrink"]=63890,["_monosh_enemy_fast_advance"]=16306,["_monosh_enemy_fast_check_player_bullets"]=21928,["_monosh_enemy_fast_render"]=21413,["_monosh_enemy_fast_render_bullets"]=22878,["_monosh_enemy_fast_spawn_due"]=23254,["_monosh_enemy_fast_update_bullets"]=14632,["_monosh_enemy_fire_at"]=20850,["_monosh_enemy_fire_boss_at"]=20879,["_monosh_enemy_fire_em0_fast"]=24313,["_monosh_enemy_frame"]=20641,["_monosh_enemy_geometry"]=43124,["_monosh_enemy_ground_bottom"]=43820,["_monosh_enemy_half_frame"]=63902,["_monosh_enemy_init"]=20492,["_monosh_enemy_path_fire_frames"]=53743,["_monosh_enemy_path_frames"]=53734,["_monosh_enemy_paths"]=53698,["_monosh_enemy_player_hit"]=63904,["_monosh_enemy_render_only"]=20671,["_monosh_enemy_spawn_index"]=63871,["_monosh_enemy_spawn_wait"]=63872,["_monosh_enemy_spawns"]=53752,["_monosh_enemy_stage_complete"]=20844,["_monosh_enemy_stage_complete_flag"]=63748,["_monosh_ground_depth_pointer"]=61313,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=63927,["_monosh_player_bullet_count"]=63718,["_monosh_player_bullet_sizes"]=43099,["_monosh_player_bullets"]=63703,["_monosh_player_can_fire"]=27141,["_monosh_player_draw_asset"]=27157,["_monosh_player_draw_flags"]=27099,["_monosh_player_init"]=27036,["_monosh_player_invuln"]=63930,["_monosh_player_pose"]=63932,["_monosh_player_state"]=63929,["_monosh_player_stumble"]=63931,["_monosh_player_update"]=29489,["_monosh_player_update_reference"]=28366,["_monosh_player_world_active"]=27135,["_monosh_player_x"]=63925,["_monosh_project_x"]=30099,["_monosh_reflected_bullet_count"]=63734,["_monosh_reflected_bullets"]=63719,["_monosh_runtime_fire_actions"]=61300,["_monosh_runtime_frame_counter"]=61301,["_monosh_runtime_paused"]=61305,["_monosh_stage1_spawn_count"]=54894,["_monosh_stage1_spawns"]=53958,["_monosh_stage_collision_bullet_cursor"]=64179,["_monosh_stage_collision_bullet_index"]=64180,["_monosh_stage_contact_result"]=64177,["_monosh_stage_draw_cache_valid"]=64178,["_monosh_stage_frame"]=28641,["_monosh_stage_frame_counter"]=64041,["_monosh_stage_geometry"]=57560,["_monosh_stage_half_frame"]=64045,["_monosh_stage_hitbox_count"]=64175,["_monosh_stage_hitboxes"]=64047,["_monosh_stage_init"]=28606,["_monosh_stage_is_clear"]=28690,["_monosh_stage_lift"]=58349,["_monosh_stage_near_count"]=64046,["_monosh_stage_need_hitboxes"]=64176,["_monosh_stage_object_count"]=64039,["_monosh_stage_objects"]=63943,["_monosh_stage_render_only"]=28687,["_monosh_stage_spawn_index"]=64040,["_monosh_stage_spawn_wait"]=64043,["_monosh_stage_title_timer"]=63933,["_monosh_title_draw"]=17797,["_monosh_title_visible"]=58365,["_movement_fraction"]=63938,["_old_buttons"]=61311,["_player_flip"]=63941,["_player_fy"]=63934,["_player_run_phase"]=63942,["_pose_x_01"]=53896,["_pose_x_12"]=53915,["_pose_x_23"]=53934,["_stage_bom0_geometry"]=57116,["_stage_bush0_geometry"]=54896,["_stage_bush1_geometry"]=55340,["_stage_em0_geometry"]=56228,["_stage_flystone_geometry"]=55784,["_stage_lift_0"]=57572,["_stage_lift_1"]=57683,["_stage_lift_2"]=57794,["_stage_lift_3"]=57905,["_stage_lift_4"]=58016,["_stage_lift_5"]=58127,["_stage_lift_6"]=58238,["_stage_tree0_geometry"]=56672,["_v9968_copy_to_vram_linear"]=14548,["addeq0sp"]=61709,["addeqysp"]=61711,["addysp"]=61727,["addysp1"]=61726,["aslax2"]=61740,["aslax3"]=61751,["aslax4"]=61765,["asrax1"]=61782,["asrax2"]=61792,["asrax3"]=61807,["audio4_first_done"]=696,["audio4_second_done"]=696,["background_done"]=98722,["booleq"]=62032,["boolge"]=62049,["boolgt"]=62047,["boolle"]=62039,["boollt"]=62041,["boolne"]=62026,["booluge"]=62065,["boolugt"]=62063,["boolule"]=62055,["boolult"]=62057,["bullet_render4"]=99584,["c_sp"]=66,["clip_left_found"]=1147,["decsp1"]=61827,["decsp2"]=61836,["decsp3"]=61849,["decsp4"]=61862,["decsp5"]=61875,["dispatch_nonzero"]=98752,["dma_chunk_ready"]=1015,["dma_finished"]=1462,["dma_started"]=1089,["fast_base_ready"]=35886,["fast_fail"]=35922,["fast_tiles"]=35856,["fx4_build_skip"]=58368,["fx4_desc_count"]=58380,["fx4_dma_bytes"]=58376,["fx4_generation"]=58374,["fx4_half_bytes"]=58378,["fx4_page"]=58372,["fx4_wait_obj_blank"]=1499,["fx_add_next_bounds"]=14631,["fx_audio_init"]=37857,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=37908,["fx_audio_sent"]=5653,["fx_build_obj"]=1961,["fx_commit_dma"]=14631,["fx_dma_bytes"]=59242,["fx_dma_count"]=59240,["fx_dma_desc"]=59244,["fx_em1_open_sizes"]=58965,["fx_emit_native"]=16169,["fx_is_obj"]=1913,["fx_latch_obj"]=2309,["fx_obj_build_done"]=2307,["fx_obj_count"]=58976,["fx_obj_dma_bytes"]=58982,["fx_obj_next"]=58704,["fx_obj_overflow"]=58980,["fx_obj_present"]=58840,["fx_obj_present_count"]=58978,["fx_obj_upload_done"]=2514,["fx_plan_dma"]=14612,["fx_project16"]=30129,["fx_read_gsu_spans"]=14557,["fx_reset_next_bounds"]=14631,["fx_sky_colors"]=17006,["fx_sky_colors_end"]=17090,["fx_sky_pointer"]=59008,["fx_upload_ground"]=2935,["fx_upload_obj"]=2355,["game_started"]=0,["generic"]=99536,["ground_done"]=2888,["ground_empty"]=3029,["gsu_uv_cache"]=99207,["half_dma_finished"]=1095,["incsp1"]=61955,["incsp2"]=61970,["incsp3"]=61984,["incsp4"]=61989,["incsp5"]=61994,["incsp6"]=61999,["incsp7"]=62004,["incsp8"]=62009,["initialized"]=1674,["integer_render4"]=100384,["invoke_row"]=1191,["irq_game"]=33430,["keys"]=58576,["ldaidx"]=62014,["logic_finished"]=682,["margin_render"]=99600,["math4_lift_result"]=1597,["memcpy_getparams"]=62111,["memcpy_upwards"]=62073,["mulax10"]=62130,["mulax3"]=62155,["mulax5"]=62172,["mulax6"]=62192,["mulax7"]=62214,["negax"]=62243,["nmi_game"]=33452,["order"]=58448,["packet_done"]=1761,["packet_work"]=6,["pipe_front_slot"]=58404,["pipe_ground_wait"]=707,["pipe_irq"]=830,["pipe_irq_done"]=1162,["pipe_irq_transfer"]=836,["pipe_missed"]=58426,["pipe_pending"]=58408,["pipe_records"]=1024,["pipe_target_slot"]=58406,["pipe_wait_dma"]=855,["player4_next"]=58984,["player4_present"]=58986,["player4_upload_bytes"]=58990,["popax"]=61962,["popptr1"]=62257,["popsargsudiv16"]=62347,["prefetch_finished"]=1141,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=62293,["pusha"]=62275,["pusha0"]=62295,["pusha0sp"]=62271,["pushax"]=62297,["pushaysp"]=62273,["pushw0sp"]=62319,["pushwysp"]=62321,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=692,["render_second_finished"]=692,["render_second_started"]=692,["render_started"]=655,["render_stop"]=99754,["reset"]=32768,["row_done"]=1255,["sa1_clear_done"]=673,["sa1_clear_start"]=555,["sa1_compact"]=36390,["sa1_cover_row"]=35610,["sa1_dirty_done"]=566,["sa1_dma_begin"]=36813,["sa1_dma_end"]=36836,["sa1_dma_poll"]=36846,["sa1_draw_done"]=1279,["sa1_draw_rows"]=35924,["sa1_draw_start"]=692,["sa1_edge_prepare"]=36118,["sa1_edge_restore"]=36305,["sa1_edge_save"]=36196,["sa1_entry"]=512,["sa1_fb_read"]=37058,["sa1_fb_write"]=37064,["sa1_find_shape"]=35374,["sa1_native_done"]=1279,["sa1_near_row"]=36550,["sa1_output_done"]=1283,["sa1_plan_dirty"]=34079,["sa1_prepare_transfer"]=34706,["sa1_select_cover"]=35460,["sa1_snapshot"]=36903,["sa1_tile_masks"]=34807,["sa1_tiles_clear"]=34939,["sa1_tiles_transfer"]=34954,["sa1_try_fast"]=35697,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=61740,["shlax3"]=61751,["shlax4"]=61765,["shrax1"]=62379,["shrax3"]=62387,["shrax4"]=62401,["sorted"]=1740,["sreg"]=68,["stage_update_done"]=61467,["staspidx"]=62418,["stax0sp"]=62440,["staxspidx"]=62451,["staxysp"]=62442,["subysp"]=62499,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=61681,["tosaddax"]=61683,["tosdiva0"]=61888,["tosdivax"]=61890,["tosicmp"]=61911,["tosicmp0"]=61909,["tossuba0"]=62478,["tossubax"]=62480,["tosudiva0"]=62512,["tosudivax"]=62514,["tosumoda0"]=62591,["tosumodax"]=62593,["transfer_chunk"]=1015,["udiv16"]=62529,["L1"]=62563,["@L1"]=62581,["Pos"]=61906,["@L3"]=61947,["@L4"]=61948,["@L2"]=62585,["L0"]=62539,["ret0"]=62028,["ret1"]=62034,["L3"]=62100,["done"]=62108,["L2"]=62372,["@L0"]=62570,["udiv16by8a"]=62570}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/directpipe"
local maxframe=600
local targetPresents=0
local scenario="directpipe"
local padded=false
local pipeline=true
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local outputJobs={}
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={17013},["_monosh_combat_fast_frame"]={17406},["_monosh_combat_render"]={17413},["_monosh_enemy_frame"]={17461},["_monosh_stage_frame"]={17483},["_monosh_boss_frame"]={17575},["_monosh_boss_prepare_render"]={17592},["_monosh_boss_render_only"]={17597,17616},["_fx_build_packet"]={17763},["_fx_build_ground"]={17766}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,0x7f0000+site,0x7f0000+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,0x7f0000+site+3,0x7f0000+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local a=labels[name]+(cpu==emu.cpuType.snes and 0x7f0000 or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if pipeline then
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank-0x40)*65536+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)end)
end
if labels.sa1_sort_packet then
 cb('sa1_sort_packet',function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability')end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario=='boss' then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  local packetAddress=0x430000
  if pipeline then packetAddress=0x434000+emu.read16(0x7e0000+labels.pipe_front_slot,emu.memType.snesMemory)*1024 end
  for i=0,count*10-1 do t[#t+1]=string.char(emu.read(packetAddress+i,emu.memType.snesMemory))end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
