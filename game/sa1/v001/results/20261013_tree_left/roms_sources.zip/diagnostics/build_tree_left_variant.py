import argparse,json,re,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];b=root/'build/sa1_game'
ap=argparse.ArgumentParser();ap.add_argument('variant',choices=['nocache_v2','bypass_v2']);args=ap.parse_args()
a=json.loads((root/'game/sa1/v001/results/20261013_reverse_tree/commands.json').read_text())['combo']+['--reverse-tree-left','--reverse-tree-left-min-bytes','13']
a+=['--reverse-tree-left-no-cache']if args.variant=='nocache_v2'else ['--reverse-tree-left-bypass']
stem='tree_left_'+args.variant
with (b/(stem+'_build.log')).open('wb')as f:subprocess.run([sys.executable,*a],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
d=b/(stem+'_build');d.mkdir(exist_ok=True)
for n in ('MonoSHSA1_4bpp_game.sfc','manifest.json','game.lbl','game.map','fast_reverse_tree.s','reverse_tree_packing.json','compiled_game_packing.json','left_hints_packing.json','ppu_sa1.bin','native_far_packing.json','native_near_packing.json'):
 if (b/n).exists():shutil.copy2(b/n,d/n)
old=b/'tree_left_v2_build'
labels=lambda p:{n:int(a,16)for a,n in re.findall(r'al ([0-9A-Fa-f]+) \.([^\s]+)',p.read_text())}
assert labels(old/'game.lbl')==labels(d/'game.lbl')
x=(old/'MonoSHSA1_4bpp_game.sfc').read_bytes();y=(d/'MonoSHSA1_4bpp_game.sfc').read_bytes()
diff=[i for i,(a,c)in enumerate(zip(x,y))if a!=c];body=[i for i in diff if not 0x7fdc<=i<0x7fe0]
assert body and max(body)-min(body)<(3 if args.variant=='nocache_v2'else 6)
assert len(diff)<=10
info=dict(referenceRomSha256=json.loads((old/'manifest.json').read_text())['romSha256'],
 romSha256=json.loads((d/'manifest.json').read_text())['romSha256'],allRuntimeLabelsIdentical=True,
 changedOffsets=diff,changesLimitedToControlJumpAndChecksum=True)
(d/'layout_verified.json').write_text(json.dumps(info,indent=2)+'\n');print(info)
