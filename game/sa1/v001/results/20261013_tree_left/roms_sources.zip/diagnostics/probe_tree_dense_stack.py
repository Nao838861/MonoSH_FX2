"""木4を連続wordのPEA/PHA行へ置換する容量と任意下地での意味だけを検査する。"""
import hashlib,json,struct,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from sa1_left_hints import physical
from verify_sa1_native_fragments import execute

def execute_dense(code,pc,sp):
 a=(None,0,0);out={}
 while True:
  op=code[pc];pc+=1
  if op==0x5c:
   assert code[pc:]==b'\x00\x07\x00';return out
  if op in (0xf4,0xbd,0x29,0x09):
   v=struct.unpack_from('<H',code,pc)[0];pc+=2
   if op==0xf4:out[sp-1]=(None,0,v);sp-=2
   elif op==0xbd:a=out.get(v,(v,65535,0))
   elif op==0x29:a=(a[0],a[1]&v,a[2]&v)
   else:a=(a[0],a[1]&~v&65535,a[2]|v)
  elif op==0x48:
   out[sp-1]=(a[0]if a[1]else None,a[1],a[2]);sp-=2
  else:raise AssertionError(hex(op))
rom=(root/'build/sa1_game/reverse_tree_combo_v2_build/MonoSHSA1_4bpp_game.sfc').read_bytes()
pointers=set();row_uses=geometries=0
for w in range(1,256):
 block=struct.unpack_from('<H',rom,0x7f0000+4*512+w*2)[0]
 if not block:continue
 for i in range(rom[0x7f0000+block]):
  entry=0x7f0000+block+1+i*10;h=rom[entry];geometries+=1;desc=struct.unpack_from('<H',rom,entry+1)[0]
  for parity in range(2):
   chain=physical(int.from_bytes(rom[0x7f0000+desc+parity*3:0x7f0000+desc+parity*3+3],'little'))
   for y in range(h):pointers.add(int.from_bytes(rom[chain+y*11+8:chain+y*11+11],'little'));row_uses+=1
codes=set();hints=set();old_bytes=words=opaque=identity=masked=right_checks=left_checks=0
for ptr in pointers:
 p=physical(ptr);old=rom[p:p+rom[p-2]];state=execute(old);extent=rom[p-1];code=bytearray();starts=[];written={};sp=extent-1
 for off in range(extent-2,-1,-2):
  source,mask,value=state.get(off,(off,65535,0));assert source in(None,off)
  starts.append((off,len(code)));words+=1
  if not mask:code+=b'\xf4'+struct.pack('<H',value);opaque+=1
  elif mask==65535 and not value:code+=b'\xbd'+struct.pack('<H',off)+b'\x48';identity+=1
  else:code+=b'\xbd'+struct.pack('<H',off)+b'\x29'+struct.pack('<H',mask)+b'\x09'+struct.pack('<H',value)+b'\x48';masked+=1
  assert sp-1==off;sp-=2;written[off]=(source if mask else None,mask,value)
 for off in range(0,extent,2):assert written[off]==state.get(off,(off,65535,0))
 code+=b'\x5c\x00\x07\x00';assert len(code)<=255
 actual=execute_dense(code,0,extent-1);assert actual==written
 hint=bytes(next((pc for off,pc in starts if off<limit),len(code)-4)for limit in range(0,extent+1,2))
 for limit in range(1,extent+1):
  start=hint[(limit+1)//2];actual=execute_dense(code,start,((limit+1)//2)*2-1)
  assert actual=={off:v for off,v in written.items()if off<limit};right_checks+=1
 for minimum in range(1,extent):
  length=hint[minimum//2];actual=execute_dense(code[:length]+b'\x5c\x00\x07\x00',0,extent-1)
  assert actual=={off:v for off,v in written.items()if off>=minimum//2*2};left_checks+=1
 codes.add(bytes(code));hints.add(hint);old_bytes+=len(old)
result=dict(referenceRomSha256=hashlib.sha256(rom).hexdigest(),geometries=geometries,rowUses=row_uses,
 kernels=len(pointers),uniqueStackKernels=len(codes),oldNativeKernelBytes=old_bytes,stackKernelBytes=sum(map(len,codes)),
 kernelBytesSaved=old_bytes-sum(map(len,codes)),rawHintTables=len(hints),rawHintBytes=sum(map(len,hints)),
 singleByteHintIndexFits=len(hints)<=256,maximumKernelBytes=max(map(len,codes)),
 denseWords=words,opaquePeaWords=opaque,preservedIdentityWords=identity,maskedPhaWords=masked,
 independentOpcodeExecutionVerified=True,rightByteLimitsVerified=right_checks,leftByteLimitsVerified=left_checks,
 arbitraryFramebufferInputsVerified=True,sourceOnly=True,gameIntegrated=False,runtimeCostMeasured=False,goal60fpsAchieved=False)
dest=root/'game/sa1/v001/results/20261013_tree_left';dest.mkdir(parents=True,exist_ok=True)
(dest/'dense_stack_capacity_probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
