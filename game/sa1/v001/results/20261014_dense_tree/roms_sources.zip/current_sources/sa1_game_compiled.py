"""現行ゲームで使用する全寸法・色位相・横2画素位相を直接65816コードにする。"""
import json,struct
import numpy as np
from sa1_patterns import dimensions
from sa1_prescaled import address

def build(variants,dest,macros=False,stride=128,row_dirty=False,row_dirty_bands=False,row_dirty_step=8,row_dirty_aligned=False,bullet_cache=False,row_dirty_exact=False,bullet_opacity=False,bullet_shapes=False,reverse_explosions_min_width=0,reverse_inline_hints=False,left_inline_hints=False,left_explosion_hints_min_width=0,left_flame_hints=False,opaque_prefix=False,opaque_prefix_inline_raw=False,flame_direct_hints=False,direct_left_hints=False,reverse_tree=False,dense_stack_tree=False):
    rom=bytearray(0x800000);cursor=0x20000;index=bytearray(65536);used=44*512;pool={};rowcache={};codes=set();maximum=0;deferred=[];alignment_gaps=[]
    reserved=((0x400000,0x440000),(0x591300,0x600000))+(((0x7e0000,0x7eb000),) if row_dirty_aligned else ())
    assert not opaque_prefix_inline_raw or opaque_prefix
    initial_values=[0];initial_index={0:0}
    tree_hints=[];tree_hint_indices={}
    from sa1_bullet_shapes import Shapes
    shapes=Shapes() if bullet_shapes else None
    def alloc(raw,fill_gaps=False):
        nonlocal cursor
        raw=bytes(raw)
        if raw in pool:return pool[raw]
        if fill_gaps:
            for gap in alignment_gaps:
                p=gap['begin']+gap['used']
                if p+len(raw)<=gap['end']:
                    assert not any(rom[p:p+len(raw)])
                    rom[p:p+len(raw)]=raw;gap['used']+=len(raw);a=address(p);pool[raw]=a
                    return a
        while True:
            boundary=0x8000 if cursor<0x400000 else 0x10000
            if cursor%boundary+len(raw)>boundary:
                end=(cursor+boundary-1)//boundary*boundary
                assert all(cursor>=b or end<=a for a,b in reserved)
                alignment_gaps.append(dict(begin=cursor,end=end,used=0));cursor=end
            block=next(((a,b) for a,b in reserved if cursor<b and cursor+len(raw)>a),None)
            if block:cursor=block[1]
            else:break
        if cursor+len(raw)>0x7f0000:raise ValueError(f'compiled game ROM exhausted: {cursor:x}')
        a=address(cursor);rom[cursor:cursor+len(raw)]=raw;cursor+=len(raw);pool[raw]=a
        return a
    def idx(raw):
        nonlocal used
        a=used;index[a:a+len(raw)]=raw;used+=len(raw)
        if used>65536:raise ValueError('compiled index exhausted')
        return a
    def row_entry(row,parity,compressed=False,reverse=False,left_inline=False,opaque_inline=False,flame_inline=False,direct_inline=False,tree_inline=False):
        nonlocal maximum
        key=row.tobytes(),parity,compressed,reverse,left_inline,opaque_inline,flame_inline,direct_inline,tree_inline
        if key in rowcache:return rowcache[key]
        pixels=np.pad(row,(parity,(-len(row)-parity)%4));words=[]
        for x in range(0,len(pixels),4):
            val=sum(int(c)<<(n*4) for n,c in enumerate(pixels[x:x+4]))
            if val:
                mask=sum((0 if c else 15)<<(n*4) for n,c in enumerate(pixels[x:x+4]))
                words.append((x//2,mask,val))
        origin=words[0][0] if words else 0;code=bytearray();acc=None;starts=[]
        if compressed:
            end=words[-1][0]+2 if words else 0
            length=1+sum(12 if mask else 6 for _,mask,_ in words)
            assert length<=255
            encoded=bytearray((length,end-origin,origin,(end-origin)//2))
            values={offset:(mask,value) for offset,mask,value in words}
            if bullet_opacity:
                opaque=sum(1<<i for i,offset in enumerate(range(origin,end,2)) if i<16 and values.get(offset,(65535,0))[0]==0)
                encoded[:2]=struct.pack('<H',opaque)
            if shapes is not None:
                encoded[:2]=struct.pack('<H',shapes.add([values.get(offset,(65535,0))[0] for offset in range(origin,end,2)]))
            for offset in range(origin,end,2):encoded+=struct.pack('<H',values.get(offset,(65535,0))[1])
            rowcache[key]=alloc(encoded).to_bytes(3,'little')
            return rowcache[key]
        dense=tree_inline and dense_stack_tree
        values={off:(mask,value) for off,mask,value in words}
        end=words[-1][0]+2 if words else origin
        sequence=((off,*values.get(off,(65535,0)))for off in range(end-2,origin-1,-2)) if dense else (reversed(words) if reverse else words)
        for offset,mask,value in sequence:
            offset-=origin
            starts.append((offset,len(code)))
            if dense:
                if not mask:code+=b'\xf4'+struct.pack('<H',value)
                else:
                    code+=b'\xbd'+struct.pack('<H',offset)
                    if mask!=65535 or value:code+=b'\x29'+struct.pack('<H',mask)+b'\x09'+struct.pack('<H',value)
                    code+=b'\x48'
                continue
            if mask:
                code+=b'\xbd'+struct.pack('<H',offset)+b'\x29'+struct.pack('<H',mask)+b'\x09'+struct.pack('<H',value)
                acc=None
            elif reverse or acc!=value:
                code+=b'\xa9'+struct.pack('<H',value);acc=value
            code+=b'\x9d'+struct.pack('<H',offset)
        code+=b'\x5c\x00\x07\x00' if dense else b'\x6b';maximum=max(maximum,len(code));assert len(code)<=0x1f0
        if dense:assert len(code)<=0xc0
        codes.add(bytes(code))
        end=words[-1][0]+2 if words else 0
        packed=pixels[::2]|pixels[1::2]<<4
        best=(0,0);start=0
        for n in range(len(packed)+1):
            if n<len(packed) and packed[n]&15 and packed[n]>>4:continue
            if n-start>best[1]-best[0]:best=(start,n)
            start=n+1
        header=bytes((len(code),end-origin)) if macros else bytes((max(0,best[0]-origin),max(0,best[1]-origin)))
        if tree_inline:
            assert reverse and macros
            hint=bytes(next((pc for off,pc in starts if off<limit),len(code)-(4 if dense else 1)) for limit in range(0,end-origin+1,2))
            if hint not in tree_hint_indices:
                tree_hint_indices[hint]=len(tree_hints);tree_hints.append(hint)
                assert len(tree_hints)<=256
            header=bytes((tree_hint_indices[hint],))+header
        if reverse and reverse_inline_hints:
            encoded=bytes(next((pc for off,pc in starts if off<limit),len(code)-1) for limit in range(0,end-origin+1,2))
            header=alloc(encoded).to_bytes(3,'little')+header
        if left_inline:
            from analyze_sa1_hint_compression import compress
            encoded=bytes(next((pc//3 for off,pc in starts if off+1>=limit),(len(code)-1)//3) for limit in range(0,end-origin+1,2))
            header=alloc(compress(encoded)).to_bytes(3,'little')+header
        if opaque_inline:
            from sa1_opaque_prefix import safe_hint
            assert macros and not left_inline and not reverse
            hint=safe_hint(code,starts,end-origin,raw_only=opaque_prefix_inline_raw)
            header=(hint if opaque_prefix_inline_raw else alloc(hint).to_bytes(3,'little'))+header
        if flame_inline:
            from sa1_flame_direct import encode
            assert macros and not left_inline and not reverse and not opaque_inline
            header=alloc(encode(code,starts,end-origin),fill_gaps=True).to_bytes(3,'little')+header
        if direct_inline:
            from sa1_flame_direct import encode
            assert macros and not (left_inline or reverse or opaque_inline or flame_inline)
            raw=encode(code,starts,end-origin);encoded=bytearray()
            for p in range(0,len(raw),3):
                value=struct.unpack_from('<H',raw,p+1)[0]
                if value not in initial_index:
                    initial_index[value]=len(initial_values);initial_values.append(value)
                    assert len(initial_values)<=256, 'left clip initial-value dictionary exhausted'
                encoded+=bytes((raw[p],initial_index[value]))
            header=alloc(encoded,fill_gaps=True).to_bytes(3,'little')+header
        ptr=alloc(header+code)+len(header)
        rowcache[key]=ptr.to_bytes(3,'little')+bytes([len(code),origin,end])
        return rowcache[key]
    patterns=dimensions()
    for asset,sizes in sorted(patterns.items()):
        for w in sorted({w for w,h in sizes},reverse=True):
            pix=variants[asset,0][1];ah,aw=pix.shape;heights=sorted(h for ww,h in sizes if ww==w)
            entries=bytearray();bounds_data=[]
            for h in heights:
                ys=(np.arange(h)*(ah*256//h))>>8;desc=bytearray()
                for phase in range(3 if (asset,1) in variants else 1):
                    pix=variants[asset,phase][1];source=pix[:,(np.arange(w)*(aw*256//w))>>8]
                    if bullet_cache and asset in (6,7,8,37):
                        for flip in range(2):
                            source=pix[:,(aw-1-((np.arange(w)*(aw*256//w))>>8)) if flip else ((np.arange(w)*(aw*256//w))>>8)]
                            for parity in range(2):
                                rows=alloc(b''.join(row_entry(source[y],parity,compressed=True) for y in range(ah)))
                                desc+=rows.to_bytes(3,'little')
                        continue
                    for parity in range(2):
                        if macros:
                            program=bytearray()
                            for dy,y in enumerate(ys):
                                row=row_entry(source[int(y)],parity,reverse=bool((reverse_explosions_min_width and asset in (40,41) and w>=reverse_explosions_min_width) or (reverse_tree and asset==4)),tree_inline=bool(reverse_tree and asset==4),left_inline=bool(left_inline_hints and (((asset in (0,2,3,5) or (left_flame_hints and asset==31)) and w>=64) or (asset==39 and left_explosion_hints_min_width and w>=left_explosion_hints_min_width))),opaque_inline=bool(opaque_prefix and asset==40 and 49<=w<=79),flame_inline=bool(flame_direct_hints and asset==31 and w>=64),direct_inline=bool(direct_left_hints and asset in (0,2,3,5) and w>=64))
                                program+=b'\xa9'+struct.pack('<H',dy*stride+row[4])+b'\x18\x65\xf8\xaa\x22'+row[:3]
                            program+=b'\x6b';rows=alloc(program)
                        else:rows=alloc(b''.join(row_entry(source[int(y)],parity) for y in ys))
                        desc+=rows.to_bytes(3,'little')
                entries+=bytes([h])+struct.pack('<H',idx(desc))
                if macros:
                    occupied=np.zeros((h,w),dtype=bool)
                    for phase in range(3 if (asset,1) in variants else 1):
                        pixels=variants[asset,phase][1]
                        occupied|=pixels[ys[:,None],((np.arange(w)*(aw*256//w))>>8)[None,:]]!=0
                    yy,xx=np.nonzero(occupied)
                    bounds=(int(xx.min()),int(yy.min()),int(xx.max())+1,int(yy.max())+1) if len(xx) else (0,0,0,0)
                    entries+=bytes(bounds)
                    if row_dirty:
                        if row_dirty_aligned:
                            phases=[]
                            if w>=32 and h>=24:
                                for yphase in range(8):
                                    encoded=bytearray();previous=None;run=0
                                    for start in range(-yphase,h,8):
                                        _,xs=np.nonzero(occupied[max(0,start):min(h,start+8)])
                                        pair=((int(xs.min()),int(xs.max())+1) if row_dirty_exact else (int(xs.min())//4,(int(xs.max())+4)//4)) if len(xs) else (0,0)
                                        assert max(pair)<256
                                        if pair==previous and run<(255 if row_dirty_exact else 8):run+=1
                                        else:
                                            if previous is not None:encoded+=bytes((*previous,run)) if row_dirty_exact else struct.pack('<H',previous[0]|previous[1]<<6|(run-1)<<13)
                                            previous=pair;run=1
                                    encoded+=bytes((*previous,run)) if row_dirty_exact else struct.pack('<H',previous[0]|previous[1]<<6|(run-1)<<13)
                                    phases.append(bytes(encoded))
                            bounds_data.append(tuple(phases));entries+=bytes(3)
                        else:
                            encoded=bytearray();previous=None;run=0
                            step=row_dirty_step if row_dirty_bands else 1
                            for start in range(0,h,step):
                                _,xs=np.nonzero(occupied[start:start+step])
                                pair=(int(xs.min())//4,(int(xs.max())+4)//4) if len(xs) else (0,0)
                                length=min(step,h-start)
                                if pair==previous and run+length<=255:run+=length
                                else:
                                    if previous is not None:encoded+=bytes((run,*previous))
                                    previous=pair;run=length
                            encoded+=bytes((run,*previous))
                            bounds_data.append(bytes(encoded));entries+=bytes(3)
            block=idx(bytes([len(heights)])+entries)
            struct.pack_into('<H',index,asset*512+w*2,block)
            for number,encoded in enumerate(bounds_data):deferred.append((block+1+number*10+7,encoded))
    reuse_gaps=opaque_prefix_inline_raw or flame_direct_hints or direct_left_hints or reverse_tree
    for location,encoded in deferred:
        if isinstance(encoded,tuple):
            # run byteは65816の16bit LDAで読まれる。LoROM bank末尾でも余分なhigh byteをROM内に置く。
            pointer=alloc(b''.join(alloc(phase+(b'\0'if reverse_tree else b''),fill_gaps=reuse_gaps).to_bytes(3,'little') for phase in encoded),fill_gaps=reuse_gaps) if encoded else 0
        else:pointer=alloc(encoded,fill_gaps=reuse_gaps)
        index[location:location+3]=pointer.to_bytes(3,'little')
    if direct_left_hints:initial_table=alloc(b''.join(struct.pack('<H',v) for v in initial_values),fill_gaps=True)
    rom[0x7f0000:]=index
    info={'geometryPatterns':sum(map(len,patterns.values())),'currentGamePatterns':True,'horizontalFlipSupported':bullet_cache,'verticalFlipSupported':bullet_cache,'flipAssets':[6,7,8,37] if bullet_cache else [],'bulletCache':bullet_cache,'pixelParities':2,'rowDescriptorBytes':11 if macros else 6,'framebufferStride':stride,'nativeRowCallChains':macros,'uniqueRows':len(rowcache),'uniqueCodeKernels':len(codes),'nativeCodeBytes':sum(map(len,codes)),'maxKernelBytes':maximum,'payloadEnd':cursor,'lookupBytes':used,'heightDescriptorBytes':10 if row_dirty else 7,'rowDirty':row_dirty,'rowDirtyBands':row_dirty_bands,'rowDirtyStep':row_dirty_step,'rowDirtyAligned':row_dirty_aligned,'reverseExplosionsMinWidth':reverse_explosions_min_width,'reverseInlineHints':reverse_inline_hints,'leftInlineHints':left_inline_hints,'leftExplosionHintsMinWidth':left_explosion_hints_min_width,'leftFlameHints':left_flame_hints}
    if reuse_gaps:info.update(deferredGapRanges=alignment_gaps,deferredGapBytes=sum(g['used'] for g in alignment_gaps))
    if direct_left_hints:info.update(directLeftHints=True,initialValueTable=initial_table,initialValues=initial_values)
    if reverse_tree:info.update(reverseTree=True,treeHints=[h.hex() for h in tree_hints])
    if dense_stack_tree:info.update(denseStackTree=True)
    (dest/'compiled_game_packing.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
    if shapes is not None:shapes.save(dest)
    return rom

if __name__=='__main__':
    from build_sa1_probe import assets,BUILD
    build(assets(),BUILD)
