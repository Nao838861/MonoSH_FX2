import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];p=root/'game/sa1/v001/dense_stack_tree_game.s';fixed=p.read_text(encoding='utf-8')
a='''  ; 左clipの末尾wordはlow byteが窓の直前、high byteだけが可視の場合がある。
  ; その場合はhigh側の窓を選ぶ。右clipのhigh側は画面外なのでlow側を選ぶ。
  ldx tCur
  bpl :+
  inc
:
'''
b='''  ldx tCur
  bpl :+
  inc
  and #$1fff
  clc
  adc #$6000
  bra tree_sp_ready
:
'''
assert fixed.count(a)==fixed.count(b)==1
try:
 p.write_text(fixed.replace(a,'').replace(b,'').replace('tree_sp_ready:\n',''),encoding='utf-8')
 subprocess.run([sys.executable,'.cache/build_dense_tree.py','v1'],cwd=root,check=True)
finally:p.write_text(fixed,encoding='utf-8')
subprocess.run([sys.executable,'.cache/build_dense_tree.py','v2'],cwd=root,check=True)
