import json,subprocess,sys,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1];build=root/'build/sa1_game'
args=json.loads((root/'game/sa1/v001/results/20261013_reverse_tree/commands.json').read_text())['combo']+['--dense-stack-tree']
(build/'dense_tree_commands.json').write_text(json.dumps(args,indent=2)+'\n')
version=sys.argv[1]if len(sys.argv)>1 else 'v1'
with (build/f'dense_tree_{version}_build.log').open('wb')as f:subprocess.run([sys.executable,*args],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
d=build/f'dense_tree_{version}_build';d.mkdir(exist_ok=True)
for n in ('MonoSHSA1_4bpp_game.sfc','game.lbl','manifest.json','compiled_game_packing.json','reverse_tree_packing.json','left_hints_packing.json','dirty_band_packing.json','pipeline_tuned.inc','fast_reverse_tree.s'):
 p=build/n
 if p.exists():shutil.copy2(p,d/n)
shutil.copy2(root/'game/sa1/v001/dense_stack_tree_game.s',d/'dense_stack_tree_game.s')
print((build/'manifest.json').read_text()[:100])
