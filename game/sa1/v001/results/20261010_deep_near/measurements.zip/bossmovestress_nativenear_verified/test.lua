local labels={["LoadAudioData"]=63579,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64182,["Tad_GetSong"]=64286,["Tad_GlobalVolumesPersist"]=64314,["Tad_GlobalVolumesResetOnSongStart"]=64308,["Tad_Init"]=63798,["Tad_IsLoaderActive"]=64340,["Tad_IsSfxPlaying"]=64354,["Tad_IsSongLoaded"]=64348,["Tad_IsSongPlaying"]=64360,["Tad_LoadSong"]=64241,["Tad_LoadSongIfChanged"]=64274,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=63925,["Tad_QueueCommand"]=64198,["Tad_QueueCommandOverride"]=64203,["Tad_QueuePannedSoundEffect"]=64220,["Tad_QueueSoundEffect"]=64230,["Tad_ReloadCommonAudioData"]=64290,["Tad_SetTransferSize"]=64320,["Tad_SongsStartImmediately"]=64296,["Tad_SongsStartPaused"]=64302,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=48,["Tad_sfxQueue_sfx"]=47,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5929,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=64023,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=9588,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=64612,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=110,["__STARTUP__"]=1,["_abs"]=63654,["_boss_age"]=40433,["_boss_attribute_cache"]=40268,["_boss_attribute_cache_count"]=40430,["_boss_attribute_z_cache"]=40412,["_boss_dda_phase"]=40651,["_boss_dda_x"]=40657,["_boss_dda_y"]=40663,["_boss_death_parts"]=40435,["_boss_death_timer"]=40434,["_boss_fire_gap"]=40444,["_boss_fire_round"]=40441,["_boss_fire_shots"]=40443,["_boss_fire_state"]=40440,["_boss_fire_volley"]=40442,["_boss_history_x"]=39884,["_boss_history_y"]=40012,["_boss_history_z"]=40140,["_boss_last_vblank"]=39820,["_boss_motion_steps"]=40439,["_boss_part_active"]=39848,["_boss_part_bottom"]=39830,["_boss_part_fall_fraction"]=39875,["_boss_part_fall_velocity"]=39866,["_boss_part_timer"]=39857,["_boss_part_x"]=39821,["_boss_part_z"]=39839,["_boss_path_half"]=40438,["_boss_player_bottom"]=40447,["_boss_player_x"]=40445,["_boss_render_camera_delta"]=40431,["_boss_restart_timer"]=40436,["_boss_z_phase"]=40437,["_death_accel_fraction"]=40685,["_death_timer"]=40683,["_death_vy"]=40682,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=2538,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=14409,["_fx_boss_project"]=14983,["_fx_build_ground"]=3541,["_fx_build_packet"]=2624,["_fx_buttons"]=38042,["_fx_draw"]=36118,["_fx_draw_count"]=36758,["_fx_em0_geometry"]=16910,["_fx_enemy_collisions"]=16377,["_fx_enemy_em1_update"]=18129,["_fx_enemy_em1_update_reference"]=26798,["_fx_enemy_fire_em1"]=26736,["_fx_enemy_remove"]=26725,["_fx_enemy_render"]=17048,["_fx_enemy_render_bullets"]=17327,["_fx_far_d_acc"]=38054,["_fx_far_u_acc"]=38052,["_fx_fire_actions"]=38045,["_fx_frame"]=18423,["_fx_ground_c1ptr"]=39810,["_fx_ground_c3ptr"]=39812,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38061,["_fx_ground_color3"]=38511,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39776,["_fx_ground_far_xptr"]=39806,["_fx_ground_far_y"]=39816,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39814,["_fx_ground_horizontal"]=38961,["_fx_ground_hptr"]=39771,["_fx_ground_native"]=3629,["_fx_ground_palette_record"]=39774,["_fx_ground_phase"]=38041,["_fx_ground_vptr"]=39808,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39773,["_fx_init"]=19186,["_fx_input"]=38044,["_fx_open_size"]=60337,["_fx_packet"]=36761,["_fx_packet_count"]=36759,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=62200,["_fx_stage_render"]=61490,["_fx_stage_update"]=62531,["_fx_submit"]=62884,["_ground_irq_vblank_count"]=38049,["_history_head"]=40432,["_hit_pending"]=38056,["_intro_timer"]=40686,["_legacy_enemy_fire_boss_at"]=25330,["_main"]=19223,["_memcpy"]=63485,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59259,["_monosh_boss_draw_order_mid"]=61419,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=19412,["_monosh_boss_hp"]=39819,["_monosh_boss_init"]=19255,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=21311,["_monosh_boss_prepare_render"]=19448,["_monosh_boss_render_only"]=14763,["_monosh_boss_should_restart"]=19234,["_monosh_boss_state"]=39818,["_monosh_bullet_reflect_rng"]=40489,["_monosh_collision_bullet_bands"]=40481,["_monosh_combat_build_collision_bands"]=21493,["_monosh_combat_fast_cache_reset"]=15962,["_monosh_combat_fast_frame"]=15178,["_monosh_combat_fast_render"]=15308,["_monosh_combat_fast_render_cached"]=15969,["_monosh_combat_fire_cooldown"]=40490,["_monosh_combat_half_frame"]=40491,["_monosh_combat_init"]=21337,["_monosh_combat_reflect_bullet"]=15607,["_monosh_combat_render"]=21490,["_monosh_combat_update"]=21432,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40646,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40495,["_monosh_enemy_active_count"]=22253,["_monosh_enemy_active_count_value"]=40493,["_monosh_enemy_bullet_count"]=40492,["_monosh_enemy_bullets"]=40575,["_monosh_enemy_camera_delta_cached"]=40644,["_monosh_enemy_collision_cursor"]=40649,["_monosh_enemy_draw_cache_valid"]=40647,["_monosh_enemy_em1_count"]=40645,["_monosh_enemy_em1_phase"]=40620,["_monosh_enemy_em1_shrink"]=40636,["_monosh_enemy_fast_advance"]=17721,["_monosh_enemy_fast_check_player_bullets"]=23343,["_monosh_enemy_fast_render"]=22828,["_monosh_enemy_fast_render_bullets"]=24293,["_monosh_enemy_fast_spawn_due"]=24669,["_monosh_enemy_fast_update_bullets"]=16047,["_monosh_enemy_fire_at"]=22265,["_monosh_enemy_fire_boss_at"]=22294,["_monosh_enemy_fire_em0_fast"]=25728,["_monosh_enemy_frame"]=22056,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40648,["_monosh_enemy_init"]=21907,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40650,["_monosh_enemy_render_only"]=22086,["_monosh_enemy_spawn_index"]=40617,["_monosh_enemy_spawn_wait"]=40618,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=22259,["_monosh_enemy_stage_complete_flag"]=40494,["_monosh_ground_depth_pointer"]=38059,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40673,["_monosh_player_bullet_count"]=40464,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40449,["_monosh_player_can_fire"]=28556,["_monosh_player_draw_asset"]=28572,["_monosh_player_draw_flags"]=28514,["_monosh_player_init"]=28451,["_monosh_player_invuln"]=40676,["_monosh_player_pose"]=40678,["_monosh_player_state"]=40675,["_monosh_player_stumble"]=40677,["_monosh_player_update"]=30904,["_monosh_player_update_reference"]=29781,["_monosh_player_world_active"]=28550,["_monosh_player_x"]=40671,["_monosh_project_x"]=31514,["_monosh_reflected_bullet_count"]=40480,["_monosh_reflected_bullets"]=40465,["_monosh_runtime_fire_actions"]=38046,["_monosh_runtime_frame_counter"]=38047,["_monosh_runtime_paused"]=38051,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40925,["_monosh_stage_collision_bullet_index"]=40926,["_monosh_stage_contact_result"]=40923,["_monosh_stage_draw_cache_valid"]=40924,["_monosh_stage_frame"]=30056,["_monosh_stage_frame_counter"]=40787,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40791,["_monosh_stage_hitbox_count"]=40921,["_monosh_stage_hitboxes"]=40793,["_monosh_stage_init"]=30021,["_monosh_stage_is_clear"]=30105,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40792,["_monosh_stage_need_hitboxes"]=40922,["_monosh_stage_object_count"]=40785,["_monosh_stage_objects"]=40689,["_monosh_stage_render_only"]=30102,["_monosh_stage_spawn_index"]=40786,["_monosh_stage_spawn_wait"]=40789,["_monosh_stage_title_timer"]=40679,["_monosh_title_draw"]=19212,["_monosh_title_visible"]=34997,["_movement_fraction"]=40684,["_old_buttons"]=38057,["_player_flip"]=40687,["_player_fy"]=40680,["_player_run_phase"]=40688,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=15963,["addeq0sp"]=63124,["addeqysp"]=63126,["addysp"]=63142,["addysp1"]=63141,["aslax2"]=63155,["aslax3"]=63166,["aslax4"]=63180,["asrax1"]=63197,["asrax2"]=63207,["asrax3"]=63222,["audio4_first_done"]=774,["audio4_second_done"]=774,["background_done"]=100258,["booleq"]=63447,["boolge"]=63464,["boolgt"]=63462,["boolle"]=63454,["boollt"]=63456,["boolne"]=63441,["booluge"]=63480,["boolugt"]=63478,["boolule"]=63470,["boolult"]=63472,["bullet_render4"]=101120,["c_sp"]=69,["clip_left_found"]=34410,["decsp1"]=63242,["decsp2"]=63251,["decsp3"]=63264,["decsp4"]=63277,["decsp5"]=63290,["dispatch_nonzero"]=100288,["dma_chunk_ready"]=1274,["dma_finished"]=2128,["dma_started"]=1466,["fast_base_ready"]=36835,["fast_fail"]=36877,["fast_tiles"]=36802,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=2517,["fx_add_next_bounds"]=16046,["fx_audio_init"]=64366,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64417,["fx_audio_sent"]=5653,["fx_build_obj"]=2979,["fx_commit_dma"]=16046,["fx_dma_bytes"]=35988,["fx_dma_count"]=35986,["fx_dma_desc"]=35990,["fx_em1_open_sizes"]=60380,["fx_emit_native"]=17584,["fx_is_obj"]=2931,["fx_latch_obj"]=3327,["fx_obj_build_done"]=3325,["fx_obj_count"]=35644,["fx_obj_dma_bytes"]=35650,["fx_obj_next"]=35372,["fx_obj_overflow"]=35648,["fx_obj_present"]=35508,["fx_obj_present_count"]=35646,["fx_obj_upload_done"]=3539,["fx_plan_dma"]=16027,["fx_project16"]=31544,["fx_read_gsu_spans"]=15972,["fx_reset_next_bounds"]=16046,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35676,["fx_upload_ground"]=3966,["fx_upload_obj"]=3373,["game_started"]=0,["generic"]=101072,["ground_done"]=3919,["ground_empty"]=4060,["gsu_uv_cache"]=100743,["half_dma_finished"]=1472,["incsp1"]=63370,["incsp2"]=63385,["incsp3"]=63399,["incsp4"]=63404,["incsp5"]=63409,["incsp6"]=63414,["incsp7"]=63419,["incsp8"]=63424,["initialized"]=2692,["integer_render4"]=101920,["invoke_row"]=34454,["irq_game"]=33464,["keys"]=35244,["ldaidx"]=63429,["logic_finished"]=754,["margin_render"]=101136,["math4_lift_result"]=2615,["memcpy_getparams"]=63526,["memcpy_upwards"]=63488,["mulax10"]=63545,["mulax3"]=63570,["mulax5"]=63587,["mulax6"]=63607,["mulax7"]=63629,["negax"]=63658,["nmi_game"]=33500,["order"]=35116,["packet_done"]=2779,["packet_work"]=6,["pipe_bw_busy"]=35046,["pipe_collect"]=817,["pipe_complete"]=35042,["pipe_dma_measured_end"]=1493,["pipe_fast_begin"]=1884,["pipe_fast_done"]=1934,["pipe_flip"]=1944,["pipe_front_slot"]=35036,["pipe_ground_extra"]=45056,["pipe_ground_extra_end"]=47956,["pipe_ground_wait"]=790,["pipe_irq"]=992,["pipe_irq_done"]=1589,["pipe_irq_exit"]=1612,["pipe_irq_transfer"]=1014,["pipe_main_offset"]=35088,["pipe_missed"]=35078,["pipe_near_build"]=14075,["pipe_near_present"]=35790,["pipe_near_select"]=14386,["pipe_obj_pointer"]=35100,["pipe_pending"]=35040,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_wait_dma"]=1050,["player4_next"]=35652,["player4_present"]=35654,["player4_upload_bytes"]=35658,["player4_uploaded"]=35656,["popax"]=63377,["popptr1"]=63672,["popsargsudiv16"]=63762,["prefetch_finished"]=1568,["ptr1"]=77,["ptr2"]=79,["ptr3"]=81,["ptr4"]=83,["push0"]=63708,["pusha"]=63690,["pusha0"]=63710,["pusha0sp"]=63686,["pushax"]=63712,["pushaysp"]=63688,["pushw0sp"]=63734,["pushwysp"]=63736,["regbank"]=89,["regsave"]=73,["render_entry"]=99840,["render_finished"]=770,["render_second_finished"]=770,["render_second_started"]=770,["render_started"]=727,["render_stop"]=101290,["reset"]=32768,["row_done"]=34518,["sa1_background_cache"]=58077,["sa1_background_initialize"]=58395,["sa1_clear_done"]=598,["sa1_clear_start"]=571,["sa1_compact"]=37431,["sa1_cover_row"]=36552,["sa1_deep_rebase"]=57818,["sa1_dirty_done"]=591,["sa1_dirty_row_rect"]=35722,["sa1_dirty_rows"]=57853,["sa1_dma_begin"]=56968,["sa1_dma_end"]=57004,["sa1_dma_irq"]=57249,["sa1_dma_poll"]=57015,["sa1_draw_done"]=34542,["sa1_draw_rows"]=36879,["sa1_draw_start"]=617,["sa1_edge_cpu_restore"]=58719,["sa1_edge_cpu_save"]=58675,["sa1_edge_prepare"]=37132,["sa1_edge_restore"]=37333,["sa1_edge_save"]=37210,["sa1_entry"]=512,["sa1_fb_read"]=57237,["sa1_fb_write"]=57243,["sa1_find_shape"]=36293,["sa1_merge_dma"]=59106,["sa1_native_done"]=34542,["sa1_near_patch"]=58604,["sa1_near_patch_bounds"]=58518,["sa1_near_row"]=37591,["sa1_occupancy_capture"]=57301,["sa1_output_done"]=34550,["sa1_plan_dirty"]=34952,["sa1_prepare_transfer"]=35619,["sa1_select_cover"]=36402,["sa1_snapshot"]=57072,["sa1_sprite_begin"]=33646,["sa1_sprite_done"]=34529,["sa1_stack_clear_band"]=58789,["sa1_stack_clear_line"]=58960,["sa1_tile_masks"]=35726,["sa1_tiles_clear"]=35858,["sa1_tiles_transfer"]=35873,["sa1_transfer_mask_capture"]=57534,["sa1_transfer_mask_prepare"]=57589,["sa1_try_fast"]=36639,["scaled_render4"]=101648,["scaled_unpacked4"]=101808,["shlax2"]=63155,["shlax3"]=63166,["shlax4"]=63180,["shrax1"]=63794,["shrax3"]=63802,["shrax4"]=63816,["sorted"]=2758,["sreg"]=71,["stage_update_done"]=62882,["staspidx"]=63833,["stax0sp"]=63855,["staxspidx"]=63866,["staxysp"]=63857,["subysp"]=63914,["tmp1"]=85,["tmp2"]=86,["tmp3"]=87,["tmp4"]=88,["tosadda0"]=63096,["tosaddax"]=63098,["tosdiva0"]=63303,["tosdivax"]=63305,["tosicmp"]=63326,["tosicmp0"]=63324,["tossuba0"]=63893,["tossubax"]=63895,["tosudiva0"]=63927,["tosudivax"]=63929,["tosumoda0"]=64006,["tosumodax"]=64008,["transfer_chunk"]=1274,["udiv16"]=63944,["L1"]=63978,["@L1"]=63996,["Pos"]=63321,["@L3"]=63362,["@L4"]=63363,["@L2"]=64000,["L0"]=63954,["ret0"]=63443,["ret1"]=63449,["L3"]=63515,["done"]=63523,["L2"]=63787,["@L0"]=63985,["udiv16by8a"]=63985}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/bossmovestress_nativenear_verified"
local maxframe=1800
local targetPresents=0
local scenario="bossmovestress_nativenear_verified"
local padded=false
local pipeline=true
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
if scenario:match('tracedma') then
 local z=assert(io.open(output..'/sa1_dma_writes.jsonl','w'))
 local blankLog=assert(io.open(output..'/blank_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local st=emu.getState()
  blankLog:write(string.format('{"field":%d,"line":%d,"value":%d,"pc":%d,"hdmaAddress":%d,"hdmaCount":%d}\n',field,st['ppu.scanline'],value,st['cpu.pc'],st['dmaController.channel[1].hdmaTableAddress'],st['dmaController.channel[1].hdmaLineCounterAndRepeat']));blankLog:flush()
 end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
 local reads=assert(io.open(output..'/cpu_dma_reads.jsonl','w'));local readCount=0
 emu.addMemoryCallback(function(address,value)
  if presents==0 and emu.read16(0x311e,emu.memType.snesMemory)==1 and readCount<800 then
   readCount=readCount+1;local s=emu.getState()
   reads:write(string.format('{"address":%d,"value":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',address,value,s['cart.coprocessor.dmaSrcAddr'],s['cart.coprocessor.dmaDestAddr'],tostring(s['cart.coprocessor.charConvDmaActive']),tostring(s['ppu.forcedBlank']),s['ppu.scanline']));reads:flush()
  end
 end,emu.callbackType.read,0x400000,0x43ffff,emu.cpuType.snes,emu.memType.snesMemory)
 emu.addMemoryCallback(function(address,value)
  if emu.read16(0x11e,emu.memType.sa1Memory)==1 then
   local s=emu.getState()
   z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,emu.memType.sa1Memory),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
  end
 end,emu.callbackType.write,0x2230,0x2239,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={18428},["_monosh_combat_fast_frame"]={18821},["_monosh_combat_render"]={18828},["_monosh_enemy_frame"]={18876},["_monosh_stage_frame"]={18898},["_monosh_boss_frame"]={18990},["_monosh_boss_prepare_render"]={19007},["_monosh_boss_render_only"]={19012,19031},["_fx_build_packet"]={19178},["_fx_build_ground"]={19181}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local irqName=name:match('^pipe_') or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(cpu==emu.cpuType.snes and (irqName and 0x7f0000 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
emu.addMemoryCallback(function(address,value)
 local line=emu.getState()['ppu.scanline']
 if field>85 and (line>=203 or line<21) and line<225 and (value&0x80)==0 then
  local f=assert(io.open(output..'/failure.txt','w'));f:write('HDMA unblanked reserved DMA lines field='..field..' line='..line);f:close();emu.stop(1)
 end
end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
local packetClock,irqTicks,irqClock=0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 cb('pipe_irq',function()irqClock=emu.getState().masterClock end)
 cb('pipe_irq_exit',function()irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()
  local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 cb('pipe_fast_begin',function()
  local st=emu.getState();assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA began outside actual blank period')
  if scenario:match('tracedma') then
   local st=emu.getState();local f=assert(io.open(output..'/cc_state.jsonl','a'))
   f:write(string.format('{"field":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',field,st['cart.coprocessor.dmaSrcAddr'],st['cart.coprocessor.dmaDestAddr'],tostring(st['cart.coprocessor.charConvDmaActive']),tostring(st['ppu.forcedBlank']),st['ppu.scanline']));f:close()
   if presents==0 then
    local f=assert(io.open(output..'/before_dma_bw.bin','wb'));local a={}
    for i=0,24575 do a[#a+1]=string.char(emu.read(1024+i,emu.memType.snesSaveRam))end
    f:write(table.concat(a));f:close()
   end
  end
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  if scenario:match('tracedma') and presents==0 then
   local f=assert(io.open(output..'/beforeflip_vram.bin','wb'));local a={}
   for i=0,65535 do a[#a+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
   f:write(table.concat(a));f:close()
  end
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock end)end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs field='..field..' gen='..presents..' byte='..i..' actual='..emu.read(i,emu.memType.snesSpriteRam)..' expected='..emu.read(record+64+i,mt))end
   if true then
    local expected=emu.read16(record+192,mt)|0x0aaa
    local actual=emu.read16(512,emu.memType.snesSpriteRam)
    assert((actual&0x0fff)==(expected&0x0fff),'player high OAM differs')
    dump(n..'_oam.bin',emu.memType.snesSpriteRam,0,544)
   else
    for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
