local labels={["LoadAudioData"]=63454,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64057,["Tad_GetSong"]=64161,["Tad_GlobalVolumesPersist"]=64189,["Tad_GlobalVolumesResetOnSongStart"]=64183,["Tad_Init"]=63673,["Tad_IsLoaderActive"]=64215,["Tad_IsSfxPlaying"]=64229,["Tad_IsSongLoaded"]=64223,["Tad_IsSongPlaying"]=64235,["Tad_LoadSong"]=64116,["Tad_LoadSongIfChanged"]=64149,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=63800,["Tad_QueueCommand"]=64073,["Tad_QueueCommandOverride"]=64078,["Tad_QueuePannedSoundEffect"]=64095,["Tad_QueueSoundEffect"]=64105,["Tad_ReloadCommonAudioData"]=64165,["Tad_SetTransferSize"]=64195,["Tad_SongsStartImmediately"]=64171,["Tad_SongsStartPaused"]=64177,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=46,["Tad_sfxQueue_sfx"]=45,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5911,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=63630,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=6996,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=64487,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=110,["__STARTUP__"]=1,["_abs"]=63261,["_boss_age"]=40415,["_boss_attribute_cache"]=40250,["_boss_attribute_cache_count"]=40412,["_boss_attribute_z_cache"]=40394,["_boss_dda_phase"]=40633,["_boss_dda_x"]=40639,["_boss_dda_y"]=40645,["_boss_death_parts"]=40417,["_boss_death_timer"]=40416,["_boss_fire_gap"]=40426,["_boss_fire_round"]=40423,["_boss_fire_shots"]=40425,["_boss_fire_state"]=40422,["_boss_fire_volley"]=40424,["_boss_history_x"]=39866,["_boss_history_y"]=39994,["_boss_history_z"]=40122,["_boss_last_vblank"]=39802,["_boss_motion_steps"]=40421,["_boss_part_active"]=39830,["_boss_part_bottom"]=39812,["_boss_part_fall_fraction"]=39857,["_boss_part_fall_velocity"]=39848,["_boss_part_timer"]=39839,["_boss_part_x"]=39803,["_boss_part_z"]=39821,["_boss_path_half"]=40420,["_boss_player_bottom"]=40429,["_boss_player_x"]=40427,["_boss_render_camera_delta"]=40413,["_boss_restart_timer"]=40418,["_boss_z_phase"]=40419,["_death_accel_fraction"]=40667,["_death_timer"]=40665,["_death_vy"]=40664,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=2482,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=14016,["_fx_boss_project"]=14590,["_fx_build_ground"]=3482,["_fx_build_packet"]=2568,["_fx_buttons"]=38024,["_fx_draw"]=36100,["_fx_draw_count"]=36740,["_fx_em0_geometry"]=16517,["_fx_enemy_collisions"]=15984,["_fx_enemy_em1_update"]=17736,["_fx_enemy_em1_update_reference"]=26405,["_fx_enemy_fire_em1"]=26343,["_fx_enemy_remove"]=26332,["_fx_enemy_render"]=16655,["_fx_enemy_render_bullets"]=16934,["_fx_far_d_acc"]=38036,["_fx_far_u_acc"]=38034,["_fx_fire_actions"]=38027,["_fx_frame"]=18030,["_fx_ground_c1ptr"]=39792,["_fx_ground_c3ptr"]=39794,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38043,["_fx_ground_color3"]=38493,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39758,["_fx_ground_far_xptr"]=39788,["_fx_ground_far_y"]=39798,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39796,["_fx_ground_horizontal"]=38943,["_fx_ground_hptr"]=39753,["_fx_ground_native"]=3570,["_fx_ground_palette_record"]=39756,["_fx_ground_phase"]=38023,["_fx_ground_vptr"]=39790,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39755,["_fx_init"]=18793,["_fx_input"]=38026,["_fx_open_size"]=59944,["_fx_packet"]=36743,["_fx_packet_count"]=36741,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=61807,["_fx_stage_render"]=61097,["_fx_stage_update"]=62138,["_fx_submit"]=62491,["_ground_irq_vblank_count"]=38031,["_history_head"]=40414,["_hit_pending"]=38038,["_intro_timer"]=40668,["_legacy_enemy_fire_boss_at"]=24937,["_main"]=18830,["_memcpy"]=63092,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59134,["_monosh_boss_draw_order_mid"]=61294,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=19019,["_monosh_boss_hp"]=39801,["_monosh_boss_init"]=18862,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=20918,["_monosh_boss_prepare_render"]=19055,["_monosh_boss_render_only"]=14370,["_monosh_boss_should_restart"]=18841,["_monosh_boss_state"]=39800,["_monosh_bullet_reflect_rng"]=40471,["_monosh_collision_bullet_bands"]=40463,["_monosh_combat_build_collision_bands"]=21100,["_monosh_combat_fast_cache_reset"]=15569,["_monosh_combat_fast_frame"]=14785,["_monosh_combat_fast_render"]=14915,["_monosh_combat_fast_render_cached"]=15576,["_monosh_combat_fire_cooldown"]=40472,["_monosh_combat_half_frame"]=40473,["_monosh_combat_init"]=20944,["_monosh_combat_reflect_bullet"]=15214,["_monosh_combat_render"]=21097,["_monosh_combat_update"]=21039,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40628,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40477,["_monosh_enemy_active_count"]=21860,["_monosh_enemy_active_count_value"]=40475,["_monosh_enemy_bullet_count"]=40474,["_monosh_enemy_bullets"]=40557,["_monosh_enemy_camera_delta_cached"]=40626,["_monosh_enemy_collision_cursor"]=40631,["_monosh_enemy_draw_cache_valid"]=40629,["_monosh_enemy_em1_count"]=40627,["_monosh_enemy_em1_phase"]=40602,["_monosh_enemy_em1_shrink"]=40618,["_monosh_enemy_fast_advance"]=17328,["_monosh_enemy_fast_check_player_bullets"]=22950,["_monosh_enemy_fast_render"]=22435,["_monosh_enemy_fast_render_bullets"]=23900,["_monosh_enemy_fast_spawn_due"]=24276,["_monosh_enemy_fast_update_bullets"]=15654,["_monosh_enemy_fire_at"]=21872,["_monosh_enemy_fire_boss_at"]=21901,["_monosh_enemy_fire_em0_fast"]=25335,["_monosh_enemy_frame"]=21663,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40630,["_monosh_enemy_init"]=21514,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40632,["_monosh_enemy_render_only"]=21693,["_monosh_enemy_spawn_index"]=40599,["_monosh_enemy_spawn_wait"]=40600,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=21866,["_monosh_enemy_stage_complete_flag"]=40476,["_monosh_ground_depth_pointer"]=38041,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40655,["_monosh_player_bullet_count"]=40446,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40431,["_monosh_player_can_fire"]=28163,["_monosh_player_draw_asset"]=28179,["_monosh_player_draw_flags"]=28121,["_monosh_player_init"]=28058,["_monosh_player_invuln"]=40658,["_monosh_player_pose"]=40660,["_monosh_player_state"]=40657,["_monosh_player_stumble"]=40659,["_monosh_player_update"]=30511,["_monosh_player_update_reference"]=29388,["_monosh_player_world_active"]=28157,["_monosh_player_x"]=40653,["_monosh_project_x"]=31121,["_monosh_reflected_bullet_count"]=40462,["_monosh_reflected_bullets"]=40447,["_monosh_runtime_fire_actions"]=38028,["_monosh_runtime_frame_counter"]=38029,["_monosh_runtime_paused"]=38033,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40907,["_monosh_stage_collision_bullet_index"]=40908,["_monosh_stage_contact_result"]=40905,["_monosh_stage_draw_cache_valid"]=40906,["_monosh_stage_frame"]=29663,["_monosh_stage_frame_counter"]=40769,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40773,["_monosh_stage_hitbox_count"]=40903,["_monosh_stage_hitboxes"]=40775,["_monosh_stage_init"]=29628,["_monosh_stage_is_clear"]=29712,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40774,["_monosh_stage_need_hitboxes"]=40904,["_monosh_stage_object_count"]=40767,["_monosh_stage_objects"]=40671,["_monosh_stage_render_only"]=29709,["_monosh_stage_spawn_index"]=40768,["_monosh_stage_spawn_wait"]=40771,["_monosh_stage_title_timer"]=40661,["_monosh_title_draw"]=18819,["_monosh_title_visible"]=34997,["_movement_fraction"]=40666,["_old_buttons"]=38039,["_player_flip"]=40669,["_player_fy"]=40662,["_player_run_phase"]=40670,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=15570,["addeq0sp"]=62731,["addeqysp"]=62733,["addysp"]=62749,["addysp1"]=62748,["aslax2"]=62762,["aslax3"]=62773,["aslax4"]=62787,["asrax1"]=62804,["asrax2"]=62814,["asrax3"]=62829,["audio4_first_done"]=771,["audio4_second_done"]=771,["background_done"]=100002,["booleq"]=63054,["boolge"]=63071,["boolgt"]=63069,["boolle"]=63061,["boollt"]=63063,["boolne"]=63048,["booluge"]=63087,["boolugt"]=63085,["boolule"]=63077,["boolult"]=63079,["bullet_render4"]=100864,["c_sp"]=67,["clip_left_found"]=34446,["decsp1"]=62849,["decsp2"]=62858,["decsp3"]=62871,["decsp4"]=62884,["decsp5"]=62897,["dispatch_nonzero"]=100032,["dma_chunk_ready"]=1271,["dma_finished"]=2130,["dma_started"]=1463,["fast_base_ready"]=36867,["fast_fail"]=36909,["fast_tiles"]=36834,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=33515,["fx_add_next_bounds"]=15653,["fx_audio_init"]=64241,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64292,["fx_audio_sent"]=5653,["fx_build_obj"]=2923,["fx_commit_dma"]=15653,["fx_dma_bytes"]=35970,["fx_dma_count"]=35968,["fx_dma_desc"]=35972,["fx_em1_open_sizes"]=59987,["fx_emit_native"]=17191,["fx_is_obj"]=2875,["fx_latch_obj"]=3271,["fx_obj_build_done"]=3269,["fx_obj_count"]=35644,["fx_obj_dma_bytes"]=35650,["fx_obj_next"]=35372,["fx_obj_overflow"]=35648,["fx_obj_present"]=35508,["fx_obj_present_count"]=35646,["fx_obj_upload_done"]=3480,["fx_plan_dma"]=15634,["fx_project16"]=31151,["fx_read_gsu_spans"]=15579,["fx_reset_next_bounds"]=15653,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35676,["fx_upload_ground"]=3907,["fx_upload_obj"]=3317,["game_started"]=0,["generic"]=100816,["ground_done"]=3860,["ground_empty"]=4001,["gsu_uv_cache"]=100487,["half_dma_finished"]=1469,["incsp1"]=62977,["incsp2"]=62992,["incsp3"]=63006,["incsp4"]=63011,["incsp5"]=63016,["incsp6"]=63021,["incsp7"]=63026,["incsp8"]=63031,["initialized"]=2636,["integer_render4"]=101664,["invoke_row"]=34490,["irq_game"]=33443,["keys"]=35244,["ldaidx"]=63036,["logic_finished"]=751,["margin_render"]=100880,["math4_lift_result"]=2559,["memcpy_getparams"]=63133,["memcpy_upwards"]=63095,["mulax10"]=63152,["mulax3"]=63177,["mulax5"]=63194,["mulax6"]=63214,["mulax7"]=63236,["negax"]=63265,["nmi_game"]=33536,["order"]=35116,["packet_done"]=2723,["packet_work"]=6,["pipe_bw_busy"]=35046,["pipe_collect"]=814,["pipe_complete"]=35042,["pipe_dma_measured_end"]=1490,["pipe_fast_begin"]=1884,["pipe_fast_done"]=1934,["pipe_flip"]=1944,["pipe_front_slot"]=35036,["pipe_ground_extra"]=45056,["pipe_ground_extra_end"]=47956,["pipe_ground_wait"]=787,["pipe_irq"]=989,["pipe_irq_done"]=1586,["pipe_irq_exit"]=1609,["pipe_irq_transfer"]=1011,["pipe_missed"]=35078,["pipe_obj_pointer"]=35100,["pipe_pending"]=35040,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_wait_dma"]=1047,["player4_next"]=35652,["player4_present"]=35654,["player4_upload_bytes"]=35658,["player4_uploaded"]=35656,["popax"]=62984,["popptr1"]=63279,["popsargsudiv16"]=63369,["prefetch_finished"]=1565,["ptr1"]=75,["ptr2"]=77,["ptr3"]=79,["ptr4"]=81,["push0"]=63315,["pusha"]=63297,["pusha0"]=63317,["pusha0sp"]=63293,["pushax"]=63319,["pushaysp"]=63295,["pushw0sp"]=63341,["pushwysp"]=63343,["regbank"]=87,["regsave"]=71,["render_entry"]=99584,["render_finished"]=767,["render_second_finished"]=767,["render_second_started"]=767,["render_started"]=724,["render_stop"]=101034,["reset"]=32768,["row_done"]=34554,["sa1_background_cache"]=58109,["sa1_background_initialize"]=58427,["sa1_clear_done"]=598,["sa1_clear_start"]=571,["sa1_compact"]=37463,["sa1_cover_row"]=36584,["sa1_deep_rebase"]=57850,["sa1_dirty_done"]=591,["sa1_dirty_row_rect"]=35754,["sa1_dirty_rows"]=57885,["sa1_dma_begin"]=57000,["sa1_dma_end"]=57036,["sa1_dma_irq"]=57281,["sa1_dma_poll"]=57047,["sa1_draw_done"]=34582,["sa1_draw_rows"]=36911,["sa1_draw_start"]=617,["sa1_edge_cpu_restore"]=58594,["sa1_edge_cpu_save"]=58550,["sa1_edge_prepare"]=37164,["sa1_edge_restore"]=37365,["sa1_edge_save"]=37242,["sa1_entry"]=512,["sa1_fb_read"]=57269,["sa1_fb_write"]=57275,["sa1_find_shape"]=36325,["sa1_merge_dma"]=58981,["sa1_native_done"]=34582,["sa1_near_row"]=37623,["sa1_occupancy_capture"]=57333,["sa1_output_done"]=34590,["sa1_plan_dirty"]=34988,["sa1_prepare_transfer"]=35651,["sa1_select_cover"]=36434,["sa1_snapshot"]=57104,["sa1_sprite_begin"]=33682,["sa1_sprite_done"]=34565,["sa1_stack_clear_band"]=58664,["sa1_stack_clear_line"]=58835,["sa1_tile_masks"]=35758,["sa1_tiles_clear"]=35890,["sa1_tiles_transfer"]=35905,["sa1_transfer_mask_capture"]=57566,["sa1_transfer_mask_prepare"]=57621,["sa1_try_fast"]=36671,["scaled_render4"]=101392,["scaled_unpacked4"]=101552,["shlax2"]=62762,["shlax3"]=62773,["shlax4"]=62787,["shrax1"]=63401,["shrax3"]=63409,["shrax4"]=63423,["sorted"]=2702,["sreg"]=69,["stage_update_done"]=62489,["staspidx"]=63440,["stax0sp"]=63462,["staxspidx"]=63473,["staxysp"]=63464,["subysp"]=63521,["tmp1"]=83,["tmp2"]=84,["tmp3"]=85,["tmp4"]=86,["tosadda0"]=62703,["tosaddax"]=62705,["tosdiva0"]=62910,["tosdivax"]=62912,["tosicmp"]=62933,["tosicmp0"]=62931,["tossuba0"]=63500,["tossubax"]=63502,["tosudiva0"]=63534,["tosudivax"]=63536,["tosumoda0"]=63613,["tosumodax"]=63615,["transfer_chunk"]=1271,["udiv16"]=63551,["L1"]=63585,["@L1"]=63603,["Pos"]=62928,["@L3"]=62969,["@L4"]=62970,["@L2"]=63607,["L0"]=63561,["ret0"]=63050,["ret1"]=63056,["L3"]=63122,["done"]=63130,["L2"]=63394,["@L0"]=63592,["udiv16by8a"]=63592}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/bossdeep7"
local maxframe=1200
local targetPresents=0
local scenario="bossdeep7"
local padded=false
local pipeline=true
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={18035},["_monosh_combat_fast_frame"]={18428},["_monosh_combat_render"]={18435},["_monosh_enemy_frame"]={18483},["_monosh_stage_frame"]={18505},["_monosh_boss_frame"]={18597},["_monosh_boss_prepare_render"]={18614},["_monosh_boss_render_only"]={18619,18638},["_fx_build_packet"]={18785},["_fx_build_ground"]={18788}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local irqName=name:match('^pipe_') or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(cpu==emu.cpuType.snes and (irqName and 0x7f0000 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
local packetClock,irqTicks,irqClock=0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 cb('pipe_irq',function()irqClock=emu.getState().masterClock end)
 cb('pipe_irq_exit',function()irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()
  local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 cb('pipe_fast_begin',function()
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock end)end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs')end
   for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
