local labels={["LoadAudioData"]=61398,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=62001,["Tad_GetSong"]=62105,["Tad_GlobalVolumesPersist"]=62133,["Tad_GlobalVolumesResetOnSongStart"]=62127,["Tad_Init"]=61617,["Tad_IsLoaderActive"]=62159,["Tad_IsSfxPlaying"]=62173,["Tad_IsSongLoaded"]=62167,["Tad_IsSongPlaying"]=62179,["Tad_LoadSong"]=62060,["Tad_LoadSongIfChanged"]=62093,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=61744,["Tad_QueueCommand"]=62017,["Tad_QueueCommandOverride"]=62022,["Tad_QueuePannedSoundEffect"]=62039,["Tad_QueueSoundEffect"]=62049,["Tad_ReloadCommonAudioData"]=62109,["Tad_SetTransferSize"]=62139,["Tad_SongsStartImmediately"]=62115,["Tad_SongsStartPaused"]=62121,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=46,["Tad_sfxQueue_sfx"]=45,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5867,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=63258,["__COLORBSS_LOAD__"]=1024,["__COLORBSS_RUN__"]=1024,["__COLORBSS_SIZE__"]=3720,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=62431,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=195,["__STARTUP__"]=1,["_abs"]=62889,["_boss_age"]=40371,["_boss_attribute_cache"]=40206,["_boss_attribute_cache_count"]=40368,["_boss_attribute_z_cache"]=40350,["_boss_dda_phase"]=40589,["_boss_dda_x"]=40595,["_boss_dda_y"]=40601,["_boss_death_parts"]=40373,["_boss_death_timer"]=40372,["_boss_fire_gap"]=40382,["_boss_fire_round"]=40379,["_boss_fire_shots"]=40381,["_boss_fire_state"]=40378,["_boss_fire_volley"]=40380,["_boss_history_x"]=39822,["_boss_history_y"]=39950,["_boss_history_z"]=40078,["_boss_last_vblank"]=39758,["_boss_motion_steps"]=40377,["_boss_part_active"]=39786,["_boss_part_bottom"]=39768,["_boss_part_fall_fraction"]=39813,["_boss_part_fall_velocity"]=39804,["_boss_part_timer"]=39795,["_boss_part_x"]=39759,["_boss_part_z"]=39777,["_boss_path_half"]=40376,["_boss_player_bottom"]=40385,["_boss_player_x"]=40383,["_boss_render_camera_delta"]=40369,["_boss_restart_timer"]=40374,["_boss_z_phase"]=40375,["_death_accel_fraction"]=40623,["_death_timer"]=40621,["_death_vy"]=40620,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=2140,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=13644,["_fx_boss_project"]=14218,["_fx_build_ground"]=3140,["_fx_build_packet"]=2226,["_fx_buttons"]=37980,["_fx_draw"]=36056,["_fx_draw_count"]=36696,["_fx_em0_geometry"]=16145,["_fx_enemy_collisions"]=15612,["_fx_enemy_em1_update"]=17364,["_fx_enemy_em1_update_reference"]=26033,["_fx_enemy_fire_em1"]=25971,["_fx_enemy_remove"]=25960,["_fx_enemy_render"]=16283,["_fx_enemy_render_bullets"]=16562,["_fx_far_d_acc"]=37992,["_fx_far_u_acc"]=37990,["_fx_fire_actions"]=37983,["_fx_frame"]=17658,["_fx_ground_c1ptr"]=39748,["_fx_ground_c3ptr"]=39750,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=37999,["_fx_ground_color3"]=38449,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39714,["_fx_ground_far_xptr"]=39744,["_fx_ground_far_y"]=39754,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39752,["_fx_ground_horizontal"]=38899,["_fx_ground_hptr"]=39709,["_fx_ground_native"]=3228,["_fx_ground_palette_record"]=39712,["_fx_ground_phase"]=37979,["_fx_ground_vptr"]=39746,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39711,["_fx_init"]=18421,["_fx_input"]=37982,["_fx_open_size"]=59572,["_fx_packet"]=36699,["_fx_packet_count"]=36697,["_fx_present"]=334,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=61435,["_fx_stage_render"]=60725,["_fx_stage_update"]=61766,["_fx_submit"]=62119,["_ground_irq_vblank_count"]=37987,["_history_head"]=40370,["_hit_pending"]=37994,["_intro_timer"]=40624,["_legacy_enemy_fire_boss_at"]=24565,["_main"]=18458,["_memcpy"]=62720,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=57078,["_monosh_boss_draw_order_mid"]=59238,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=18647,["_monosh_boss_hp"]=39757,["_monosh_boss_init"]=18490,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=20546,["_monosh_boss_prepare_render"]=18683,["_monosh_boss_render_only"]=13998,["_monosh_boss_should_restart"]=18469,["_monosh_boss_state"]=39756,["_monosh_bullet_reflect_rng"]=40427,["_monosh_collision_bullet_bands"]=40419,["_monosh_combat_build_collision_bands"]=20728,["_monosh_combat_fast_cache_reset"]=15197,["_monosh_combat_fast_frame"]=14413,["_monosh_combat_fast_render"]=14543,["_monosh_combat_fast_render_cached"]=15204,["_monosh_combat_fire_cooldown"]=40428,["_monosh_combat_half_frame"]=40429,["_monosh_combat_init"]=20572,["_monosh_combat_reflect_bullet"]=14842,["_monosh_combat_render"]=20725,["_monosh_combat_update"]=20667,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40584,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40433,["_monosh_enemy_active_count"]=21488,["_monosh_enemy_active_count_value"]=40431,["_monosh_enemy_bullet_count"]=40430,["_monosh_enemy_bullets"]=40513,["_monosh_enemy_camera_delta_cached"]=40582,["_monosh_enemy_collision_cursor"]=40587,["_monosh_enemy_draw_cache_valid"]=40585,["_monosh_enemy_em1_count"]=40583,["_monosh_enemy_em1_phase"]=40558,["_monosh_enemy_em1_shrink"]=40574,["_monosh_enemy_fast_advance"]=16956,["_monosh_enemy_fast_check_player_bullets"]=22578,["_monosh_enemy_fast_render"]=22063,["_monosh_enemy_fast_render_bullets"]=23528,["_monosh_enemy_fast_spawn_due"]=23904,["_monosh_enemy_fast_update_bullets"]=15282,["_monosh_enemy_fire_at"]=21500,["_monosh_enemy_fire_boss_at"]=21529,["_monosh_enemy_fire_em0_fast"]=24963,["_monosh_enemy_frame"]=21291,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40586,["_monosh_enemy_init"]=21142,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40588,["_monosh_enemy_render_only"]=21321,["_monosh_enemy_spawn_index"]=40555,["_monosh_enemy_spawn_wait"]=40556,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=21494,["_monosh_enemy_stage_complete_flag"]=40432,["_monosh_ground_depth_pointer"]=37997,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40611,["_monosh_player_bullet_count"]=40402,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40387,["_monosh_player_can_fire"]=27791,["_monosh_player_draw_asset"]=27807,["_monosh_player_draw_flags"]=27749,["_monosh_player_init"]=27686,["_monosh_player_invuln"]=40614,["_monosh_player_pose"]=40616,["_monosh_player_state"]=40613,["_monosh_player_stumble"]=40615,["_monosh_player_update"]=30139,["_monosh_player_update_reference"]=29016,["_monosh_player_world_active"]=27785,["_monosh_player_x"]=40609,["_monosh_project_x"]=30749,["_monosh_reflected_bullet_count"]=40418,["_monosh_reflected_bullets"]=40403,["_monosh_runtime_fire_actions"]=37984,["_monosh_runtime_frame_counter"]=37985,["_monosh_runtime_paused"]=37989,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40863,["_monosh_stage_collision_bullet_index"]=40864,["_monosh_stage_contact_result"]=40861,["_monosh_stage_draw_cache_valid"]=40862,["_monosh_stage_frame"]=29291,["_monosh_stage_frame_counter"]=40725,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40729,["_monosh_stage_hitbox_count"]=40859,["_monosh_stage_hitboxes"]=40731,["_monosh_stage_init"]=29256,["_monosh_stage_is_clear"]=29340,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40730,["_monosh_stage_need_hitboxes"]=40860,["_monosh_stage_object_count"]=40723,["_monosh_stage_objects"]=40627,["_monosh_stage_render_only"]=29337,["_monosh_stage_spawn_index"]=40724,["_monosh_stage_spawn_wait"]=40727,["_monosh_stage_title_timer"]=40617,["_monosh_title_draw"]=18447,["_monosh_title_visible"]=34997,["_movement_fraction"]=40622,["_old_buttons"]=37995,["_player_flip"]=40625,["_player_fy"]=40618,["_player_run_phase"]=40626,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=15198,["addeq0sp"]=62359,["addeqysp"]=62361,["addysp"]=62377,["addysp1"]=62376,["aslax2"]=62390,["aslax3"]=62401,["aslax4"]=62415,["asrax1"]=62432,["asrax2"]=62442,["asrax3"]=62457,["audio4_first_done"]=744,["audio4_second_done"]=744,["background_done"]=98722,["booleq"]=62682,["boolge"]=62699,["boolgt"]=62697,["boolle"]=62689,["boollt"]=62691,["boolne"]=62676,["booluge"]=62715,["boolugt"]=62713,["boolule"]=62705,["boolult"]=62707,["bullet_render4"]=99584,["c_sp"]=67,["clip_left_found"]=34179,["decsp1"]=62477,["decsp2"]=62486,["decsp3"]=62499,["decsp4"]=62512,["decsp5"]=62525,["dispatch_nonzero"]=98752,["dma_chunk_ready"]=1101,["dma_finished"]=1804,["dma_started"]=1237,["fast_base_ready"]=36611,["fast_fail"]=36653,["fast_tiles"]=36578,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=2119,["fx_add_next_bounds"]=15281,["fx_audio_init"]=62185,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=62236,["fx_audio_sent"]=5653,["fx_build_obj"]=2581,["fx_commit_dma"]=15281,["fx_dma_bytes"]=35926,["fx_dma_count"]=35924,["fx_dma_desc"]=35928,["fx_em1_open_sizes"]=59615,["fx_emit_native"]=16819,["fx_is_obj"]=2533,["fx_latch_obj"]=2929,["fx_obj_build_done"]=2927,["fx_obj_count"]=35636,["fx_obj_dma_bytes"]=35642,["fx_obj_next"]=35364,["fx_obj_overflow"]=35640,["fx_obj_present"]=35500,["fx_obj_present_count"]=35638,["fx_obj_upload_done"]=3138,["fx_plan_dma"]=15262,["fx_project16"]=30779,["fx_read_gsu_spans"]=15207,["fx_reset_next_bounds"]=15281,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35668,["fx_upload_ground"]=3565,["fx_upload_obj"]=2975,["game_started"]=0,["generic"]=99536,["ground_done"]=3518,["ground_empty"]=3659,["gsu_uv_cache"]=99207,["half_dma_finished"]=1243,["incsp1"]=62605,["incsp2"]=62620,["incsp3"]=62634,["incsp4"]=62639,["incsp5"]=62644,["incsp6"]=62649,["incsp7"]=62654,["incsp8"]=62659,["initialized"]=2294,["integer_render4"]=100384,["invoke_row"]=34223,["irq_game"]=33436,["keys"]=35236,["ldaidx"]=62664,["logic_finished"]=724,["margin_render"]=99600,["math4_lift_result"]=2217,["memcpy_getparams"]=62761,["memcpy_upwards"]=62723,["mulax10"]=62780,["mulax3"]=62805,["mulax5"]=62822,["mulax6"]=62842,["mulax7"]=62864,["negax"]=62893,["nmi_game"]=33458,["order"]=35108,["packet_done"]=2381,["packet_work"]=6,["pipe_bw_busy"]=35046,["pipe_complete"]=35042,["pipe_dma_measured_end"]=1264,["pipe_front_slot"]=35036,["pipe_ground_extra"]=3584,["pipe_ground_extra_end"]=4744,["pipe_ground_wait"]=755,["pipe_irq"]=922,["pipe_irq_done"]=1344,["pipe_irq_exit"]=1355,["pipe_irq_transfer"]=944,["pipe_missed"]=35064,["pipe_obj_pointer"]=35086,["pipe_pending"]=35040,["pipe_presented_irq"]=35068,["pipe_records"]=1024,["pipe_render_slot"]=35034,["pipe_stage_convert"]=1805,["pipe_stage_done"]=2080,["pipe_status"]=35052,["pipe_target_slot"]=35038,["pipe_wait_dma"]=953,["player4_next"]=35644,["player4_present"]=35646,["player4_upload_bytes"]=35650,["popax"]=62612,["popptr1"]=62907,["popsargsudiv16"]=62997,["prefetch_finished"]=1339,["ptr1"]=75,["ptr2"]=77,["ptr3"]=79,["ptr4"]=81,["push0"]=62943,["pusha"]=62925,["pusha0"]=62945,["pusha0sp"]=62921,["pushax"]=62947,["pushaysp"]=62923,["pushw0sp"]=62969,["pushwysp"]=62971,["regbank"]=87,["regsave"]=71,["render_entry"]=98304,["render_finished"]=740,["render_second_finished"]=740,["render_second_started"]=740,["render_started"]=697,["render_stop"]=99754,["reset"]=32768,["row_done"]=34287,["sa1_clear_done"]=683,["sa1_clear_start"]=565,["sa1_compact"]=37121,["sa1_cover_row"]=36332,["sa1_dirty_done"]=576,["sa1_dma_begin"]=56592,["sa1_dma_end"]=56628,["sa1_dma_irq"]=56873,["sa1_dma_poll"]=56639,["sa1_draw_done"]=34311,["sa1_draw_rows"]=36655,["sa1_draw_start"]=702,["sa1_edge_prepare"]=36849,["sa1_edge_restore"]=37036,["sa1_edge_save"]=36927,["sa1_entry"]=512,["sa1_fb_read"]=56861,["sa1_fb_write"]=56867,["sa1_find_shape"]=36096,["sa1_merge_dma"]=56925,["sa1_native_done"]=34311,["sa1_near_row"]=37281,["sa1_output_done"]=34319,["sa1_plan_dirty"]=34713,["sa1_prepare_transfer"]=35426,["sa1_select_cover"]=36182,["sa1_snapshot"]=56696,["sa1_sprite_begin"]=33482,["sa1_sprite_done"]=34298,["sa1_tile_masks"]=35529,["sa1_tiles_clear"]=35661,["sa1_tiles_transfer"]=35676,["sa1_try_fast"]=36419,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=62390,["shlax3"]=62401,["shlax4"]=62415,["shrax1"]=63029,["shrax3"]=63037,["shrax4"]=63051,["sorted"]=2360,["sreg"]=69,["stage_busy"]=35098,["stage_update_done"]=62117,["staspidx"]=63068,["stax0sp"]=63090,["staxspidx"]=63101,["staxysp"]=63092,["subysp"]=63149,["tmp1"]=83,["tmp2"]=84,["tmp3"]=85,["tmp4"]=86,["tosadda0"]=62331,["tosaddax"]=62333,["tosdiva0"]=62538,["tosdivax"]=62540,["tosicmp"]=62561,["tosicmp0"]=62559,["tossuba0"]=63128,["tossubax"]=63130,["tosudiva0"]=63162,["tosudivax"]=63164,["tosumoda0"]=63241,["tosumodax"]=63243,["transfer_chunk"]=1101,["udiv16"]=63179,["L1"]=63213,["@L1"]=63231,["Pos"]=62556,["@L3"]=62597,["@L4"]=62598,["@L2"]=63235,["L0"]=63189,["ret0"]=62678,["ret1"]=62684,["L3"]=62750,["done"]=62758,["L2"]=63022,["@L0"]=63220,["udiv16by8a"]=63220}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/stageprefetch"
local maxframe=600
local targetPresents=0
local scenario="stageprefetch"
local padded=false
local pipeline=true
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local completedPackets={}
local outputJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={17663},["_monosh_combat_fast_frame"]={18056},["_monosh_combat_render"]={18063},["_monosh_enemy_frame"]={18111},["_monosh_stage_frame"]={18133},["_monosh_boss_frame"]={18225},["_monosh_boss_prepare_render"]={18242},["_monosh_boss_render_only"]={18247,18266},["_fx_build_packet"]={18413},["_fx_build_ground"]={18416}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,0x7f0000+site,0x7f0000+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,0x7f0000+site+3,0x7f0000+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local a=labels[name]+(cpu==emu.cpuType.snes and 0x7f0000 or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
local packetClock,irqTicks,irqClock=0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 cb('pipe_irq',function()irqClock=emu.getState().masterClock end)
 cb('pipe_irq_exit',function()irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank-0x40)*65536+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()
  local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,5-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_sort_packet or labels.sa1_temporal_prepare then
 cb(labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare',function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability')end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs')end
   for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
