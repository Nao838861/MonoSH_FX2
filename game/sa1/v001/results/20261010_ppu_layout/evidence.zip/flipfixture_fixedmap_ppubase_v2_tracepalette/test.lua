local labels={["LoadAudioData"]=64006,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64609,["Tad_GetSong"]=64713,["Tad_GlobalVolumesPersist"]=64741,["Tad_GlobalVolumesResetOnSongStart"]=64735,["Tad_Init"]=64225,["Tad_IsLoaderActive"]=64767,["Tad_IsSfxPlaying"]=64781,["Tad_IsSongLoaded"]=64775,["Tad_IsSongPlaying"]=64787,["Tad_LoadSong"]=64668,["Tad_LoadSongIfChanged"]=64701,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=64352,["Tad_QueueCommand"]=64625,["Tad_QueueCommandOverride"]=64630,["Tad_QueuePannedSoundEffect"]=64647,["Tad_QueueSoundEffect"]=64657,["Tad_ReloadCommonAudioData"]=64717,["Tad_SetTransferSize"]=64747,["Tad_SongsStartImmediately"]=64723,["Tad_SongsStartPaused"]=64729,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=51,["Tad_sfxQueue_sfx"]=50,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5943,["__BULLETJIT_LOAD__"]=98304,["__BULLETJIT_RUN__"]=768,["__BULLETJIT_SIZE__"]=416,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65348,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=9448,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__LEFTJIT_LOAD__"]=98720,["__LEFTJIT_RUN__"]=768,["__LEFTJIT_SIZE__"]=373,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=65039,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=214,["__STARTUP__"]=1,["_abs"]=64979,["_boss_age"]=40447,["_boss_attribute_cache"]=40282,["_boss_attribute_cache_count"]=40444,["_boss_attribute_z_cache"]=40426,["_boss_dda_phase"]=40665,["_boss_dda_x"]=40671,["_boss_dda_y"]=40677,["_boss_death_parts"]=40449,["_boss_death_timer"]=40448,["_boss_fire_gap"]=40458,["_boss_fire_round"]=40455,["_boss_fire_shots"]=40457,["_boss_fire_state"]=40454,["_boss_fire_volley"]=40456,["_boss_history_x"]=39898,["_boss_history_y"]=40026,["_boss_history_z"]=40154,["_boss_last_vblank"]=39834,["_boss_motion_steps"]=40453,["_boss_part_active"]=39862,["_boss_part_bottom"]=39844,["_boss_part_fall_fraction"]=39889,["_boss_part_fall_velocity"]=39880,["_boss_part_timer"]=39871,["_boss_part_x"]=39835,["_boss_part_z"]=39853,["_boss_path_half"]=40452,["_boss_player_bottom"]=40461,["_boss_player_x"]=40459,["_boss_render_camera_delta"]=40445,["_boss_restart_timer"]=40450,["_boss_z_phase"]=40451,["_death_accel_fraction"]=40699,["_death_timer"]=40697,["_death_vy"]=40696,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=3342,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=15734,["_fx_boss_project"]=16308,["_fx_build_ground"]=4356,["_fx_build_packet"]=3428,["_fx_buttons"]=38056,["_fx_draw"]=36132,["_fx_draw_count"]=36772,["_fx_em0_geometry"]=18235,["_fx_enemy_collisions"]=17702,["_fx_enemy_em1_update"]=19454,["_fx_enemy_em1_update_reference"]=28123,["_fx_enemy_fire_em1"]=28061,["_fx_enemy_remove"]=28050,["_fx_enemy_render"]=18373,["_fx_enemy_render_bullets"]=18652,["_fx_far_d_acc"]=38068,["_fx_far_u_acc"]=38066,["_fx_fire_actions"]=38059,["_fx_frame"]=19748,["_fx_ground_c1ptr"]=39824,["_fx_ground_c3ptr"]=39826,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38075,["_fx_ground_color3"]=38525,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39790,["_fx_ground_far_xptr"]=39820,["_fx_ground_far_y"]=39830,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39828,["_fx_ground_horizontal"]=38975,["_fx_ground_hptr"]=39785,["_fx_ground_native"]=4444,["_fx_ground_palette_record"]=39788,["_fx_ground_phase"]=38055,["_fx_ground_vptr"]=39822,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39787,["_fx_init"]=20511,["_fx_input"]=38058,["_fx_open_size"]=61662,["_fx_packet"]=36775,["_fx_packet_count"]=36773,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=63525,["_fx_stage_render"]=62815,["_fx_stage_update"]=63856,["_fx_submit"]=64209,["_ground_irq_vblank_count"]=38063,["_history_head"]=40446,["_hit_pending"]=38070,["_intro_timer"]=40700,["_legacy_enemy_fire_boss_at"]=26655,["_main"]=20548,["_memcpy"]=64810,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59686,["_monosh_boss_draw_order_mid"]=61846,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=20737,["_monosh_boss_hp"]=39833,["_monosh_boss_init"]=20580,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=22636,["_monosh_boss_prepare_render"]=20773,["_monosh_boss_render_only"]=16088,["_monosh_boss_should_restart"]=20559,["_monosh_boss_state"]=39832,["_monosh_bullet_reflect_rng"]=40503,["_monosh_collision_bullet_bands"]=40495,["_monosh_combat_build_collision_bands"]=22818,["_monosh_combat_fast_cache_reset"]=17287,["_monosh_combat_fast_frame"]=16503,["_monosh_combat_fast_render"]=16633,["_monosh_combat_fast_render_cached"]=17294,["_monosh_combat_fire_cooldown"]=40504,["_monosh_combat_half_frame"]=40505,["_monosh_combat_init"]=22662,["_monosh_combat_reflect_bullet"]=16932,["_monosh_combat_render"]=22815,["_monosh_combat_update"]=22757,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40660,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40509,["_monosh_enemy_active_count"]=23578,["_monosh_enemy_active_count_value"]=40507,["_monosh_enemy_bullet_count"]=40506,["_monosh_enemy_bullets"]=40589,["_monosh_enemy_camera_delta_cached"]=40658,["_monosh_enemy_collision_cursor"]=40663,["_monosh_enemy_draw_cache_valid"]=40661,["_monosh_enemy_em1_count"]=40659,["_monosh_enemy_em1_phase"]=40634,["_monosh_enemy_em1_shrink"]=40650,["_monosh_enemy_fast_advance"]=19046,["_monosh_enemy_fast_check_player_bullets"]=24668,["_monosh_enemy_fast_render"]=24153,["_monosh_enemy_fast_render_bullets"]=25618,["_monosh_enemy_fast_spawn_due"]=25994,["_monosh_enemy_fast_update_bullets"]=17372,["_monosh_enemy_fire_at"]=23590,["_monosh_enemy_fire_boss_at"]=23619,["_monosh_enemy_fire_em0_fast"]=27053,["_monosh_enemy_frame"]=23381,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40662,["_monosh_enemy_init"]=23232,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40664,["_monosh_enemy_render_only"]=23411,["_monosh_enemy_spawn_index"]=40631,["_monosh_enemy_spawn_wait"]=40632,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=23584,["_monosh_enemy_stage_complete_flag"]=40508,["_monosh_ground_depth_pointer"]=38073,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40687,["_monosh_player_bullet_count"]=40478,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40463,["_monosh_player_can_fire"]=29881,["_monosh_player_draw_asset"]=29897,["_monosh_player_draw_flags"]=29839,["_monosh_player_init"]=29776,["_monosh_player_invuln"]=40690,["_monosh_player_pose"]=40692,["_monosh_player_state"]=40689,["_monosh_player_stumble"]=40691,["_monosh_player_update"]=32229,["_monosh_player_update_reference"]=31106,["_monosh_player_world_active"]=29875,["_monosh_player_x"]=40685,["_monosh_project_x"]=32839,["_monosh_reflected_bullet_count"]=40494,["_monosh_reflected_bullets"]=40479,["_monosh_runtime_fire_actions"]=38060,["_monosh_runtime_frame_counter"]=38061,["_monosh_runtime_paused"]=38065,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40939,["_monosh_stage_collision_bullet_index"]=40940,["_monosh_stage_contact_result"]=40937,["_monosh_stage_draw_cache_valid"]=40938,["_monosh_stage_frame"]=31381,["_monosh_stage_frame_counter"]=40801,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40805,["_monosh_stage_hitbox_count"]=40935,["_monosh_stage_hitboxes"]=40807,["_monosh_stage_init"]=31346,["_monosh_stage_is_clear"]=31430,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40806,["_monosh_stage_need_hitboxes"]=40936,["_monosh_stage_object_count"]=40799,["_monosh_stage_objects"]=40703,["_monosh_stage_render_only"]=31427,["_monosh_stage_spawn_index"]=40800,["_monosh_stage_spawn_wait"]=40803,["_monosh_stage_title_timer"]=40693,["_monosh_title_draw"]=20537,["_monosh_title_visible"]=34997,["_movement_fraction"]=40698,["_old_buttons"]=38071,["_player_flip"]=40701,["_player_fy"]=40694,["_player_run_phase"]=40702,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=17288,["addeq0sp"]=64449,["addeqysp"]=64451,["addysp"]=64467,["addysp1"]=64466,["aslax2"]=64480,["aslax3"]=64491,["aslax4"]=64505,["asrax1"]=64522,["asrax2"]=64532,["asrax3"]=64547,["audio4_first_done"]=828,["audio4_second_done"]=828,["background_done"]=110786,["booleq"]=64772,["boolge"]=64789,["boolgt"]=64787,["boolle"]=64779,["boollt"]=64781,["boolne"]=64766,["booluge"]=64805,["boolugt"]=64803,["boolule"]=64795,["boolult"]=64797,["bullet_render4"]=111648,["c_sp"]=72,["clip_left_found"]=34353,["compact_ppu_boot"]=99254,["decsp1"]=64567,["decsp2"]=64576,["decsp3"]=64589,["decsp4"]=64602,["decsp5"]=64615,["dispatch_nonzero"]=110816,["dma_chunk_ready"]=1325,["dma_finished"]=2796,["dma_started"]=1525,["fast_base_ready"]=36830,["fast_fail"]=36879,["fast_tiles"]=36797,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=3321,["fx_add_next_bounds"]=17371,["fx_audio_init"]=64793,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64844,["fx_audio_sent"]=5653,["fx_build_obj"]=3794,["fx_commit_dma"]=17371,["fx_dma_bytes"]=36002,["fx_dma_count"]=36000,["fx_dma_desc"]=36004,["fx_em1_open_sizes"]=61705,["fx_emit_native"]=18909,["fx_is_obj"]=3746,["fx_latch_obj"]=4142,["fx_obj_build_done"]=4140,["fx_obj_count"]=35646,["fx_obj_dma_bytes"]=35652,["fx_obj_next"]=35374,["fx_obj_overflow"]=35650,["fx_obj_present"]=35510,["fx_obj_present_count"]=35648,["fx_obj_upload_done"]=4354,["fx_plan_dma"]=17352,["fx_project16"]=32869,["fx_read_gsu_spans"]=17297,["fx_reset_next_bounds"]=17371,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35678,["fx_upload_ground"]=4714,["fx_upload_obj"]=4188,["game_started"]=0,["generic"]=111600,["ground_done"]=4667,["ground_empty"]=4808,["gsu_uv_cache"]=111271,["half_dma_finished"]=1531,["idle_clear_dma"]=101985,["idle_clear_done"]=102041,["incsp1"]=64695,["incsp2"]=64710,["incsp3"]=64724,["incsp4"]=64729,["incsp5"]=64734,["incsp6"]=64739,["incsp7"]=64744,["incsp8"]=64749,["initialized"]=3496,["integer_render4"]=112448,["invoke_row"]=34397,["irq_game"]=33469,["keys"]=35246,["ldaidx"]=64754,["logic_finished"]=805,["margin_render"]=111664,["math4_lift_result"]=3419,["memcpy_getparams"]=64851,["memcpy_upwards"]=64813,["mulax10"]=64870,["mulax3"]=64895,["mulax5"]=64912,["mulax6"]=64932,["mulax7"]=64954,["negax"]=64983,["nmi_game"]=33505,["order"]=35118,["packet_done"]=3594,["packet_work"]=9,["pfBytes"]=35792,["pfDesc"]=35794,["pfPartial"]=35790,["pipe_available"]=35096,["pipe_bw_busy"]=35046,["pipe_collect"]=871,["pipe_complete"]=35042,["pipe_dma_chunk"]=35106,["pipe_dma_measured_end"]=1552,["pipe_fast_begin"]=2085,["pipe_fast_done"]=2606,["pipe_fast_partial_done"]=3260,["pipe_fast_unavailable"]=2614,["pipe_flip"]=2616,["pipe_front_slot"]=35036,["pipe_ground_extra"]=45068,["pipe_ground_extra_end"]=47968,["pipe_ground_wait"]=844,["pipe_irq"]=1046,["pipe_irq_checked"]=1660,["pipe_irq_done"]=1652,["pipe_irq_exit"]=1683,["pipe_irq_transfer"]=1068,["pipe_main_offset"]=35088,["pipe_missed"]=35078,["pipe_near_build"]=14929,["pipe_near_prepare_next"]=14823,["pipe_near_prepared"]=35788,["pipe_near_present"]=35786,["pipe_near_select"]=15266,["pipe_next_slot"]=35090,["pipe_obj_pointer"]=35102,["pipe_pending"]=35040,["pipe_prefix_plan"]=15485,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_time_left"]=1729,["pipe_wait_dma"]=1104,["pipe_write_slot"]=35030,["player4_next"]=35654,["player4_present"]=35656,["player4_upload_bytes"]=35660,["player4_uploaded"]=35658,["popax"]=64702,["popptr1"]=64997,["popsargsudiv16"]=65087,["prefetch_finished"]=1631,["ptr1"]=80,["ptr2"]=82,["ptr3"]=84,["ptr4"]=86,["push0"]=65033,["pusha"]=65015,["pusha0"]=65035,["pusha0sp"]=65011,["pushax"]=65037,["pushaysp"]=65013,["pushw0sp"]=65059,["pushwysp"]=65061,["regbank"]=92,["regsave"]=76,["render_entry"]=110368,["render_finished"]=824,["render_second_finished"]=824,["render_second_started"]=824,["render_started"]=778,["render_stop"]=111818,["reset"]=32768,["row_done"]=34461,["sa1_background_cache"]=58262,["sa1_background_initialize"]=58580,["sa1_bullet_cache_init"]=100820,["sa1_bullet_cache_prepare"]=100821,["sa1_clear_done"]=702,["sa1_clear_start"]=530,["sa1_clear_wide_band"]=59150,["sa1_compact"]=37487,["sa1_cover_row"]=36507,["sa1_deep_rebase"]=57907,["sa1_dirty_done"]=553,["sa1_dirty_row_rect"]=35677,["sa1_dirty_rows"]=57942,["sa1_dma_begin"]=57058,["sa1_dma_end"]=57094,["sa1_dma_irq"]=57339,["sa1_dma_poll"]=57105,["sa1_dma_try_begin"]=57024,["sa1_draw_done"]=34485,["sa1_draw_rows"]=36881,["sa1_draw_start"]=721,["sa1_edge_cpu_restore"]=58904,["sa1_edge_cpu_save"]=58860,["sa1_edge_prepare"]=37146,["sa1_edge_restore"]=37370,["sa1_edge_save"]=37228,["sa1_entry"]=512,["sa1_fb_read"]=57327,["sa1_fb_write"]=57333,["sa1_find_shape"]=36248,["sa1_ground_compiled"]=15439,["sa1_idle_clear"]=101823,["sa1_left_hint_draw"]=102100,["sa1_list_sort"]=15289,["sa1_merge_dma"]=59533,["sa1_native_done"]=34485,["sa1_near_patch"]=58789,["sa1_near_patch_bounds"]=58703,["sa1_near_row"]=37647,["sa1_occupancy_capture"]=57391,["sa1_output_done"]=34501,["sa1_plan_dirty"]=34903,["sa1_prepare_transfer"]=35574,["sa1_select_cover"]=36357,["sa1_small_edge_prepare"]=58974,["sa1_small_edge_restore"]=59139,["sa1_small_edge_save"]=59128,["sa1_snapshot"]=57162,["sa1_sparse_direct_finish"]=102057,["sa1_sparse_map_prepare"]=102056,["sa1_sprite_begin"]=33587,["sa1_sprite_done"]=34472,["sa1_stack_clear_band"]=59212,["sa1_stack_clear_line"]=59387,["sa1_stack_clear_prepare"]=59195,["sa1_tile_masks"]=35681,["sa1_tiles_clear"]=35813,["sa1_tiles_transfer"]=35828,["sa1_transfer_mask_capture"]=57624,["sa1_transfer_mask_prepare"]=57691,["sa1_try_fast"]=36594,["scaled_render4"]=112176,["scaled_unpacked4"]=112336,["shlax2"]=64480,["shlax3"]=64491,["shlax4"]=64505,["shrax1"]=65119,["shrax3"]=65127,["shrax4"]=65141,["sorted"]=3573,["sparse_direct_overflow"]=102099,["sreg"]=74,["stage_update_done"]=64207,["staspidx"]=65158,["stax0sp"]=65180,["staxspidx"]=65191,["staxysp"]=65182,["subysp"]=65239,["tm_first"]=99345,["tm_length"]=99857,["tm_rest"]=100369,["tmp1"]=88,["tmp2"]=89,["tmp3"]=90,["tmp4"]=91,["tosadda0"]=64421,["tosaddax"]=64423,["tosdiva0"]=64628,["tosdivax"]=64630,["tosicmp"]=64651,["tosicmp0"]=64649,["tossuba0"]=65218,["tossubax"]=65220,["tosudiva0"]=65252,["tosudivax"]=65254,["tosumoda0"]=65331,["tosumodax"]=65333,["transfer_chunk"]=1325,["udiv16"]=65269,["L1"]=65303,["@L1"]=65321,["Pos"]=64646,["@L3"]=64687,["@L4"]=64688,["@L2"]=65325,["L0"]=65279,["ret0"]=64768,["ret1"]=64774,["L3"]=64840,["done"]=64848,["L2"]=65112,["@L0"]=65310,["udiv16by8a"]=65310}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/flipfixture_fixedmap_ppubase_v2_tracepalette"
local maxframe=1800
local targetPresents=120
local scenario="flipfixture_fixedmap_ppubase_v2_tracepalette"
local function captureGeneration(g)
 return g<=120 or g%60==0 or (scenario:match('captureburst') and g>=530 and g<=570)
end
local padded=false
local pipeline=true
local vramPrefetch3=true
local vramFourShared=false
local fixedMap=true
local fixedMapDelta=false
local fixedMapDeltaDma=false
local packetOffload=false
local packetIramArrays=false
local packetRunning=false
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local finishedCapture=false
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local pageCommit=nil
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuActiveParts,cpuActiveEntries={},{}
local irqTicks,irqClock,irqDepth=0,0,0
local activeBegin=0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local expectedPalette={0,0,154,119,254,82,94,10,101,15,113,55,83,90,141,61,1,6,74,38,76,8,53,0,0,4,55,101,109,97,120,45}
if scenario:match('tracepalette') then
 local z=assert(io.open(output..'/palette_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  if field>90 then
   local s=emu.getState()
   z:write(string.format('{"field":%d,"line":%d,"hclock":%d,"address":%d,"value":%d,"cgadd":%d,"pc":%d}\n',field,s['ppu.scanline'],s['memoryManager.hClock'],address,value,s['ppu.cgramAddress'],s['cpu.pc']));z:flush()
  end
 end,emu.callbackType.write,32,63,emu.cpuType.snes,emu.memType.snesCgRam)
end
if scenario:match('tracedma') then
 local z=assert(io.open(output..'/sa1_dma_writes.jsonl','w'))
 local blankLog=assert(io.open(output..'/blank_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local st=emu.getState()
  blankLog:write(string.format('{"field":%d,"line":%d,"value":%d,"pc":%d,"hdmaAddress":%d,"hdmaCount":%d}\n',field,st['ppu.scanline'],value,st['cpu.pc'],st['dmaController.channel[1].hdmaTableAddress'],st['dmaController.channel[1].hdmaLineCounterAndRepeat']));blankLog:flush()
 end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
 local reads=assert(io.open(output..'/cpu_dma_reads.jsonl','w'));local readCount=0
 emu.addMemoryCallback(function(address,value)
  if presents==0 and emu.read16(0x311e,emu.memType.snesMemory)==1 and readCount<800 then
   readCount=readCount+1;local s=emu.getState()
   reads:write(string.format('{"address":%d,"value":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',address,value,s['cart.coprocessor.dmaSrcAddr'],s['cart.coprocessor.dmaDestAddr'],tostring(s['cart.coprocessor.charConvDmaActive']),tostring(s['ppu.forcedBlank']),s['ppu.scanline']));reads:flush()
  end
 end,emu.callbackType.read,0x400000,0x43ffff,emu.cpuType.snes,emu.memType.snesMemory)
 emu.addMemoryCallback(function(address,value)
  if emu.read16(0x11e,emu.memType.sa1Memory)==1 then
   local s=emu.getState()
   z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,emu.memType.sa1Memory),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
  end
 end,emu.callbackType.write,0x2230,0x2239,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local cpuStageJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write16(4194304+labels[name],value,emu.memType.snesMemory)end
end
for name,sites in pairs({["_fx_read_input"]={19753},["_monosh_combat_fast_frame"]={20146},["_monosh_combat_render"]={20153},["_monosh_enemy_frame"]={20201},["_monosh_stage_frame"]={20223},["_monosh_boss_frame"]={20315},["_monosh_boss_prepare_render"]={20332},["_monosh_boss_render_only"]={20337,20356},["_fx_build_packet"]={20503},["_fx_build_ground"]={20506}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock;cpuActiveEntries[name]=activeClock() end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()
   cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272
   cpuActiveParts[name]=(cpuActiveParts[name] or 0)+(activeClock()-cpuActiveEntries[name])/21477.272
   if name=='_fx_read_input' and scenario:match('detinput') then
    local phase=logic%240
    local value=0x80
    if scenario:match('move') then
     value=value+(phase<60 and 0x100 or phase<120 and 0x800 or phase<180 and 0x200 or 0x400)
    end
    emu.write16(0x7e0000+labels._fx_buttons,value,emu.memType.snesMemory)
   end
  end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write(4194304+labels[name],value,emu.memType.snesMemory)end
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local gameHook=false and (name=='_fx_build_packet' or name=='initialized' or name=='sorted' or name=='packet_done' or name=='sa1_list_sort')
 local packetHook=packetOffload and (name=='initialized' or name=='sorted' or name=='packet_done' or name=='sa1_list_sort')
 if gameHook or packetHook then cpu=emu.cpuType.sa1 end
 if packetHook then local run=fn;fn=function()if packetRunning then run()end end end
 local irqName=name:match('^pipe_') or name=='p3PumpBlank' or name=='stage_time_ok' or name=='stage_converted' or name=='stage_too_large' or name=='fx_obj_upload_done' or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(packetHook and 0 or gameHook and 0xc10000 or cpu==emu.cpuType.snes and labels[name]<65536 and (irqName and 12648448 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()if finishedCapture then return end;local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if false then
 local log=assert(io.open(output..'/game_offload.jsonl','w'))
 local active=false;local begin=0
 cb('sa1_game_begin',function()active=true;begin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_game_end',function()
  active=false
  local mt=emu.memType.sa1Memory
  assert(emu.read16(0x435100+labels.c_sp,mt)==0x7c00,'game software stack did not balance')
  for i=0,62,2 do
   assert(emu.read16(0x437b00+i,mt)==0xa55a,'game software stack crossed scratch boundary')
   assert(emu.read16(0x437e00+i,mt)==0xa55a,'game hardware stack crossed software stack boundary')
  end
  log:write(string.format('{"field":%d,"logic":%d,"ms":%.6f}\n',field,logic,(emu.getState().masterClock-begin)/21477.272));log:flush()
 end,emu.cpuType.sa1)
 emu.addMemoryCallback(function()
  if active then local f=assert(io.open(output..'/failure.txt','w'));f:write('SA-1 game accessed S-CPU arithmetic registers');f:close();emu.stop(1)end
 end,emu.callbackType.write,0x4202,0x4206,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if labels.fallback_publish and scenario:match('tracefallback') then
 local f=assert(io.open(output..'/fallback_debug.jsonl','w'))
 cb('fallback_publish',function()
  local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt);local page=emu.read16(record+6,mt)*2
  local outside={}
  for tile=32,767 do
   local mask=emu.read(0x7e0000+labels.fbMasks+slot*128+math.floor(tile/8),mt)
   if (mask & (1<<(tile%8)))==0 then
    for b=0,31 do
     if emu.read(page+tile*32+b,emu.memType.snesVideoRam)~=0 then outside[#outside+1]=tile;break end
    end
   end
  end
  f:write(string.format('{"generation":%d,"page":%d,"outside":[%s]}\n',gen,page,table.concat(outside,',')));f:flush()
 end)
 if labels.sa1_fallback_build then cb('sa1_fallback_build',function()
  local s=emu.getState()
  f:write(string.format('{"field":%d,"sa1Stack":%d}\n',field,s['cart.coprocessor.cpu.sp'] or -1));f:flush()
 end,emu.cpuType.sa1)end
end
emu.addMemoryCallback(function(address,value)
 local line=emu.getState()['ppu.scanline']
 if field>85 and (line>=203 or line<21) and line<225 and (value&0x80)==0 then
  local f=assert(io.open(output..'/failure.txt','w'));f:write('HDMA unblanked reserved DMA lines field='..field..' line='..line..' value='..value);f:close()
  local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)
 end
end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
-- VRAM/OAM DMA�͎��ۂ�forced blank�܂���VBLANK���ɊJ�n����B
emu.addMemoryCallback(function(address,value)
 if field>90 and (value&1)~=0 then
  local bb=emu.read(0x4301,emu.memType.snesMemory)
  if bb==0x18 or bb==4 then
   local st=emu.getState()
   if emu.read16(0x4305,emu.memType.snesMemory)==0 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('zero-length VRAM/OAM DMA would transfer 65536 bytes field='..field);f:close();emu.stop(1)
   end
   if vramPrefetch3 and bb==0x18 then
    local first=(st['ppu.vramAddress']&0x7fff)*2
    local last=first+emu.read16(0x4305,emu.memType.snesMemory)
    local fixedOverlap=(first<1024 and last>0) or (first<0x4400 and last>0x4000)
    if vramFourShared then fixedOverlap=(first<0x9000 and last>0x8c00) or (first<0xc000 and last>0xbc00) end
    if fixedMap then
     local playerUpload=first==0xc800 and last==0xcb80 and emu.read(0x4304,emu.memType.snesMemory)==0xdf
     local mapUpload=fixedMapDelta and first==0xc040 and last==0xc600 and emu.read(0x4304,emu.memType.snesMemory)==0x7e
     if fixedMapDeltaDma and first>=0xbc40 and last<=0xc200 and emu.read(0x4304,emu.memType.snesMemory)==1 then mapUpload=true end
     fixedOverlap=not (playerUpload or mapUpload or (first>=0x20 and last<=0x5c20) or (first>=0x6020 and last<=0xbc20))
    end
    if fixedOverlap then
     local f=assert(io.open(output..'/failure.txt','w'))
     f:write('frame DMA overwrites fixed BG2 CHR field='..field..' first='..first..' last='..last);f:close();emu.stop(1)
    end
   end
   if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('VRAM/OAM DMA started outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
   end
  end
 end
end,emu.callbackType.write,0x420b,0x420b,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(function(address,value)
 if field>90 then
  local st=emu.getState()
  if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write('BG1 page changed outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
  end
  pageCommit={field=field,line=st['ppu.scanline'],clock=st.masterClock}
 end
end,emu.callbackType.write,0x210b,0x210b,emu.cpuType.snes,emu.memType.snesMemory)
local packetClock=0
if pipeline then
 local function irqEntry()if irqDepth==0 then irqClock=emu.getState().masterClock end;irqDepth=irqDepth+1 end
 cb('pipe_irq',irqEntry)
 if labels.p3PumpBlank then cb('p3PumpBlank',irqEntry)end
 cb('pipe_irq_exit',function()irqDepth=irqDepth-1;assert(irqDepth>=0,'IRQ accounting underflow');if irqDepth==0 then irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end end)
 emu.addMemoryCallback(function(address,value)
  if irqDepth>0 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write(string.format('IRQ modified game math register $%04x at field %d',address,field));f:close()
   emu.stop(1)
  end
 end,emu.callbackType.write,0x4202,0x4206,emu.cpuType.snes,emu.memType.snesMemory)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
if packetOffload and labels.sa1_packet_finished then
 local packetLog=assert(io.open(output..'/packet_prepare.jsonl','w'))
 local packetBegin=0
 cb('sa1_packet_prepare',function()packetRunning=true;packetBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_packet_finished',function()
  packetLog:write(string.format('{"field":%d,"ms":%.6f,"inputCount":%d,"outputCount":%d}\n',field,(emu.getState().masterClock-packetBegin)/21477.272,emu.read16(0x431404,emu.memType.sa1Memory),emu.read16(0x431402,emu.memType.sa1Memory)));packetLog:flush()
  packetRunning=false
 end,emu.cpuType.sa1)
end
if not packetOffload then for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done','pipe_prefix_plan','pipe_fast_begin','pipe_fast_partial_done','pipe_collect','pipe_flip'})do
 if labels[name] then
  cb(name,function()
   if presents<10 or (scenario:match('timing') and field>=620 and field<=650) then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 end
 cb('prefetch_finished',function()
  if true then return end
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if captureGeneration(gen) then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb(labels.pipe_irq_checked and 'pipe_irq_checked' or 'pipe_irq_done',function()
  -- IRQ�����̃L���[�Ǘ��͕\���������s�ł���BPPU�̎��]���E�ؑֈʒu��ʁX�Ɍ�������B
  local line=emu.getState()['ppu.scanline']
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_list_sort or labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_list_sort and 'sa1_list_sort' or labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=(false or packetOffload) and emu.memType.sa1Memory or emu.memType.snesMemory;local base=packetOffload and (packetIramArrays and 0 or 0x430000) or false and 4194304 or 0x7e0000
  local n=packetOffload and emu.read16(0x700+labels.packet_work+8,mt) or false and emu.read16(labels.packet_work+8,emu.memType.sa1Memory) or emu.read16(base+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(base+labels.keys+i,mt),value=emu.read16(base+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   local base=packetOffload and (packetIramArrays and 0 or 0x430000) or false and 4194304 or 0x7e0000
   local mt=(false or packetOffload) and emu.memType.sa1Memory or emu.memType.snesMemory
   for i,v in ipairs(sortReference)do assert(emu.read16(base+labels.order+(i-1)*2,mt)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(base+labels.order+(i-1)*2,mt))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.sparse_direct_overflow then cb('sparse_direct_overflow',function()error('direct sparse VRAM capacity exceeded field='..field)end,emu.cpuType.sa1)end
if labels.idle_clear_dma then
 local f=assert(io.open(output..'/idle_clear.jsonl','w'));local started,slot,band=0,0,0
 cb('idle_clear_dma',function()
  started=emu.getState().masterClock
  slot=emu.read16(0xa0,emu.memType.sa1InternalRam)//2
  band=emu.read16(0xac,emu.memType.sa1InternalRam)
 end,emu.cpuType.sa1)
 cb('idle_clear_done',function()
  f:write(string.format('{"field":%d,"slot":%d,"band":%d,"ms":%.6f}\n',field,slot,band,(emu.getState().masterClock-started)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
if labels.pipe_fast_partial_done then
 local f=assert(io.open(output..'/prefix_dma.jsonl','w'));local started=0
 local planClock,planMs=0,0
 cb('pipe_prefix_plan',function()planClock=emu.getState().masterClock end)
 cb('pipe_fast_begin',function()
  started=emu.getState().masterClock
  planMs=planClock>0 and (started-planClock)/21477.272 or 0
  planClock=0
 end)
 cb('pipe_fast_partial_done',function()
  local st=emu.getState();local mt=emu.memType.snesMemory;local base=0x7e0000
  f:write(string.format('{"field":%d,"line":%d,"bytes":%d,"descriptors":%d,"ms":%.6f,"planMs":%.6f}\n',field,st['ppu.scanline'],emu.read16(base+labels.pfBytes,mt),emu.read16(base+labels.pfDesc,mt)//6,(st.masterClock-started)/21477.272,planMs));f:flush()
 end)
end
if labels.stage_too_large then cb('stage_too_large',function()error('compact WRAM staging capacity exceeded field='..field)end)end
if labels.stage_time_ok then
 local started=0;local bytes=0;local count=0;local line=0
 cb('stage_time_ok',function()
  local st=emu.getState();local mt=emu.memType.snesMemory
  local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.stage_record,mt)
  started=st.masterClock;line=st['ppu.scanline'];bytes=emu.read16(record+34,mt);count=emu.read16(record+2,mt)//6
 end)
 cb('stage_converted',function()
  local st=emu.getState()
  cpuStageJobs[#cpuStageJobs+1]=string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}',field,bytes,count,line,st['ppu.scanline'],(st.masterClock-started)/21477.272)
 end)
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
if labels.cache_miss then
 local f=assert(io.open(output..'/bullet_cache.jsonl','w'));local start=0;local missed=false
 cb('sa1_bullet_cache_prepare',function()start=emu.getState().masterClock;missed=false end,emu.cpuType.sa1)
 cb('cache_miss',function()missed=true end,emu.cpuType.sa1)
 cb('cache_ready',function()
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"field":%d,"asset":%d,"width":%d,"height":%d,"flags":%d,"miss":%s,"ms":%.6f}\n',#times+1,field,emu.read16(0x3e,mt),emu.read16(0x34,mt),emu.read16(0x36,mt),emu.read16(0x3c,mt),missed and 'true' or 'false',(emu.getState().masterClock-start)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
cb('render_started',function()begin=emu.getState().masterClock;activeBegin=activeClock();cpuParts={};cpuActiveParts={} end)
cb('logic_finished',function()
 if scenario:match('^leftfixture') then
  local geometries={{0,90,48},{3,90,47},{0,93,50},{3,93,49},{0,97,52},{3,96,51},{0,104,55},{3,100,53},{0,107,57},{3,103,55},{0,114,61},{3,110,58}}
  local centers={-40,0,16,30,64,128,250}
  local bottoms={40,120,205}
  word('_fx_packet_count',2)
  for i=1,2 do
   local g=geometries[math.floor((logic-1)/7)*2%#geometries+i]
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[(logic+i-2)%#centers+1]&65535,mt)
   emu.write16(a+2,bottoms[math.floor((logic-1)/#centers)%#bottoms+1],mt)
   emu.write(a+4,g[2],mt);emu.write(a+5,g[3],mt);emu.write(a+6,g[1],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^flipfixture') then
  local assets={6,7,8,37};local sizes={6,16,32,48,62}
  local size=sizes[math.floor((logic-1)/12)%5+1]
  local flags=(math.floor((logic-1)/3)%4)*16+(logic-1)%3
  local centers={-2,254,128,64};local bottoms={120,200,30,160}
  word('_fx_packet_count',4)
  for i=1,4 do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[i]&65535,mt);emu.write16(a+2,bottoms[i],mt)
   emu.write(a+4,size,mt);emu.write(a+5,size,mt);emu.write(a+6,assets[i],mt);emu.write(a+7,flags,mt)
   emu.write16(a+8,0,mt)
  end
 end
 if packetOffload and (scenario:match('^flipfixture') or scenario:match('^leftfixture')) then
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels._fx_packet_count,mt)
  byte('_fx_draw_count',n)
  for i=0,n*10-1 do emu.write(0x7e0000+labels._fx_draw+i,emu.read(0x7e0000+labels._fx_packet+i,mt),mt)end
 end
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 local activeParts={};for name,v in pairs(cpuActiveParts)do activeParts[#activeParts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"activeLogicMs":%.6f,"parts":{%s},"activeParts":{%s}}',field,logicMs,(activeClock()-activeBegin)/21477.272,table.concat(parts,','),table.concat(activeParts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if true and captureGeneration(gen) then
   local bank=emu.read16(0x102,mt);local base=emu.read16(0x19a,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank&255)*65536+base+i,mt))end
   completedFrames[gen]=table.concat(t)
  end
  if captureGeneration(gen) then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 local rejectedLog=assert(io.open(output..'/rejected_dma.jsonl','w'))
 cb('pipe_fast_unavailable',function()
  local mt=emu.memType.snesMemory;local base=0x7e0000
  local record=base+labels.pipe_records+emu.read16(base+labels.pipe_record_offset,mt)
  rejectedLog:write(string.format('{"field":%d,"gen":%d,"bytes":%d,"count":%d,"cost":%d,"available":%d}\n',field,emu.read16(record+8,mt),emu.read16(record+34,mt),(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6,emu.read16(base+labels.pipe_dma_chunk,mt),emu.read16(base+labels.pipe_available,mt)));rejectedLog:flush()
 end)
 cb('pipe_fast_begin',function()
  local st=emu.getState();assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA began outside actual blank period')
  if scenario:match('tracedma') then
   local st=emu.getState();local f=assert(io.open(output..'/cc_state.jsonl','a'))
   f:write(string.format('{"field":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',field,st['cart.coprocessor.dmaSrcAddr'],st['cart.coprocessor.dmaDestAddr'],tostring(st['cart.coprocessor.charConvDmaActive']),tostring(st['ppu.forcedBlank']),st['ppu.scanline']));f:close()
   if presents==0 then
    local f=assert(io.open(output..'/before_dma_bw.bin','wb'));local a={}
    for i=0,24575 do a[#a+1]=string.char(emu.read(1024+i,emu.memType.snesSaveRam))end
    f:write(table.concat(a));f:close()
   end
  end
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA ended outside actual blank period')
  if scenario:match('tracedma') and presents==0 then
   local f=assert(io.open(output..'/beforeflip_vram.bin','wb'));local a={}
   for i=0,65535 do a[#a+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
   f:write(table.concat(a));f:close()
  end
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.fx_obj_upload_done then cb('fx_obj_upload_done',function()
 if field>90 then
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'OAM DMA ended outside actual blank period')
 end
end)end
if labels.dense_vram_overflow then cb('dense_vram_overflow',function()error('packed image exceeds one VRAM page')end,emu.cpuType.sa1)end
if vramPrefetch3 then
 emu.addMemoryCallback(function(address,value)
  if field>85 then
   local st=emu.getState()
   assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'BG1 map changed outside actual blank period')
  end
 end,emu.callbackType.write,0x2107,0x2107,emu.cpuType.snes,emu.memType.snesMemory)
end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock;pageCommit=nil end)end
if labels.fd_flip then
 local f=assert(io.open(output..'/map_delta.jsonl','w'))
 local begin=0;local count=0
 cb('fd_flip',function()
  local st=emu.getState();begin=st.masterClock
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,emu.memType.snesMemory)
  count=emu.read16(0x7e0000+labels.pipe_records+slot*512+62,emu.memType.snesMemory)
  if count>0 then assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'map update started outside actual blank')end
 end)
 cb('fd_flip_done',function()
  local st=emu.getState()
  if count>0 then assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'map update ended outside actual blank')end
  f:write(string.format('{"field":%d,"count":%d,"ms":%.6f,"line":%d}\n',field,count,(st.masterClock-begin)/21477.272,st['ppu.scanline']));f:flush()
 end)
end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=(pageCommit and pageCommit.line) or state['ppu.scanline']
 local commitField=(pageCommit and pageCommit.field) or field
 local visibleField=commitField+(line>=203 and line<225 and 1 or 0)
 assert(line<=21 or line>=203,'page flip occurred during visible lines field='..field..' line='..line)
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if captureGeneration(presents) then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   local page=emu.read16(record+6,mt)*2
   local bg1Chr=state['ppu.layers[0].chrAddress']*2
   local bg1Map=state['ppu.layers[0].tilemapAddress']*2
   local bg2Chr=state['ppu.layers[1].chrAddress']*2
   local bg2Map=state['ppu.layers[1].tilemapAddress']*2
   assert(bg1Chr==math.floor(page/8192)*8192,'PPU BG1 CHR base differs from the rendered page')
   assert(bg1Map==(fixedMap and 0xc000 or vramFourShared and 0xc000 or vramPrefetch3 and page+0x800 or 0xc000),'PPU BG1 map base differs')
   assert(bg2Chr==(fixedMap and 0xa000 or vramFourShared and 0x8000 or true and 0 or 0xc000),'PPU BG2 CHR base differs')
   assert(bg2Map==0xc000,'PPU BG2 map base differs')
   local p=assert(io.open(output..'/'..n..'_ppu.json','w'))
   p:write(string.format('{"bg1Chr":%d,"bg1Map":%d,"bg2Chr":%d,"bg2Map":%d}',bg1Chr,bg1Map,bg2Chr,bg2Map));p:close()
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   if fixedMapDelta then dump(n..'_map_delta.bin',emu.memType.snesMemory,0x7e0000+labels.fdStorage+slot*1472,1472)end
   if true then dump(n..'_ground_h.bin',emu.memType.snesMemory,0x7e0000+emu.read16(record+26,mt),270)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs field='..field..' gen='..presents..' byte='..i..' actual='..emu.read(i,emu.memType.snesSpriteRam)..' expected='..emu.read(record+64+i,mt))end
   if true then
    local expected=emu.read16(record+192,mt)|0x0aaa
    local actual=emu.read16(512,emu.memType.snesSpriteRam)
    assert((actual&0x0fff)==(expected&0x0fff),'player high OAM differs')
    dump(n..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    dump(n..'_palette.bin',emu.memType.snesCgRam,0,512)
   else
    for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 if true and presents>0 then
  for i=0,31 do
   local fx=emu.read(32+i,emu.memType.snesCgRam)
   local near=emu.read(480+i,emu.memType.snesCgRam)
   if fx~=expectedPalette[i+1] or near~=expectedPalette[i+1] then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('CGRAM changed field='..field..' byte='..i..' fx='..fx..' near='..near..' expected='..expectedPalette[i+1]);f:close();emu.stop(1);return
   end
  end
 end
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if finished then
  local f=assert(io.open(output..'/final_state.txt','w'));for k,v in pairs(emu.getState())do f:write(tostring(k)..'='..tostring(v)..'\n')end;f:close()
 end
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  finishedCapture=true
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s],"cpuStageJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,','),table.concat(cpuStageJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
