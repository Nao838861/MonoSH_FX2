local labels={["LoadAudioData"]=37295,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=37898,["Tad_GetSong"]=38002,["Tad_GlobalVolumesPersist"]=38030,["Tad_GlobalVolumesResetOnSongStart"]=38024,["Tad_Init"]=37514,["Tad_IsLoaderActive"]=38056,["Tad_IsSfxPlaying"]=38070,["Tad_IsSongLoaded"]=38064,["Tad_IsSongPlaying"]=38076,["Tad_LoadSong"]=37957,["Tad_LoadSongIfChanged"]=37990,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=37641,["Tad_QueueCommand"]=37914,["Tad_QueueCommandOverride"]=37919,["Tad_QueuePannedSoundEffect"]=37936,["Tad_QueueSoundEffect"]=37946,["Tad_ReloadCommonAudioData"]=38006,["Tad_SetTransferSize"]=38036,["Tad_SongsStartImmediately"]=38012,["Tad_SongsStartPaused"]=38018,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=45,["Tad_sfxQueue_sfx"]=44,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5849,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62823,["__COLORBSS_LOAD__"]=1024,["__COLORBSS_RUN__"]=1024,["__COLORBSS_SIZE__"]=3720,["__DATA_LOAD__"]=12764155,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__SA1_LOAD__"]=38328,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=823,["__STARTUP__"]=1,["_abs"]=62454,["_boss_age"]=63721,["_boss_attribute_cache"]=63556,["_boss_attribute_cache_count"]=63718,["_boss_attribute_z_cache"]=63700,["_boss_dda_phase"]=63939,["_boss_dda_x"]=63945,["_boss_dda_y"]=63951,["_boss_death_parts"]=63723,["_boss_death_timer"]=63722,["_boss_fire_gap"]=63732,["_boss_fire_round"]=63729,["_boss_fire_shots"]=63731,["_boss_fire_state"]=63728,["_boss_fire_volley"]=63730,["_boss_history_x"]=63172,["_boss_history_y"]=63300,["_boss_history_z"]=63428,["_boss_last_vblank"]=63108,["_boss_motion_steps"]=63727,["_boss_part_active"]=63136,["_boss_part_bottom"]=63118,["_boss_part_fall_fraction"]=63163,["_boss_part_fall_velocity"]=63154,["_boss_part_timer"]=63145,["_boss_part_x"]=63109,["_boss_part_z"]=63127,["_boss_path_half"]=63726,["_boss_player_bottom"]=63735,["_boss_player_x"]=63733,["_boss_render_camera_delta"]=63719,["_boss_restart_timer"]=63724,["_boss_z_phase"]=63725,["_death_accel_fraction"]=63973,["_death_timer"]=63971,["_death_vy"]=63970,["_enemy_p0_samples"]=47713,["_enemy_p1_samples"]=48448,["_enemy_p2_samples"]=49153,["_enemy_p3_samples"]=49858,["_enemy_p4_samples"]=50563,["_enemy_p5_samples"]=51280,["_enemy_p6_samples"]=51997,["_enemy_p7_samples"]=52564,["_enemy_p8_samples"]=53131,["_fx4_explosion_lift"]=1711,["_fx_asset_bank"]=27546,["_fx_asset_height"]=27502,["_fx_asset_width"]=27458,["_fx_audio_events"]=5648,["_fx_boss_hits"]=13209,["_fx_boss_project"]=13783,["_fx_build_ground"]=2711,["_fx_build_packet"]=1797,["_fx_buttons"]=61330,["_fx_draw"]=59406,["_fx_draw_count"]=60046,["_fx_em0_geometry"]=15710,["_fx_enemy_collisions"]=15177,["_fx_enemy_em1_update"]=16929,["_fx_enemy_em1_update_reference"]=25598,["_fx_enemy_fire_em1"]=25536,["_fx_enemy_remove"]=25525,["_fx_enemy_render"]=15848,["_fx_enemy_render_bullets"]=16127,["_fx_far_d_acc"]=61342,["_fx_far_u_acc"]=61340,["_fx_fire_actions"]=61333,["_fx_frame"]=17223,["_fx_ground_c1ptr"]=63098,["_fx_ground_c3ptr"]=63100,["_fx_ground_camera"]=27590,["_fx_ground_color1"]=61349,["_fx_ground_color3"]=61799,["_fx_ground_depth_rows"]=27735,["_fx_ground_far_x"]=63064,["_fx_ground_far_xptr"]=63094,["_fx_ground_far_y"]=63104,["_fx_ground_greens"]=33081,["_fx_ground_horizon"]=63102,["_fx_ground_horizontal"]=62249,["_fx_ground_hptr"]=63059,["_fx_ground_native"]=2799,["_fx_ground_palette_record"]=63062,["_fx_ground_phase"]=61329,["_fx_ground_vptr"]=63096,["_fx_ground_width"]=33000,["_fx_ground_world_phase"]=63061,["_fx_init"]=17986,["_fx_input"]=61332,["_fx_open_size"]=59137,["_fx_packet"]=60049,["_fx_packet_count"]=60047,["_fx_present"]=334,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=33089,["_fx_stage_contact"]=61000,["_fx_stage_render"]=60290,["_fx_stage_update"]=61331,["_fx_submit"]=61684,["_ground_irq_vblank_count"]=61337,["_history_head"]=63720,["_hit_pending"]=61344,["_intro_timer"]=63974,["_legacy_enemy_fire_boss_at"]=24130,["_main"]=18023,["_memcpy"]=62285,["_monosh_bom_geometry"]=43346,["_monosh_boss_body_geometry"]=39089,["_monosh_boss_bom_depth_by_size"]=39533,["_monosh_boss_bom_geometry"]=39311,["_monosh_boss_bullet_velocity"]=39771,["_monosh_boss_draw_order_base"]=34547,["_monosh_boss_draw_order_mid"]=36707,["_monosh_boss_explosion_ground_bottom"]=39660,["_monosh_boss_explosion_scale_low"]=39549,["_monosh_boss_face_geometry"]=38867,["_monosh_boss_frame"]=18212,["_monosh_boss_hp"]=63107,["_monosh_boss_init"]=18055,["_monosh_boss_path_center_y"]=33587,["_monosh_boss_path_center_y_mid"]=34307,["_monosh_boss_path_x"]=33347,["_monosh_boss_path_x_mid"]=34067,["_monosh_boss_path_z"]=33107,["_monosh_boss_path_z_mid"]=33827,["_monosh_boss_prepare_fire"]=20111,["_monosh_boss_prepare_render"]=18248,["_monosh_boss_render_only"]=13563,["_monosh_boss_should_restart"]=18034,["_monosh_boss_state"]=63106,["_monosh_bullet_reflect_rng"]=63777,["_monosh_collision_bullet_bands"]=63769,["_monosh_combat_build_collision_bands"]=20293,["_monosh_combat_fast_cache_reset"]=14762,["_monosh_combat_fast_frame"]=13978,["_monosh_combat_fast_render"]=14108,["_monosh_combat_fast_render_cached"]=14769,["_monosh_combat_fire_cooldown"]=63778,["_monosh_combat_half_frame"]=63779,["_monosh_combat_init"]=20137,["_monosh_combat_reflect_bullet"]=14407,["_monosh_combat_render"]=20290,["_monosh_combat_update"]=20232,["_monosh_ebullet4_geometry"]=44153,["_monosh_ebullet_animation_geometry"]=43931,["_monosh_ebullet_geometry"]=44375,["_monosh_ebullet_velocity"]=44385,["_monosh_em1_animation_assets_ready"]=63934,["_monosh_em1_closed_geometry"]=43568,["_monosh_em1_open_geometry"]=43790,["_monosh_enemies"]=63783,["_monosh_enemy_active_count"]=21053,["_monosh_enemy_active_count_value"]=63781,["_monosh_enemy_bullet_count"]=63780,["_monosh_enemy_bullets"]=63863,["_monosh_enemy_camera_delta_cached"]=63932,["_monosh_enemy_collision_cursor"]=63937,["_monosh_enemy_draw_cache_valid"]=63935,["_monosh_enemy_em1_count"]=63933,["_monosh_enemy_em1_phase"]=63908,["_monosh_enemy_em1_shrink"]=63924,["_monosh_enemy_fast_advance"]=16521,["_monosh_enemy_fast_check_player_bullets"]=22143,["_monosh_enemy_fast_render"]=21628,["_monosh_enemy_fast_render_bullets"]=23093,["_monosh_enemy_fast_spawn_due"]=23469,["_monosh_enemy_fast_update_bullets"]=14847,["_monosh_enemy_fire_at"]=21065,["_monosh_enemy_fire_boss_at"]=21094,["_monosh_enemy_fire_em0_fast"]=24528,["_monosh_enemy_frame"]=20856,["_monosh_enemy_geometry"]=43124,["_monosh_enemy_ground_bottom"]=43820,["_monosh_enemy_half_frame"]=63936,["_monosh_enemy_init"]=20707,["_monosh_enemy_path_fire_frames"]=53743,["_monosh_enemy_path_frames"]=53734,["_monosh_enemy_paths"]=53698,["_monosh_enemy_player_hit"]=63938,["_monosh_enemy_render_only"]=20886,["_monosh_enemy_spawn_index"]=63905,["_monosh_enemy_spawn_wait"]=63906,["_monosh_enemy_spawns"]=53752,["_monosh_enemy_stage_complete"]=21059,["_monosh_enemy_stage_complete_flag"]=63782,["_monosh_ground_depth_pointer"]=61347,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=63961,["_monosh_player_bullet_count"]=63752,["_monosh_player_bullet_sizes"]=43099,["_monosh_player_bullets"]=63737,["_monosh_player_can_fire"]=27356,["_monosh_player_draw_asset"]=27372,["_monosh_player_draw_flags"]=27314,["_monosh_player_init"]=27251,["_monosh_player_invuln"]=63964,["_monosh_player_pose"]=63966,["_monosh_player_state"]=63963,["_monosh_player_stumble"]=63965,["_monosh_player_update"]=29704,["_monosh_player_update_reference"]=28581,["_monosh_player_world_active"]=27350,["_monosh_player_x"]=63959,["_monosh_project_x"]=30314,["_monosh_reflected_bullet_count"]=63768,["_monosh_reflected_bullets"]=63753,["_monosh_runtime_fire_actions"]=61334,["_monosh_runtime_frame_counter"]=61335,["_monosh_runtime_paused"]=61339,["_monosh_stage1_spawn_count"]=54894,["_monosh_stage1_spawns"]=53958,["_monosh_stage_collision_bullet_cursor"]=64213,["_monosh_stage_collision_bullet_index"]=64214,["_monosh_stage_contact_result"]=64211,["_monosh_stage_draw_cache_valid"]=64212,["_monosh_stage_frame"]=28856,["_monosh_stage_frame_counter"]=64075,["_monosh_stage_geometry"]=57560,["_monosh_stage_half_frame"]=64079,["_monosh_stage_hitbox_count"]=64209,["_monosh_stage_hitboxes"]=64081,["_monosh_stage_init"]=28821,["_monosh_stage_is_clear"]=28905,["_monosh_stage_lift"]=58349,["_monosh_stage_near_count"]=64080,["_monosh_stage_need_hitboxes"]=64210,["_monosh_stage_object_count"]=64073,["_monosh_stage_objects"]=63977,["_monosh_stage_render_only"]=28902,["_monosh_stage_spawn_index"]=64074,["_monosh_stage_spawn_wait"]=64077,["_monosh_stage_title_timer"]=63967,["_monosh_title_draw"]=18012,["_monosh_title_visible"]=58365,["_movement_fraction"]=63972,["_old_buttons"]=61345,["_player_flip"]=63975,["_player_fy"]=63968,["_player_run_phase"]=63976,["_pose_x_01"]=53896,["_pose_x_12"]=53915,["_pose_x_23"]=53934,["_stage_bom0_geometry"]=57116,["_stage_bush0_geometry"]=54896,["_stage_bush1_geometry"]=55340,["_stage_em0_geometry"]=56228,["_stage_flystone_geometry"]=55784,["_stage_lift_0"]=57572,["_stage_lift_1"]=57683,["_stage_lift_2"]=57794,["_stage_lift_3"]=57905,["_stage_lift_4"]=58016,["_stage_lift_5"]=58127,["_stage_lift_6"]=58238,["_stage_tree0_geometry"]=56672,["_v9968_copy_to_vram_linear"]=14763,["addeq0sp"]=61924,["addeqysp"]=61926,["addysp"]=61942,["addysp1"]=61941,["aslax2"]=61955,["aslax3"]=61966,["aslax4"]=61980,["asrax1"]=61997,["asrax2"]=62007,["asrax3"]=62022,["audio4_first_done"]=734,["audio4_second_done"]=734,["background_done"]=98722,["booleq"]=62247,["boolge"]=62264,["boolgt"]=62262,["boolle"]=62254,["boollt"]=62256,["boolne"]=62241,["booluge"]=62280,["boolugt"]=62278,["boolule"]=62270,["boolult"]=62272,["bullet_render4"]=99584,["c_sp"]=66,["clip_left_found"]=1157,["decsp1"]=62042,["decsp2"]=62051,["decsp3"]=62064,["decsp4"]=62077,["decsp5"]=62090,["dispatch_nonzero"]=98752,["dma_chunk_ready"]=1120,["dma_finished"]=1653,["dma_started"]=1217,["fast_base_ready"]=35895,["fast_fail"]=35928,["fast_tiles"]=35862,["fx4_build_skip"]=58368,["fx4_desc_count"]=58380,["fx4_dma_bytes"]=58376,["fx4_generation"]=58374,["fx4_half_bytes"]=58378,["fx4_page"]=58372,["fx4_wait_obj_blank"]=1690,["fx_add_next_bounds"]=14846,["fx_audio_init"]=38082,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=38133,["fx_audio_sent"]=5653,["fx_build_obj"]=2152,["fx_commit_dma"]=14846,["fx_dma_bytes"]=59276,["fx_dma_count"]=59274,["fx_dma_desc"]=59278,["fx_em1_open_sizes"]=59180,["fx_emit_native"]=16384,["fx_is_obj"]=2104,["fx_latch_obj"]=2500,["fx_obj_build_done"]=2498,["fx_obj_count"]=58986,["fx_obj_dma_bytes"]=58992,["fx_obj_next"]=58714,["fx_obj_overflow"]=58990,["fx_obj_present"]=58850,["fx_obj_present_count"]=58988,["fx_obj_upload_done"]=2709,["fx_plan_dma"]=14827,["fx_project16"]=30344,["fx_read_gsu_spans"]=14772,["fx_reset_next_bounds"]=14846,["fx_sky_colors"]=17006,["fx_sky_colors_end"]=17090,["fx_sky_pointer"]=59018,["fx_upload_ground"]=3130,["fx_upload_obj"]=2546,["game_started"]=0,["generic"]=99536,["ground_done"]=3083,["ground_empty"]=3224,["gsu_uv_cache"]=99207,["half_dma_finished"]=1223,["incsp1"]=62170,["incsp2"]=62185,["incsp3"]=62199,["incsp4"]=62204,["incsp5"]=62209,["incsp6"]=62214,["incsp7"]=62219,["incsp8"]=62224,["initialized"]=1865,["integer_render4"]=100384,["invoke_row"]=1201,["irq_game"]=33436,["keys"]=58586,["ldaidx"]=62229,["logic_finished"]=714,["margin_render"]=99600,["math4_lift_result"]=1788,["memcpy_getparams"]=62326,["memcpy_upwards"]=62288,["mulax10"]=62345,["mulax3"]=62370,["mulax5"]=62387,["mulax6"]=62407,["mulax7"]=62429,["negax"]=62458,["nmi_game"]=33458,["order"]=58458,["packet_done"]=1952,["packet_work"]=6,["pipe_bw_busy"]=58414,["pipe_complete"]=58410,["pipe_front_slot"]=58404,["pipe_ground_extra"]=3584,["pipe_ground_extra_end"]=4744,["pipe_ground_wait"]=745,["pipe_irq"]=902,["pipe_irq_done"]=1332,["pipe_irq_transfer"]=924,["pipe_missed"]=58430,["pipe_obj_pointer"]=58452,["pipe_pending"]=58408,["pipe_presented_irq"]=58434,["pipe_records"]=1024,["pipe_render_slot"]=58402,["pipe_status"]=58418,["pipe_target_slot"]=58406,["pipe_wait_dma"]=960,["player4_next"]=58994,["player4_present"]=58996,["player4_upload_bytes"]=59000,["popax"]=62177,["popptr1"]=62472,["popsargsudiv16"]=62562,["prefetch_finished"]=1311,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=62508,["pusha"]=62490,["pusha0"]=62510,["pusha0sp"]=62486,["pushax"]=62512,["pushaysp"]=62488,["pushw0sp"]=62534,["pushwysp"]=62536,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=730,["render_second_finished"]=730,["render_second_started"]=730,["render_started"]=687,["render_stop"]=99754,["reset"]=32768,["row_done"]=1265,["sa1_clear_done"]=683,["sa1_clear_start"]=565,["sa1_compact"]=36396,["sa1_cover_row"]=35616,["sa1_dirty_done"]=576,["sa1_dma_begin"]=36819,["sa1_dma_end"]=36855,["sa1_dma_irq"]=37090,["sa1_dma_poll"]=36866,["sa1_draw_done"]=1289,["sa1_draw_rows"]=35930,["sa1_draw_start"]=702,["sa1_edge_prepare"]=36124,["sa1_edge_restore"]=36311,["sa1_edge_save"]=36202,["sa1_entry"]=512,["sa1_fb_read"]=37078,["sa1_fb_write"]=37084,["sa1_find_shape"]=35380,["sa1_merge_dma"]=37142,["sa1_native_done"]=1289,["sa1_near_row"]=36556,["sa1_output_done"]=1297,["sa1_plan_dirty"]=34085,["sa1_prepare_transfer"]=34712,["sa1_select_cover"]=35466,["sa1_snapshot"]=36923,["sa1_sprite_begin"]=33482,["sa1_sprite_done"]=1276,["sa1_tile_masks"]=34813,["sa1_tiles_clear"]=34945,["sa1_tiles_transfer"]=34960,["sa1_try_fast"]=35703,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=61955,["shlax3"]=61966,["shlax4"]=61980,["shrax1"]=62594,["shrax3"]=62602,["shrax4"]=62616,["sorted"]=1931,["sreg"]=68,["stage_update_done"]=61682,["staspidx"]=62633,["stax0sp"]=62655,["staxspidx"]=62666,["staxysp"]=62657,["subysp"]=62714,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=61896,["tosaddax"]=61898,["tosdiva0"]=62103,["tosdivax"]=62105,["tosicmp"]=62126,["tosicmp0"]=62124,["tossuba0"]=62693,["tossubax"]=62695,["tosudiva0"]=62727,["tosudivax"]=62729,["tosumoda0"]=62806,["tosumodax"]=62808,["transfer_chunk"]=1120,["udiv16"]=62744,["L1"]=62778,["@L1"]=62796,["Pos"]=62121,["@L3"]=62162,["@L4"]=62163,["@L2"]=62800,["L0"]=62754,["ret0"]=62243,["ret1"]=62249,["L3"]=62315,["done"]=62323,["L2"]=62587,["@L0"]=62785,["udiv16by8a"]=62785}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/boss"
local maxframe=1200
local targetPresents=0
local scenario="boss"
local padded=false
local pipeline=true
local field,logic,presents=0,0,0
local begin,sa1begin,drawbegin=0,0,0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local completedPackets={}
local outputJobs={}
local queueSamples={}
local objectJobs={}
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
for name,sites in pairs({["_fx_read_input"]={17228},["_monosh_combat_fast_frame"]={17621},["_monosh_combat_render"]={17628},["_monosh_enemy_frame"]={17676},["_monosh_stage_frame"]={17698},["_monosh_boss_frame"]={17790},["_monosh_boss_prepare_render"]={17807},["_monosh_boss_render_only"]={17812,17831},["_fx_build_packet"]={17978},["_fx_build_ground"]={17981}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,0x7f0000+site,0x7f0000+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,0x7f0000+site+3,0x7f0000+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local a=labels[name]+(cpu==emu.cpuType.snes and 0x7f0000 or 0)
 emu.addMemoryCallback(function()local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if pipeline then
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank-0x40)*65536+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb('pipe_irq_done',function()
  local line=emu.getState()['ppu.scanline'];assert(line<=22 or line>=203,'PPU transfer exceeded blank period line='..line..' field='..field..' presents='..presents)
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,5-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_sort_packet then
 cb('sa1_sort_packet',function()
  local mt=emu.memType.snesMemory;local n=emu.read16(0x7e0000+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(0x7e0000+labels.keys+i,mt),value=emu.read16(0x7e0000+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   for i,v in ipairs(sortReference)do assert(emu.read16(0x7e0000+labels.order+(i-1)*2,emu.memType.snesMemory)==v.value,'packet sort changed depth/priority/stability')end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=state['ppu.scanline']
 local visibleField=field+(line>=203 and line<225 and 1 or 0)
 assert(line<=22 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs')end
   for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()emu.setInput({a=true},0)end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
