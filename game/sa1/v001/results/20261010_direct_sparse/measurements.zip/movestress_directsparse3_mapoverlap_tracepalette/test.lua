local labels={["LoadAudioData"]=64023,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=14226292,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=64626,["Tad_GetSong"]=64730,["Tad_GlobalVolumesPersist"]=64758,["Tad_GlobalVolumesResetOnSongStart"]=64752,["Tad_Init"]=64242,["Tad_IsLoaderActive"]=64784,["Tad_IsSfxPlaying"]=64798,["Tad_IsSongLoaded"]=64792,["Tad_IsSongPlaying"]=64804,["Tad_LoadSong"]=64685,["Tad_LoadSongIfChanged"]=64718,["Tad_Loader_Bin"]=14226176,["Tad_Loader_SIZE"]=116,["Tad_Process"]=64369,["Tad_QueueCommand"]=64642,["Tad_QueueCommandOverride"]=64647,["Tad_QueuePannedSoundEffect"]=64664,["Tad_QueueSoundEffect"]=64674,["Tad_ReloadCommonAudioData"]=64734,["Tad_SetTransferSize"]=64764,["Tad_SongsStartImmediately"]=64740,["Tad_SongsStartPaused"]=64746,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=51,["Tad_sfxQueue_sfx"]=50,["__BSS_LOAD__"]=34998,["__BSS_RUN__"]=34998,["__BSS_SIZE__"]=5943,["__BULLETJIT_LOAD__"]=98304,["__BULLETJIT_RUN__"]=768,["__BULLETJIT_SIZE__"]=362,["__CODE_LOAD__"]=12648448,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65497,["__COLORBSS_LOAD__"]=40960,["__COLORBSS_RUN__"]=40960,["__COLORBSS_SIZE__"]=9448,["__DATA_LOAD__"]=12740787,["__DATA_RUN__"]=34995,["__DATA_SIZE__"]=3,["__LEFTJIT_LOAD__"]=98666,["__LEFTJIT_RUN__"]=768,["__LEFTJIT_SIZE__"]=373,["__RODATA_LOAD__"]=12713984,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=26803,["__SA1_LOAD__"]=65056,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=207,["__STARTUP__"]=1,["_abs"]=65128,["_boss_age"]=40447,["_boss_attribute_cache"]=40282,["_boss_attribute_cache_count"]=40444,["_boss_attribute_z_cache"]=40426,["_boss_dda_phase"]=40665,["_boss_dda_x"]=40671,["_boss_dda_y"]=40677,["_boss_death_parts"]=40449,["_boss_death_timer"]=40448,["_boss_fire_gap"]=40458,["_boss_fire_round"]=40455,["_boss_fire_shots"]=40457,["_boss_fire_state"]=40454,["_boss_fire_volley"]=40456,["_boss_history_x"]=39898,["_boss_history_y"]=40026,["_boss_history_z"]=40154,["_boss_last_vblank"]=39834,["_boss_motion_steps"]=40453,["_boss_part_active"]=39862,["_boss_part_bottom"]=39844,["_boss_part_fall_fraction"]=39889,["_boss_part_fall_velocity"]=39880,["_boss_part_timer"]=39871,["_boss_part_x"]=39835,["_boss_part_z"]=39853,["_boss_path_half"]=40452,["_boss_player_bottom"]=40461,["_boss_player_x"]=40459,["_boss_render_camera_delta"]=40445,["_boss_restart_timer"]=40450,["_boss_z_phase"]=40451,["_death_accel_fraction"]=40699,["_death_timer"]=40697,["_death_vy"]=40696,["_enemy_p0_samples"]=24345,["_enemy_p1_samples"]=25080,["_enemy_p2_samples"]=25785,["_enemy_p3_samples"]=26490,["_enemy_p4_samples"]=27195,["_enemy_p5_samples"]=27912,["_enemy_p6_samples"]=28629,["_enemy_p7_samples"]=29196,["_enemy_p8_samples"]=29763,["_fx4_explosion_lift"]=3487,["_fx_asset_bank"]=14170,["_fx_asset_height"]=14126,["_fx_asset_width"]=14082,["_fx_audio_events"]=5648,["_fx_boss_hits"]=15883,["_fx_boss_project"]=16457,["_fx_build_ground"]=4501,["_fx_build_packet"]=3573,["_fx_buttons"]=38056,["_fx_draw"]=36132,["_fx_draw_count"]=36772,["_fx_em0_geometry"]=18384,["_fx_enemy_collisions"]=17851,["_fx_enemy_em1_update"]=19603,["_fx_enemy_em1_update_reference"]=28272,["_fx_enemy_fire_em1"]=28210,["_fx_enemy_remove"]=28199,["_fx_enemy_render"]=18522,["_fx_enemy_render_bullets"]=18801,["_fx_far_d_acc"]=38068,["_fx_far_u_acc"]=38066,["_fx_fire_actions"]=38059,["_fx_frame"]=19897,["_fx_ground_c1ptr"]=39824,["_fx_ground_c3ptr"]=39826,["_fx_ground_camera"]=14214,["_fx_ground_color1"]=38075,["_fx_ground_color3"]=38525,["_fx_ground_depth_rows"]=14359,["_fx_ground_far_x"]=39790,["_fx_ground_far_xptr"]=39820,["_fx_ground_far_y"]=39830,["_fx_ground_greens"]=19705,["_fx_ground_horizon"]=39828,["_fx_ground_horizontal"]=38975,["_fx_ground_hptr"]=39785,["_fx_ground_native"]=4589,["_fx_ground_palette_record"]=39788,["_fx_ground_phase"]=38055,["_fx_ground_vptr"]=39822,["_fx_ground_width"]=19624,["_fx_ground_world_phase"]=39787,["_fx_init"]=20660,["_fx_input"]=38058,["_fx_open_size"]=61811,["_fx_packet"]=36775,["_fx_packet_count"]=36773,["_fx_present"]=340,["_fx_read_input"]=70,["_fx_send_ground"]=130,["_fx_sky_color"]=19713,["_fx_stage_contact"]=63674,["_fx_stage_render"]=62964,["_fx_stage_update"]=64005,["_fx_submit"]=64358,["_ground_irq_vblank_count"]=38063,["_history_head"]=40446,["_hit_pending"]=38070,["_intro_timer"]=40700,["_legacy_enemy_fire_boss_at"]=26804,["_main"]=20697,["_memcpy"]=64959,["_monosh_bom_geometry"]=19978,["_monosh_boss_body_geometry"]=10072,["_monosh_boss_bom_depth_by_size"]=10516,["_monosh_boss_bom_geometry"]=10294,["_monosh_boss_bullet_velocity"]=10754,["_monosh_boss_draw_order_base"]=59703,["_monosh_boss_draw_order_mid"]=61863,["_monosh_boss_explosion_ground_bottom"]=10643,["_monosh_boss_explosion_scale_low"]=10532,["_monosh_boss_face_geometry"]=9850,["_monosh_boss_frame"]=20886,["_monosh_boss_hp"]=39833,["_monosh_boss_init"]=20729,["_monosh_boss_path_center_y"]=8890,["_monosh_boss_path_center_y_mid"]=9610,["_monosh_boss_path_x"]=8650,["_monosh_boss_path_x_mid"]=9370,["_monosh_boss_path_z"]=8410,["_monosh_boss_path_z_mid"]=9130,["_monosh_boss_prepare_fire"]=22785,["_monosh_boss_prepare_render"]=20922,["_monosh_boss_render_only"]=16237,["_monosh_boss_should_restart"]=20708,["_monosh_boss_state"]=39832,["_monosh_bullet_reflect_rng"]=40503,["_monosh_collision_bullet_bands"]=40495,["_monosh_combat_build_collision_bands"]=22967,["_monosh_combat_fast_cache_reset"]=17436,["_monosh_combat_fast_frame"]=16652,["_monosh_combat_fast_render"]=16782,["_monosh_combat_fast_render_cached"]=17443,["_monosh_combat_fire_cooldown"]=40504,["_monosh_combat_half_frame"]=40505,["_monosh_combat_init"]=22811,["_monosh_combat_reflect_bullet"]=17081,["_monosh_combat_render"]=22964,["_monosh_combat_update"]=22906,["_monosh_ebullet4_geometry"]=20785,["_monosh_ebullet_animation_geometry"]=20563,["_monosh_ebullet_geometry"]=21007,["_monosh_ebullet_velocity"]=21017,["_monosh_em1_animation_assets_ready"]=40660,["_monosh_em1_closed_geometry"]=20200,["_monosh_em1_open_geometry"]=20422,["_monosh_enemies"]=40509,["_monosh_enemy_active_count"]=23727,["_monosh_enemy_active_count_value"]=40507,["_monosh_enemy_bullet_count"]=40506,["_monosh_enemy_bullets"]=40589,["_monosh_enemy_camera_delta_cached"]=40658,["_monosh_enemy_collision_cursor"]=40663,["_monosh_enemy_draw_cache_valid"]=40661,["_monosh_enemy_em1_count"]=40659,["_monosh_enemy_em1_phase"]=40634,["_monosh_enemy_em1_shrink"]=40650,["_monosh_enemy_fast_advance"]=19195,["_monosh_enemy_fast_check_player_bullets"]=24817,["_monosh_enemy_fast_render"]=24302,["_monosh_enemy_fast_render_bullets"]=25767,["_monosh_enemy_fast_spawn_due"]=26143,["_monosh_enemy_fast_update_bullets"]=17521,["_monosh_enemy_fire_at"]=23739,["_monosh_enemy_fire_boss_at"]=23768,["_monosh_enemy_fire_em0_fast"]=27202,["_monosh_enemy_frame"]=23530,["_monosh_enemy_geometry"]=19756,["_monosh_enemy_ground_bottom"]=20452,["_monosh_enemy_half_frame"]=40662,["_monosh_enemy_init"]=23381,["_monosh_enemy_path_fire_frames"]=30375,["_monosh_enemy_path_frames"]=30366,["_monosh_enemy_paths"]=30330,["_monosh_enemy_player_hit"]=40664,["_monosh_enemy_render_only"]=23560,["_monosh_enemy_spawn_index"]=40631,["_monosh_enemy_spawn_wait"]=40632,["_monosh_enemy_spawns"]=30384,["_monosh_enemy_stage_complete"]=23733,["_monosh_enemy_stage_complete_flag"]=40508,["_monosh_ground_depth_pointer"]=38073,["_monosh_ground_offset"]=34995,["_monosh_ground_screen_delta"]=34996,["_monosh_player_bottom"]=40687,["_monosh_player_bullet_count"]=40478,["_monosh_player_bullet_sizes"]=19731,["_monosh_player_bullets"]=40463,["_monosh_player_can_fire"]=30030,["_monosh_player_draw_asset"]=30046,["_monosh_player_draw_flags"]=29988,["_monosh_player_init"]=29925,["_monosh_player_invuln"]=40690,["_monosh_player_pose"]=40692,["_monosh_player_state"]=40689,["_monosh_player_stumble"]=40691,["_monosh_player_update"]=32378,["_monosh_player_update_reference"]=31255,["_monosh_player_world_active"]=30024,["_monosh_player_x"]=40685,["_monosh_project_x"]=32988,["_monosh_reflected_bullet_count"]=40494,["_monosh_reflected_bullets"]=40479,["_monosh_runtime_fire_actions"]=38060,["_monosh_runtime_frame_counter"]=38061,["_monosh_runtime_paused"]=38065,["_monosh_stage1_spawn_count"]=31526,["_monosh_stage1_spawns"]=30590,["_monosh_stage_collision_bullet_cursor"]=40939,["_monosh_stage_collision_bullet_index"]=40940,["_monosh_stage_contact_result"]=40937,["_monosh_stage_draw_cache_valid"]=40938,["_monosh_stage_frame"]=31530,["_monosh_stage_frame_counter"]=40801,["_monosh_stage_geometry"]=34192,["_monosh_stage_half_frame"]=40805,["_monosh_stage_hitbox_count"]=40935,["_monosh_stage_hitboxes"]=40807,["_monosh_stage_init"]=31495,["_monosh_stage_is_clear"]=31579,["_monosh_stage_lift"]=34981,["_monosh_stage_near_count"]=40806,["_monosh_stage_need_hitboxes"]=40936,["_monosh_stage_object_count"]=40799,["_monosh_stage_objects"]=40703,["_monosh_stage_render_only"]=31576,["_monosh_stage_spawn_index"]=40800,["_monosh_stage_spawn_wait"]=40803,["_monosh_stage_title_timer"]=40693,["_monosh_title_draw"]=20686,["_monosh_title_visible"]=34997,["_movement_fraction"]=40698,["_old_buttons"]=38071,["_player_flip"]=40701,["_player_fy"]=40694,["_player_run_phase"]=40702,["_pose_x_01"]=30528,["_pose_x_12"]=30547,["_pose_x_23"]=30566,["_stage_bom0_geometry"]=33748,["_stage_bush0_geometry"]=31528,["_stage_bush1_geometry"]=31972,["_stage_em0_geometry"]=32860,["_stage_flystone_geometry"]=32416,["_stage_lift_0"]=34204,["_stage_lift_1"]=34315,["_stage_lift_2"]=34426,["_stage_lift_3"]=34537,["_stage_lift_4"]=34648,["_stage_lift_5"]=34759,["_stage_lift_6"]=34870,["_stage_tree0_geometry"]=33304,["_v9968_copy_to_vram_linear"]=17437,["addeq0sp"]=64598,["addeqysp"]=64600,["addysp"]=64616,["addysp1"]=64615,["aslax2"]=64629,["aslax3"]=64640,["aslax4"]=64654,["asrax1"]=64671,["asrax2"]=64681,["asrax3"]=64696,["audio4_first_done"]=810,["audio4_second_done"]=810,["background_done"]=111586,["booleq"]=64921,["boolge"]=64938,["boolgt"]=64936,["boolle"]=64928,["boollt"]=64930,["boolne"]=64915,["booluge"]=64954,["boolugt"]=64952,["boolule"]=64944,["boolult"]=64946,["bullet_render4"]=112448,["c_sp"]=72,["clip_left_found"]=34354,["decsp1"]=64716,["decsp2"]=64725,["decsp3"]=64738,["decsp4"]=64751,["decsp5"]=64764,["dispatch_nonzero"]=111616,["dma_chunk_ready"]=1372,["dma_finished"]=2932,["dma_started"]=1572,["fast_base_ready"]=36859,["fast_fail"]=36908,["fast_tiles"]=36826,["fx4_build_skip"]=35000,["fx4_desc_count"]=35012,["fx4_dma_bytes"]=35008,["fx4_generation"]=35006,["fx4_half_bytes"]=35010,["fx4_page"]=35004,["fx4_wait_obj_blank"]=3466,["fx_add_next_bounds"]=17520,["fx_audio_init"]=64810,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=64861,["fx_audio_sent"]=5653,["fx_build_obj"]=3939,["fx_commit_dma"]=17520,["fx_dma_bytes"]=36002,["fx_dma_count"]=36000,["fx_dma_desc"]=36004,["fx_em1_open_sizes"]=61854,["fx_emit_native"]=19058,["fx_is_obj"]=3891,["fx_latch_obj"]=4287,["fx_obj_build_done"]=4285,["fx_obj_count"]=35646,["fx_obj_dma_bytes"]=35652,["fx_obj_next"]=35374,["fx_obj_overflow"]=35650,["fx_obj_present"]=35510,["fx_obj_present_count"]=35648,["fx_obj_upload_done"]=4499,["fx_plan_dma"]=17501,["fx_project16"]=33018,["fx_read_gsu_spans"]=17446,["fx_reset_next_bounds"]=17520,["fx_sky_colors"]=8326,["fx_sky_colors_end"]=8410,["fx_sky_pointer"]=35678,["fx_upload_ground"]=4859,["fx_upload_obj"]=4333,["game_started"]=0,["generic"]=112400,["ground_done"]=4812,["ground_empty"]=4953,["gsu_uv_cache"]=112071,["half_dma_finished"]=1578,["incsp1"]=64844,["incsp2"]=64859,["incsp3"]=64873,["incsp4"]=64878,["incsp5"]=64883,["incsp6"]=64888,["incsp7"]=64893,["incsp8"]=64898,["initialized"]=3641,["integer_render4"]=113248,["invoke_row"]=34398,["irq_game"]=33470,["keys"]=35246,["ldaidx"]=64903,["logic_finished"]=787,["margin_render"]=112464,["math4_lift_result"]=3564,["memcpy_getparams"]=65000,["memcpy_upwards"]=64962,["mulax10"]=65019,["mulax3"]=65044,["mulax5"]=65061,["mulax6"]=65081,["mulax7"]=65103,["negax"]=65132,["nmi_game"]=33506,["order"]=35118,["packet_done"]=3739,["packet_work"]=9,["pfBytes"]=35792,["pfDesc"]=35794,["pfPartial"]=35790,["pipe_available"]=35096,["pipe_bw_busy"]=35046,["pipe_collect"]=853,["pipe_complete"]=35042,["pipe_dma_chunk"]=35106,["pipe_dma_measured_end"]=1599,["pipe_fast_begin"]=2162,["pipe_fast_done"]=2741,["pipe_fast_partial_done"]=3405,["pipe_fast_unavailable"]=2749,["pipe_flip"]=2751,["pipe_front_slot"]=35036,["pipe_ground_extra"]=45068,["pipe_ground_extra_end"]=47968,["pipe_ground_wait"]=826,["pipe_irq"]=1028,["pipe_irq_checked"]=1737,["pipe_irq_done"]=1729,["pipe_irq_exit"]=1760,["pipe_irq_transfer"]=1050,["pipe_main_offset"]=35088,["pipe_missed"]=35078,["pipe_near_build"]=15074,["pipe_near_prepare_next"]=14968,["pipe_near_prepared"]=35788,["pipe_near_present"]=35786,["pipe_near_select"]=15411,["pipe_next_slot"]=35090,["pipe_obj_pointer"]=35102,["pipe_pending"]=35040,["pipe_prefix_plan"]=15630,["pipe_presented_irq"]=35082,["pipe_record_offset"]=35086,["pipe_records"]=40960,["pipe_render_slot"]=35034,["pipe_status"]=35060,["pipe_target_slot"]=35038,["pipe_time_left"]=1806,["pipe_wait_dma"]=1086,["pipe_write_slot"]=35030,["player4_next"]=35654,["player4_present"]=35656,["player4_upload_bytes"]=35660,["player4_uploaded"]=35658,["popax"]=64851,["popptr1"]=65146,["popsargsudiv16"]=65236,["prefetch_finished"]=1702,["ptr1"]=80,["ptr2"]=82,["ptr3"]=84,["ptr4"]=86,["push0"]=65182,["pusha"]=65164,["pusha0"]=65184,["pusha0sp"]=65160,["pushax"]=65186,["pushaysp"]=65162,["pushw0sp"]=65208,["pushwysp"]=65210,["regbank"]=92,["regsave"]=76,["render_entry"]=111168,["render_finished"]=806,["render_second_finished"]=806,["render_second_started"]=806,["render_started"]=760,["render_stop"]=112618,["reset"]=32768,["row_done"]=34462,["sa1_background_cache"]=58279,["sa1_background_initialize"]=58597,["sa1_bullet_cache_init"]=100665,["sa1_bullet_cache_prepare"]=100666,["sa1_clear_done"]=695,["sa1_clear_start"]=526,["sa1_clear_wide_band"]=59167,["sa1_compact"]=37516,["sa1_cover_row"]=36536,["sa1_deep_rebase"]=57924,["sa1_dirty_done"]=546,["sa1_dirty_row_rect"]=35706,["sa1_dirty_rows"]=57959,["sa1_dma_begin"]=57087,["sa1_dma_end"]=57123,["sa1_dma_irq"]=57368,["sa1_dma_poll"]=57134,["sa1_dma_try_begin"]=57053,["sa1_draw_done"]=34486,["sa1_draw_rows"]=36910,["sa1_draw_start"]=714,["sa1_edge_cpu_restore"]=58921,["sa1_edge_cpu_save"]=58877,["sa1_edge_prepare"]=37175,["sa1_edge_restore"]=37399,["sa1_edge_save"]=37257,["sa1_entry"]=512,["sa1_fb_read"]=57356,["sa1_fb_write"]=57362,["sa1_find_shape"]=36277,["sa1_ground_compiled"]=15584,["sa1_left_hint_draw"]=102898,["sa1_list_sort"]=15434,["sa1_merge_dma"]=59550,["sa1_native_done"]=34486,["sa1_near_patch"]=58806,["sa1_near_patch_bounds"]=58720,["sa1_near_row"]=37676,["sa1_occupancy_capture"]=57420,["sa1_output_done"]=34502,["sa1_plan_dirty"]=34904,["sa1_prepare_transfer"]=35603,["sa1_select_cover"]=36386,["sa1_small_edge_prepare"]=58991,["sa1_small_edge_restore"]=59156,["sa1_small_edge_save"]=59145,["sa1_snapshot"]=57191,["sa1_sparse_direct_finish"]=102804,["sa1_sparse_map_prepare"]=101168,["sa1_sprite_begin"]=33588,["sa1_sprite_done"]=34473,["sa1_stack_clear_band"]=59229,["sa1_stack_clear_line"]=59404,["sa1_stack_clear_prepare"]=59212,["sa1_tile_masks"]=35710,["sa1_tiles_clear"]=35842,["sa1_tiles_transfer"]=35857,["sa1_transfer_mask_capture"]=57653,["sa1_transfer_mask_prepare"]=57708,["sa1_try_fast"]=36623,["scaled_render4"]=112976,["scaled_unpacked4"]=113136,["shlax2"]=64629,["shlax3"]=64640,["shlax4"]=64654,["shrax1"]=65268,["shrax3"]=65276,["shrax4"]=65290,["sorted"]=3718,["sparse_direct_overflow"]=102897,["sreg"]=74,["stage_update_done"]=64356,["staspidx"]=65307,["stax0sp"]=65329,["staxspidx"]=65340,["staxysp"]=65331,["subysp"]=65388,["tm_first"]=99190,["tm_length"]=99702,["tm_rest"]=100214,["tmp1"]=88,["tmp2"]=89,["tmp3"]=90,["tmp4"]=91,["tosadda0"]=64570,["tosaddax"]=64572,["tosdiva0"]=64777,["tosdivax"]=64779,["tosicmp"]=64800,["tosicmp0"]=64798,["tossuba0"]=65367,["tossubax"]=65369,["tosudiva0"]=65401,["tosudivax"]=65403,["tosumoda0"]=65480,["tosumodax"]=65482,["transfer_chunk"]=1372,["udiv16"]=65418,["L1"]=65452,["@L1"]=65470,["Pos"]=64795,["@L3"]=64836,["@L4"]=64837,["@L2"]=65474,["L0"]=65428,["ret0"]=64917,["ret1"]=64923,["L3"]=64989,["done"]=64997,["L2"]=65261,["@L0"]=65459,["udiv16by8a"]=65459}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_game/movestress_directsparse3_mapoverlap_tracepalette"
local maxframe=800
local targetPresents=0
local scenario="movestress_directsparse3_mapoverlap_tracepalette"
local padded=false
local pipeline=true
local vramPrefetch3=true
local cpuCodeBase=8323072
local field,logic,presents=0,0,0
local finishedCapture=false
local begin,sa1begin,drawbegin=0,0,0
local flipBegin=0
local dirtyDone,clearDone,nativeDone=0,0,0
local dirtyMs,clearMs,bgMs,nativeMs,logicMs=0,0,0,0,0
local times={}
local presentationTimes={}
local pageCommit=nil
local readyLine,startClock,waitMs=0,0,0
local cpuParts,cpuEntries={},{}
local cpuJobs={}
local sortReference=nil
local packetTrace=assert(io.open(output..'/packet_trace.bin','wb'))
local completedFrames={}
local expectedPalette={0,0,154,119,254,82,94,10,101,15,113,55,83,90,141,61,1,6,74,38,76,8,53,0,0,4,55,101,109,97,120,45}
if scenario:match('tracepalette') then
 local z=assert(io.open(output..'/palette_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  if field>90 then
   local s=emu.getState()
   z:write(string.format('{"field":%d,"line":%d,"hclock":%d,"address":%d,"value":%d,"cgadd":%d,"pc":%d}\n',field,s['ppu.scanline'],s['memoryManager.hClock'],address,value,s['ppu.cgramAddress'],s['cpu.pc']));z:flush()
  end
 end,emu.callbackType.write,32,63,emu.cpuType.snes,emu.memType.snesCgRam)
end
if scenario:match('tracedma') then
 local z=assert(io.open(output..'/sa1_dma_writes.jsonl','w'))
 local blankLog=assert(io.open(output..'/blank_writes.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local st=emu.getState()
  blankLog:write(string.format('{"field":%d,"line":%d,"value":%d,"pc":%d,"hdmaAddress":%d,"hdmaCount":%d}\n',field,st['ppu.scanline'],value,st['cpu.pc'],st['dmaController.channel[1].hdmaTableAddress'],st['dmaController.channel[1].hdmaLineCounterAndRepeat']));blankLog:flush()
 end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
 local reads=assert(io.open(output..'/cpu_dma_reads.jsonl','w'));local readCount=0
 emu.addMemoryCallback(function(address,value)
  if presents==0 and emu.read16(0x311e,emu.memType.snesMemory)==1 and readCount<800 then
   readCount=readCount+1;local s=emu.getState()
   reads:write(string.format('{"address":%d,"value":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',address,value,s['cart.coprocessor.dmaSrcAddr'],s['cart.coprocessor.dmaDestAddr'],tostring(s['cart.coprocessor.charConvDmaActive']),tostring(s['ppu.forcedBlank']),s['ppu.scanline']));reads:flush()
  end
 end,emu.callbackType.read,0x400000,0x43ffff,emu.cpuType.snes,emu.memType.snesMemory)
 emu.addMemoryCallback(function(address,value)
  if emu.read16(0x11e,emu.memType.sa1Memory)==1 then
   local s=emu.getState()
   z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,emu.memType.sa1Memory),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
  end
 end,emu.callbackType.write,0x2230,0x2239,emu.cpuType.sa1,emu.memType.sa1Memory)
end
if scenario:match('tracezero') then
 local z=assert(io.open(output..'/rowzero.jsonl','w'))
 emu.addMemoryCallback(function(address,value)
  local s=emu.getState();local m=emu.memType.sa1Memory
  z:write(string.format('{"gen":%d,"address":%d,"value":%d,"pc":%d}\n',emu.read16(0x198,m),address,value,(s['cart.coprocessor.cpu.k'] or 0)*65536+(s['cart.coprocessor.cpu.pc'] or 0)));z:flush()
 end,emu.callbackType.write,0x420000,0x42007f,emu.cpuType.sa1,emu.memType.sa1Memory)
end
local completedPackets={}
local jobSequence=0
local outputJobs={}
local cpuStageJobs={}
local queueSamples={}
local objectJobs={}
local dmaJobs={}
local dmaClock,dmaLength,dmaLine=0,0,0
local objectBegin=0
local function word(name,value)
 emu.write16(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write16(0x400000+labels[name],value,emu.memType.snesMemory)end
end
for name,sites in pairs({["_fx_read_input"]={19902},["_monosh_combat_fast_frame"]={20295},["_monosh_combat_render"]={20302},["_monosh_enemy_frame"]={20350},["_monosh_stage_frame"]={20372},["_monosh_boss_frame"]={20464},["_monosh_boss_prepare_render"]={20481},["_monosh_boss_render_only"]={20486,20505},["_fx_build_packet"]={20652},["_fx_build_ground"]={20655}})do
 for _,site in ipairs(sites)do
  emu.addMemoryCallback(function()cpuEntries[name]=emu.getState().masterClock end,emu.callbackType.exec,cpuCodeBase+site,cpuCodeBase+site)
  emu.addMemoryCallback(function()cpuParts[name]=(cpuParts[name] or 0)+(emu.getState().masterClock-cpuEntries[name])/21477.272 end,emu.callbackType.exec,cpuCodeBase+site+3,cpuCodeBase+site+3)
 end
end
local function byte(name,value)
 emu.write(0x7e0000+labels[name],value,emu.memType.snesMemory)
 if false and name:match('^_monosh') then emu.write(0x400000+labels[name],value,emu.memType.snesMemory)end
end
local function cb(name,fn,cpu)
 cpu=cpu or emu.cpuType.snes
 local gameHook=false and (name=='_fx_build_packet' or name=='initialized' or name=='sorted' or name=='packet_done' or name=='sa1_list_sort')
 if gameHook then cpu=emu.cpuType.sa1 end
 local irqName=name:match('^pipe_') or name=='p3PumpBlank' or name=='stage_time_ok' or name=='stage_converted' or name=='stage_too_large' or name=='fx_obj_upload_done' or name=='dma_started' or name=='dma_finished' or name=='half_dma_finished' or name=='prefetch_finished' or name=='transfer_chunk' or name=='dma_chunk_ready'
 local a=labels[name]+(gameHook and 0xc10000 or cpu==emu.cpuType.snes and labels[name]<65536 and (irqName and 12648448 or cpuCodeBase) or 0)
 emu.addMemoryCallback(function()if finishedCapture then return end;local ok,err=pcall(fn);if not ok then local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close();local g=assert(io.open(output..'/failure_state.txt','w'));for k,v in pairs(emu.getState())do g:write(tostring(k)..'='..tostring(v)..'\n')end;g:close();emu.stop(1)end end,emu.callbackType.exec,a,a,cpu,cpu==emu.cpuType.snes and emu.memType.snesMemory or emu.memType.sa1Memory)
end
if labels.fallback_publish and scenario:match('tracefallback') then
 local f=assert(io.open(output..'/fallback_debug.jsonl','w'))
 cb('fallback_publish',function()
  local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt);local page=emu.read16(record+6,mt)*2
  local outside={}
  for tile=32,767 do
   local mask=emu.read(0x7e0000+labels.fbMasks+slot*128+math.floor(tile/8),mt)
   if (mask & (1<<(tile%8)))==0 then
    for b=0,31 do
     if emu.read(page+tile*32+b,emu.memType.snesVideoRam)~=0 then outside[#outside+1]=tile;break end
    end
   end
  end
  f:write(string.format('{"generation":%d,"page":%d,"outside":[%s]}\n',gen,page,table.concat(outside,',')));f:flush()
 end)
 if labels.sa1_fallback_build then cb('sa1_fallback_build',function()
  local s=emu.getState()
  f:write(string.format('{"field":%d,"sa1Stack":%d}\n',field,s['cart.coprocessor.cpu.sp'] or -1));f:flush()
 end,emu.cpuType.sa1)end
end
emu.addMemoryCallback(function(address,value)
 local line=emu.getState()['ppu.scanline']
 if field>85 and (line>=203 or line<21) and line<225 and (value&0x80)==0 then
  local f=assert(io.open(output..'/failure.txt','w'));f:write('HDMA unblanked reserved DMA lines field='..field..' line='..line);f:close();emu.stop(1)
 end
end,emu.callbackType.write,0x2100,0x2100,emu.cpuType.snes,emu.memType.snesMemory)
-- VRAM/OAM DMA�͎��ۂ�forced blank�܂���VBLANK���ɊJ�n����B
emu.addMemoryCallback(function(address,value)
 if field>90 and (value&1)~=0 then
  local bb=emu.read(0x4301,emu.memType.snesMemory)
  if bb==0x18 or bb==4 then
   local st=emu.getState()
   if emu.read16(0x4305,emu.memType.snesMemory)==0 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('zero-length VRAM/OAM DMA would transfer 65536 bytes field='..field);f:close();emu.stop(1)
   end
   if vramPrefetch3 and bb==0x18 then
    local first=(st['ppu.vramAddress']&0x7fff)*2
    local last=first+emu.read16(0x4305,emu.memType.snesMemory)
    if (first<1024 and last>0) or (first<0x4400 and last>0x4000) then
     local f=assert(io.open(output..'/failure.txt','w'))
     f:write('frame DMA overwrites fixed BG2 CHR field='..field..' first='..first..' last='..last);f:close();emu.stop(1)
    end
   end
   if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('VRAM/OAM DMA started outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
   end
  end
 end
end,emu.callbackType.write,0x420b,0x420b,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(function(address,value)
 if field>90 then
  local st=emu.getState()
  if not st['ppu.forcedBlank'] and st['ppu.scanline']<225 then
   local f=assert(io.open(output..'/failure.txt','w'))
   f:write('BG1 page changed outside actual blank field='..field..' line='..st['ppu.scanline']);f:close();emu.stop(1)
  end
  pageCommit={field=field,line=st['ppu.scanline'],clock=st.masterClock}
 end
end,emu.callbackType.write,0x210b,0x210b,emu.cpuType.snes,emu.memType.snesMemory)
local packetClock,irqTicks,irqClock,irqDepth=0,0,0,0
local function activeClock()local c=emu.getState().masterClock;return c-irqTicks-(irqClock>0 and c-irqClock or 0)end
if pipeline then
 local function irqEntry()if irqDepth==0 then irqClock=emu.getState().masterClock end;irqDepth=irqDepth+1 end
 cb('pipe_irq',irqEntry)
 if labels.p3PumpBlank then cb('p3PumpBlank',irqEntry)end
 cb('pipe_irq_exit',function()irqDepth=irqDepth-1;assert(irqDepth>=0,'IRQ accounting underflow');if irqDepth==0 then irqTicks=irqTicks+emu.getState().masterClock-irqClock;irqClock=0 end end)
end
cb('_fx_build_packet',function()packetClock=activeClock() end)
for _,name in ipairs({'initialized','sorted','packet_done'})do
 cb(name,function()local c=activeClock();cpuParts['packet_'..name]=(c-packetClock)/21477.272;packetClock=c end)
end
if pipeline then
 cb('dma_started',function()
  local state=emu.getState();dmaClock=state.masterClock;dmaLine=state['ppu.scanline'];dmaLength=emu.read16(0x4305,emu.memType.snesMemory)
 end)
 cb('pipe_dma_measured_end',function()
  local state=emu.getState();dmaJobs[#dmaJobs+1]=string.format('{"field":%d,"line":%d,"endLine":%d,"length":%d,"ms":%.6f}',field,dmaLine,state['ppu.scanline'],dmaLength,(state.masterClock-dmaClock)/21477.272)
 end)
 local diag=assert(io.open(output..'/pipeline_trace.jsonl','w'))
 for _,name in ipairs({'pipe_irq','pipe_irq_transfer','pipe_wait_dma','dma_started','half_dma_finished','prefetch_finished','pipe_irq_done'})do
  cb(name,function()
   if presents<10 then
    local s=emu.getState();local mt=emu.memType.snesMemory
    diag:write(string.format('{"label":"%s","field":%d,"present":%d,"line":%d,"clock":%d,"src":%d,"len":%d,"grant":%d}\n',name,field,presents,s['ppu.scanline'],s.masterClock,emu.read16(0x4302,mt)+65536*emu.read(0x4304,mt),emu.read16(0x4305,mt),emu.read16(0x311c,mt)));diag:flush()
   end
  end)
 end
 cb('prefetch_finished',function()
  if true then return end
  local mt=emu.memType.snesMemory
  local slot=emu.read16(0x7e0000+labels.pipe_target_slot,mt)
  local record=0x7e0000+labels.pipe_records+slot*512
  local gen=emu.read16(record+8,mt)
  if gen<=120 or gen%60==0 then
   local bank=emu.read16(record,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read(((bank&255)-0x40)*65536+(bank&0xff00)+i,emu.memType.snesSaveRam))end
   completedFrames[gen]=table.concat(t)
  end
 end)
 cb(labels.pipe_irq_checked and 'pipe_irq_checked' or 'pipe_irq_done',function()
  -- IRQ�����̃L���[�Ǘ��͕\���������s�ł���BPPU�̎��]���E�ؑֈʒu��ʁX�Ɍ�������B
  local line=emu.getState()['ppu.scanline']
  local mt=emu.memType.snesMemory;local ready=0;local rendering=0
  for i=0,8-1 do local s=emu.read16(0x7e0000+labels.pipe_status+i*2,mt);if s==2 then ready=ready+1 elseif s==1 then rendering=rendering+1 end end
  queueSamples[#queueSamples+1]=string.format('{"field":%d,"line":%d,"ready":%d,"rendering":%d,"complete":%d,"flipped":%d,"target":%d}',field,line,ready,rendering,emu.read16(0x7e0000+labels.pipe_complete,mt),emu.read16(0x7e0000+labels.pipe_presented_irq,mt),emu.read16(0x7e0000+labels.pipe_target_slot,mt))
 end)
end
if labels.sa1_list_sort or labels.sa1_sort_packet or labels.sa1_temporal_prepare or labels.sa1_radix_sort or labels.sa1_key_buckets then
 cb(labels.sa1_list_sort and 'sa1_list_sort' or labels.sa1_key_buckets and 'sa1_key_buckets' or labels.sa1_radix_sort and 'sa1_radix_sort' or (labels.sa1_sort_packet and 'sa1_sort_packet' or 'sa1_temporal_prepare'),function()
  local mt=false and emu.memType.sa1Memory or emu.memType.snesMemory;local base=false and 0x400000 or 0x7e0000
  local n=false and emu.read16(labels.packet_work+8,emu.memType.sa1Memory) or emu.read16(base+labels.packet_work+8,mt)
  sortReference={}
  for i=0,n-2,2 do sortReference[#sortReference+1]={key=emu.read16(base+labels.keys+i,mt),value=emu.read16(base+labels.order+i,mt),index=i}end
  table.sort(sortReference,function(a,b)return a.key<b.key or (a.key==b.key and a.index<b.index)end)
 end)
 cb('sorted',function()
  if sortReference then
   local base=false and 0x400000 or 0x7e0000
   local mt=false and emu.memType.sa1Memory or emu.memType.snesMemory
   for i,v in ipairs(sortReference)do assert(emu.read16(base+labels.order+(i-1)*2,mt)==v.value,'packet sort changed depth/priority/stability field='..field..' index='..i..' expected='..v.value..' key='..v.key..' actual='..emu.read16(base+labels.order+(i-1)*2,mt))end
   sortReference=nil
  end
 end)
end
local function dump(name,mem,a,n)
 local f=assert(io.open(output..'/'..name,'wb'));local t={}
 for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
 f:write(table.concat(t));f:close()
end
if labels.stage_too_large then cb('stage_too_large',function()error('compact WRAM staging capacity exceeded field='..field)end)end
if labels.stage_time_ok then
 local started=0;local bytes=0;local count=0;local line=0
 cb('stage_time_ok',function()
  local st=emu.getState();local mt=emu.memType.snesMemory
  local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.stage_record,mt)
  started=st.masterClock;line=st['ppu.scanline'];bytes=emu.read16(record+34,mt);count=emu.read16(record+2,mt)//6
 end)
 cb('stage_converted',function()
  local st=emu.getState()
  cpuStageJobs[#cpuStageJobs+1]=string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}',field,bytes,count,line,st['ppu.scanline'],(st.masterClock-started)/21477.272)
 end)
end
if labels.fast_base_ready then
 local debug=assert(io.open(output..'/fast_debug.txt','w'))
 for _,name in ipairs({'sa1_try_fast','fast_tiles','fast_fail','fast_base_ready','invoke_row'})do
  cb(name,function()
   if presents==0 then
    local mt=emu.memType.sa1Memory
    debug:write(name)
    for _,a in ipairs({0x34,0x36,0x38,0x3a,0x44,0x48,0xa0,0xa2,0xb0,0xb2,0xb4,0xc0,0xc2,0xf8})do debug:write(string.format(' %02x=%04x',a,emu.read16(a,mt)))end
    debug:write('\n');debug:flush()
   end
  end,emu.cpuType.sa1)
 end
end
if labels.invoke_row then
 local recent=assert(io.open(output..'/native_trace.jsonl','w'))
 cb('invoke_row',function()
  local mt=emu.memType.sa1Memory
  local entry=emu.read16(0x7f1,mt)+65536*emu.read(0x7f3,mt)
  local n=emu.read16(0x8c,mt)
  if presents>=24 and presents<26 then
   recent:write(string.format('{"present":%d,"entry":%d,"len":%d,"dy":%d,"asset":%d,"wordstart":%d,"initialA":%d,"edge":%d}\n',presents,entry,n,emu.read16(0x40,mt),emu.read16(0x3e,mt),emu.read16(0xd4,mt),emu.read16(0xd6,mt),emu.read16(0x90,mt)));recent:flush()
   dump('latest_jit.bin',emu.memType.sa1InternalRam,0x700,256)
  end
 end,emu.cpuType.sa1)
end
cb('_fx_frame',function()
 logic=logic+1
 begin=emu.getState().masterClock
 if scenario:match('stress') then byte('_monosh_player_invuln',255)end
 if scenario:match('^boss') then
  byte('_monosh_player_invuln',255)
  if field>=90 then
   byte('_monosh_enemy_stage_complete_flag',1)
   byte('_monosh_enemy_active_count_value',0)
   byte('_monosh_stage_object_count',0)
   word('_monosh_stage_frame_counter',3900)
  end
 end
end)
if labels.cache_miss then
 local f=assert(io.open(output..'/bullet_cache.jsonl','w'));local start=0;local missed=false
 cb('sa1_bullet_cache_prepare',function()start=emu.getState().masterClock;missed=false end,emu.cpuType.sa1)
 cb('cache_miss',function()missed=true end,emu.cpuType.sa1)
 cb('cache_ready',function()
  local mt=emu.memType.sa1Memory
  f:write(string.format('{"job":%d,"field":%d,"asset":%d,"width":%d,"height":%d,"flags":%d,"miss":%s,"ms":%.6f}\n',#times+1,field,emu.read16(0x3e,mt),emu.read16(0x34,mt),emu.read16(0x36,mt),emu.read16(0x3c,mt),missed and 'true' or 'false',(emu.getState().masterClock-start)/21477.272));f:flush()
 end,emu.cpuType.sa1)
end
cb('render_started',function()begin=emu.getState().masterClock;cpuParts={} end)
cb('logic_finished',function()
 if scenario:match('^leftfixture') then
  local geometries={{0,90,48},{3,90,47},{0,93,50},{3,93,49},{0,97,52},{3,96,51},{0,104,55},{3,100,53},{0,107,57},{3,103,55},{0,114,61},{3,110,58}}
  local centers={-40,0,16,30,64,128,250}
  local bottoms={40,120,205}
  word('_fx_packet_count',2)
  for i=1,2 do
   local g=geometries[math.floor((logic-1)/7)*2%#geometries+i]
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[(logic+i-2)%#centers+1]&65535,mt)
   emu.write16(a+2,bottoms[math.floor((logic-1)/#centers)%#bottoms+1],mt)
   emu.write(a+4,g[2],mt);emu.write(a+5,g[3],mt);emu.write(a+6,g[1],mt);emu.write(a+7,0,mt);emu.write16(a+8,i,mt)
  end
 end
 if scenario:match('^flipfixture') then
  local assets={6,7,8,37};local sizes={6,16,32,48,62}
  local size=sizes[math.floor((logic-1)/12)%5+1]
  local flags=(math.floor((logic-1)/3)%4)*16+(logic-1)%3
  local centers={-2,254,128,64};local bottoms={120,200,30,160}
  word('_fx_packet_count',4)
  for i=1,4 do
   local a=0x7e0000+labels._fx_packet+(i-1)*10;local mt=emu.memType.snesMemory
   emu.write16(a,centers[i]&65535,mt);emu.write16(a+2,bottoms[i],mt)
   emu.write(a+4,size,mt);emu.write(a+5,size,mt);emu.write(a+6,assets[i],mt);emu.write(a+7,flags,mt)
   emu.write16(a+8,0,mt)
  end
 end
 logicMs=(emu.getState().masterClock-begin)/21477.272
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 cpuJobs[#cpuJobs+1]=string.format('{"field":%d,"logicMs":%.6f,"parts":{%s}}',field,logicMs,table.concat(parts,','))
end)
cb('transfer_chunk',function()local s=emu.getState();readyLine=s['ppu.scanline'];startClock=s.masterClock end)
cb('dma_chunk_ready',function()waitMs=(emu.getState().masterClock-startClock)/21477.272;startClock=emu.getState().masterClock end)
cb('sa1_clear_start',function()sa1begin=emu.getState().masterClock end,emu.cpuType.sa1)
if labels.sa1_sprite_begin then
 cb('sa1_sprite_begin',function()objectBegin=emu.getState().masterClock end,emu.cpuType.sa1)
 cb('sa1_sprite_done',function()
  local mt=emu.memType.sa1Memory;local i=emu.read16(0x2c,mt);local a=0x430000+i*10;local ms=(emu.getState().masterClock-objectBegin)/21477.272
  if ms>0.5 then objectJobs[#objectJobs+1]=string.format('{"field":%d,"job":%d,"index":%d,"asset":%d,"width":%d,"height":%d,"x":%d,"bottom":%d,"ms":%.6f}',field,#times+1,i,emu.read(a+6,mt),emu.read(a+4,mt),emu.read(a+5,mt),emu.read16(a,mt),emu.read16(a+2,mt),ms)end
 end,emu.cpuType.sa1)
end
if labels.sa1_output_done then cb('sa1_output_done',function()outputJobs[#outputJobs+1]=string.format('{"field":%d,"totalOutputMs":%.6f}',field,(emu.getState().masterClock-sa1begin)/21477.272)end,emu.cpuType.sa1)end
if labels.sa1_dirty_done then
 cb('sa1_dirty_done',function()
 if pipeline then jobSequence=jobSequence+1;assert(emu.read16(0x198,emu.memType.sa1Memory)==jobSequence,'SA-1 job duplicated or skipped')end
dirtyDone=emu.getState().masterClock;dirtyMs=(dirtyDone-sa1begin)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_clear_done',function()clearDone=emu.getState().masterClock;clearMs=(clearDone-dirtyDone)/21477.272 end,emu.cpuType.sa1)
 cb('sa1_native_done',function()nativeDone=emu.getState().masterClock;nativeMs=(nativeDone-drawbegin)/21477.272 end,emu.cpuType.sa1)
end
cb('sa1_draw_start',function()drawbegin=emu.getState().masterClock;bgMs=(drawbegin-clearDone)/21477.272 end,emu.cpuType.sa1)
cb('sa1_draw_done',function()
 local now=emu.getState().masterClock
 local mt=emu.memType.sa1Memory;local n=emu.read16(0x106,mt);local trace={}
 for _,a in ipairs({0x108,0x10a,0x10c,0x106})do local v=emu.read16(a,mt);trace[#trace+1]=string.char(v&255,v>>8)end
 for i=0,n*10-1 do trace[#trace+1]=string.char(emu.read(0x430000+i,mt))end
 packetTrace:write(table.concat(trace))
 if pipeline then
  local cpuMt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_render_slot,cpuMt)
  local gen=emu.read16(0x7e0000+labels.pipe_records+slot*512+8,cpuMt)
  if true and (gen<=120 or gen%60==0) then
   local bank=emu.read16(0x102,mt);local base=emu.read16(0x19a,mt);local t={}
   for i=0,24575 do t[#t+1]=string.char(emu.read((bank&255)*65536+base+i,mt))end
   completedFrames[gen]=table.concat(t)
  end
  if gen<=120 or gen%60==0 then local t={};for i=0,n*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,mt))end;completedPackets[gen]=table.concat(t)end
 end
 local dirtyBytes=0
 for r=0,23 do local a=0x120+r*4;dirtyBytes=dirtyBytes+math.max(0,emu.read16(a+2,emu.memType.sa1Memory)-emu.read16(a,emu.memType.sa1Memory))*8 end
 if presents==0 then
  dump('first_bw.bin',emu.memType.snesSaveRam,0,65536)
  dump('first_iram.bin',emu.memType.sa1InternalRam,0,2048)
 end
 local parts={};for name,v in pairs(cpuParts)do parts[#parts+1]=string.format('"%s":%.6f',name,v)end
 times[#times+1]=string.format('{"field":%d,"clearAndBgMs":%.6f,"drawMs":%.6f,"totalSa1Ms":%.6f,"dirtyMs":%.6f,"clearMs":%.6f,"bgMs":%.6f,"nativeMs":%.6f,"compactMs":%.6f,"logicMs":%.6f,"dirtyBytes":%d,"cpuParts":{%s}}',field,(drawbegin-sa1begin)/21477.272,(now-drawbegin)/21477.272,(now-sa1begin)/21477.272,dirtyMs,clearMs,bgMs,nativeMs,(now-nativeDone)/21477.272,logicMs,dirtyBytes,table.concat(parts,','))
end,emu.cpuType.sa1)
if labels.pipe_fast_begin then
 local fastClock,fastBytes,fastCount,fastLine=0,0,0,0
 local fastLog=assert(io.open(output..'/fast_dma.jsonl','w'))
 local rejectedLog=assert(io.open(output..'/rejected_dma.jsonl','w'))
 cb('pipe_fast_unavailable',function()
  local mt=emu.memType.snesMemory;local base=0x7e0000
  local record=base+labels.pipe_records+emu.read16(base+labels.pipe_record_offset,mt)
  rejectedLog:write(string.format('{"field":%d,"gen":%d,"bytes":%d,"count":%d,"cost":%d,"available":%d}\n',field,emu.read16(record+8,mt),emu.read16(record+34,mt),(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6,emu.read16(base+labels.pipe_dma_chunk,mt),emu.read16(base+labels.pipe_available,mt)));rejectedLog:flush()
 end)
 cb('pipe_fast_begin',function()
  local st=emu.getState();assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA began outside actual blank period')
  if scenario:match('tracedma') then
   local st=emu.getState();local f=assert(io.open(output..'/cc_state.jsonl','a'))
   f:write(string.format('{"field":%d,"source":%d,"dest":%d,"active":%s,"blank":%s,"line":%d}\n',field,st['cart.coprocessor.dmaSrcAddr'],st['cart.coprocessor.dmaDestAddr'],tostring(st['cart.coprocessor.charConvDmaActive']),tostring(st['ppu.forcedBlank']),st['ppu.scanline']));f:close()
   if presents==0 then
    local f=assert(io.open(output..'/before_dma_bw.bin','wb'));local a={}
    for i=0,24575 do a[#a+1]=string.char(emu.read(1024+i,emu.memType.snesSaveRam))end
    f:write(table.concat(a));f:close()
   end
  end
  local mt=emu.memType.snesMemory;local record=0x7e0000+labels.pipe_records+emu.read16(0x7e0000+labels.pipe_record_offset,mt)
  fastClock=emu.getState().masterClock;fastLine=emu.getState()['ppu.scanline']
  fastBytes=emu.read16(record+34,mt);fastCount=(emu.read16(record+2,mt)-emu.read16(record+4,mt))/6
 end)
 cb('pipe_fast_done',function()
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'VRAM DMA ended outside actual blank period')
  if scenario:match('tracedma') and presents==0 then
   local f=assert(io.open(output..'/beforeflip_vram.bin','wb'));local a={}
   for i=0,65535 do a[#a+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
   f:write(table.concat(a));f:close()
  end
  fastLog:write(string.format('{"field":%d,"bytes":%d,"count":%d,"line":%d,"endLine":%d,"ms":%.6f}\n',field,fastBytes,fastCount,fastLine,st['ppu.scanline'],(st.masterClock-fastClock)/21477.272));fastLog:flush()
 end)
end
if labels.fx_obj_upload_done then cb('fx_obj_upload_done',function()
 if field>90 then
  local st=emu.getState()
  assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'OAM DMA ended outside actual blank period')
 end
end)end
if labels.dense_vram_overflow then cb('dense_vram_overflow',function()error('packed image exceeds one VRAM page')end,emu.cpuType.sa1)end
if vramPrefetch3 then
 emu.addMemoryCallback(function(address,value)
  if field>85 then
   local st=emu.getState()
   assert(st['ppu.forcedBlank'] or st['ppu.scanline']>=225,'BG1 map changed outside actual blank period')
  end
 end,emu.callbackType.write,0x2107,0x2107,emu.cpuType.snes,emu.memType.snesMemory)
end
if labels.pipe_flip then cb('pipe_flip',function()flipBegin=emu.getState().masterClock;pageCommit=nil end)end
cb('dma_finished',function()
 presents=presents+1
 if pipeline then local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt);assert(emu.read16(0x7e0000+labels.pipe_records+slot*512+8,mt)==presents,'pipeline skipped or reordered a frame')end
 local state=emu.getState();local line=(pageCommit and pageCommit.line) or state['ppu.scanline']
 local commitField=(pageCommit and pageCommit.field) or field
 local visibleField=commitField+(line>=203 and line<225 and 1 or 0)
 assert(line<=21 or line>=203,'page flip occurred during visible lines')
 presentationTimes[#presentationTimes+1]=string.format('{"field":%d,"visibleField":%d,"line":%d,"clock":%d,"dmaBytes":%d,"readyLine":%d,"waitMs":%.6f,"transferMs":%.6f,"flipMs":%.6f}',field,visibleField,line,state.masterClock,emu.read16(0x7e0000+labels.fx4_dma_bytes,emu.memType.snesMemory),readyLine,waitMs,(state.masterClock-startClock)/21477.272,(state.masterClock-flipBegin)/21477.272)
 if presents<=120 or presents%60==0 then
  local n=string.format('present%05d',presents)
  local record=nil
  if pipeline then
   local mt=emu.memType.snesMemory;local slot=emu.read16(0x7e0000+labels.pipe_front_slot,mt)
   record=0x7e0000+labels.pipe_records+slot*512
   local gen=emu.read16(record+8,mt);assert(gen==presents,'pipeline skipped or reordered a frame')
   if true then dump(n..'_record.bin',emu.memType.snesMemory,record,512)end
   if true then dump(n..'_ground_h.bin',emu.memType.snesMemory,0x7e0000+emu.read16(record+26,mt),270)end
   for i=0,23 do assert(emu.read(i,emu.memType.snesSpriteRam)==emu.read(record+64+i,mt),'pipeline OAM differs field='..field..' gen='..presents..' byte='..i..' actual='..emu.read(i,emu.memType.snesSpriteRam)..' expected='..emu.read(record+64+i,mt))end
   if true then
    local expected=emu.read16(record+192,mt)|0x0aaa
    local actual=emu.read16(512,emu.memType.snesSpriteRam)
    assert((actual&0x0fff)==(expected&0x0fff),'player high OAM differs')
    dump(n..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    dump(n..'_palette.bin',emu.memType.snesCgRam,0,512)
   else
    for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==emu.read(record+192+i,mt),'pipeline high OAM differs')end
   end
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));f:write((assert(completedFrames[gen],'missing completed snapshot')));f:close();completedFrames[gen]=nil
  elseif padded then
   local f=assert(io.open(output..'/'..n..'_fb.bin','wb'));local t={}
   for y=0,191 do for x=0,127 do t[#t+1]=string.char(emu.read(y*256+64+x,emu.memType.snesSaveRam))end end
   f:write(table.concat(t));f:close()
  else dump(n..'_fb.bin',emu.memType.snesSaveRam,0,24576)end
  if true and record then dump(n..'_background.bin',emu.memType.snesSaveRam,0x30000+emu.read16(record+40,emu.memType.snesMemory),2048)end
  dump(n..'_vram.bin',emu.memType.snesVideoRam,0,65536)
  local count=emu.read16(pipeline and record+16 or 0x3106,emu.memType.snesMemory)
  local f=assert(io.open(output..'/'..n..'_meta.bin','wb'))
  local t={}
  local addresses=pipeline and {record+10,record+12,record+14,record+16,0x7e0000+labels.fx4_page} or {0x3108,0x310a,0x310c,0x3106,0x7e0000+labels.fx4_page}
  for _,a in ipairs(addresses)do
   local v=emu.read16(a,emu.memType.snesMemory);t[#t+1]=string.char(v&255,v>>8)
  end
  if pipeline then
   local gen=emu.read16(record+8,emu.memType.snesMemory)
   t[#t+1]=assert(completedPackets[gen],'missing completed packet');completedPackets[gen]=nil
  else
   for i=0,count*10-1 do t[#t+1]=string.char(emu.read(0x430000+i,emu.memType.snesMemory))end
  end
  f:write(table.concat(t));f:close()
 end
end)
emu.addEventCallback(function()
 local input={a=true}
 if scenario:match('move') then
  local phase=logic%240
  input.right=phase<60;input.left=phase>=120 and phase<180
  input.up=phase>=60 and phase<120;input.down=phase>=180
 end
 emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 field=field+1
 if true and field>90 then
  for i=0,31 do
   local fx=emu.read(32+i,emu.memType.snesCgRam)
   local near=emu.read(480+i,emu.memType.snesCgRam)
   if fx~=expectedPalette[i+1] or near~=expectedPalette[i+1] then
    local f=assert(io.open(output..'/failure.txt','w'))
    f:write('CGRAM changed field='..field..' byte='..i..' fx='..fx..' near='..near..' expected='..expectedPalette[i+1]);f:close();emu.stop(1);return
   end
  end
 end
 local finished=field==maxframe or (targetPresents>0 and presents>=targetPresents)
 if finished then
  local f=assert(io.open(output..'/final_state.txt','w'));for k,v in pairs(emu.getState())do f:write(tostring(k)..'='..tostring(v)..'\n')end;f:close()
 end
 if field==120 or finished then
  local f=assert(io.open(output..'/frame'..field..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer())do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255)end
  f:write(table.concat(t));f:close()
 end
 if finished then
  local st=assert(io.open(output..'/end_state.txt','w'));for k,v in pairs(emu.getState())do st:write(tostring(k)..'='..tostring(v)..'\n')end;st:close()
  dump('end_wram.bin',emu.memType.snesWorkRam,0,131072)
  finishedCapture=true
  packetTrace:close()
  local f=assert(io.open(output..'/summary.json','w'))
  f:write(string.format('{"fields":%d,"logic":%d,"presents":%d,"presentationTimes":[%s],"sa1Jobs":[%s],"cpuJobs":[%s],"outputJobs":[%s],"queueSamples":[%s],"objectJobs":[%s],"dmaJobs":[%s],"cpuStageJobs":[%s]}',field,logic,presents,table.concat(presentationTimes,','),table.concat(times,','),table.concat(cpuJobs,','),table.concat(outputJobs,','),table.concat(queueSamples,','),table.concat(objectJobs,','),table.concat(dmaJobs,','),table.concat(cpuStageJobs,',')));f:close()
  dump('iram.bin',emu.memType.sa1InternalRam,0,2048)
  emu.stop(0)
 end
end,emu.eventType.endFrame)
