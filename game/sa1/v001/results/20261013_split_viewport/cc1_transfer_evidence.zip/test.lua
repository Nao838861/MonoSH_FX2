local jobs={{["name"]="game530",["bank"]=64},{["name"]="game531",["bank"]=65},{["name"]="game532",["bank"]=66},{["name"]="game533",["bank"]=64},{["name"]="game534",["bank"]=65},{["name"]="game535",["bank"]=66},{["name"]="game536",["bank"]=64},{["name"]="game537",["bank"]=65},{["name"]="game538",["bank"]=66},{["name"]="game539",["bank"]=64},{["name"]="game540",["bank"]=65},{["name"]="game541",["bank"]=66},{["name"]="game542",["bank"]=64},{["name"]="game543",["bank"]=65},{["name"]="game544",["bank"]=66},{["name"]="game545",["bank"]=64},{["name"]="game546",["bank"]=65},{["name"]="game547",["bank"]=66},{["name"]="game548",["bank"]=64},{["name"]="game549",["bank"]=65},{["name"]="game550",["bank"]=66},{["name"]="game551",["bank"]=64},{["name"]="game552",["bank"]=65},{["name"]="game553",["bank"]=66},{["name"]="game554",["bank"]=64},{["name"]="game555",["bank"]=65},{["name"]="game556",["bank"]=66},{["name"]="game557",["bank"]=64},{["name"]="game558",["bank"]=65},{["name"]="game559",["bank"]=66},{["name"]="game560",["bank"]=64},{["name"]="game561",["bank"]=65},{["name"]="game562",["bank"]=66},{["name"]="game563",["bank"]=64},{["name"]="game564",["bank"]=65},{["name"]="game565",["bank"]=66},{["name"]="game566",["bank"]=64},{["name"]="game567",["bank"]=65},{["name"]="game568",["bank"]=66},{["name"]="game569",["bank"]=64},{["name"]="game570",["bank"]=65},{["name"]="all_colors_pattern",["bank"]=66}}
local labels={["__SA1_LOAD__"]=32946,["__SA1_RUN__"]=512,["__SA1_SIZE__"]=81,["probe_finished"]=32936,["probe_ready"]=32831,["reset"]=32768,["split_transfer_begin"]=32843,["split_transfer_end"]=32936}
local output="D:/HomeBrew/MonoSHSA1_4bpp60_20261010/build/sa1_split_cc1"
local index=1;local ready=false;local start=0;local rows={}
local function cb(name,fn)
 emu.addMemoryCallback(fn,emu.callbackType.exec,labels[name],labels[name],emu.cpuType.snes,emu.memType.snesMemory)
end
cb('probe_ready',function()
 if ready then return end
 local j=jobs[index];local f=assert(io.open(output..'/'..j.name..'_source.bin','rb'));local s=f:read('*a');f:close()
 assert(#s==49152)
 local bank=(j.bank-0x40)*65536
 for i=0,24575 do
  emu.write(bank+0x400+i,s:byte(i+1),emu.memType.snesSaveRam)
  emu.write(bank+0x8400+i,s:byte(24577+i),emu.memType.snesSaveRam)
 end
 for _,a in ipairs({0x6a00,0xea00})do for i=0,63 do emu.write(bank+a+i,(i*71+37)&255,emu.memType.snesSaveRam)end end
 emu.write16(0x3108,j.bank,emu.memType.snesMemory);emu.write16(0x3100,1,emu.memType.snesMemory);ready=true
end)
cb('split_transfer_begin',function()start=emu.getState().masterClock end)
cb('probe_finished',function()
 local j=jobs[index];local t={}
 for i=0,24575 do t[#t+1]=string.char(emu.read(i,emu.memType.snesVideoRam))end
 local f=assert(io.open(output..'/'..j.name..'_actual.bin','wb'));f:write(table.concat(t));f:close()
 local bank=(j.bank-0x40)*65536
 for _,a in ipairs({0x6a00,0xea00})do for i=0,63 do assert(emu.read(bank+a+i,emu.memType.snesSaveRam)==((i*71+37)&255),'prefix metadata changed')end end
 local s=emu.getState();assert(not s['cart.coprocessor.charConvDmaActive'])
 rows[#rows+1]=string.format('{"name":"%s","bank":%d,"clocks":%d}',j.name,j.bank,s.masterClock-start)
 if index==#jobs then
  local f=assert(io.open(output..'/timings.json','w'));f:write('['..table.concat(rows,',')..']');f:close();emu.stop(0)
 else index=index+1;ready=false end
end)
