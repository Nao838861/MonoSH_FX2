"""木4のnative行を逆順へ置換する場合のコード・hint量を数える。実装・速度評価ではない。"""
import hashlib,json,struct,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from sa1_left_hints import physical
from sa1_reverse_explosions import compress_hint
from verify_sa1_native_fragments import execute
b=root/'build/sa1_game';rom=(b/'right_narrow_v2_build/MonoSHSA1_4bpp_game.sfc').read_bytes();pointers=set()
geometries=0;rows=0
for width in range(1,256):
 block=struct.unpack_from('<H',rom,0x7f0000+4*512+width*2)[0]
 if not block:continue
 for i in range(rom[0x7f0000+block]):
  entry=0x7f0000+block+1+i*10;h=rom[entry];geometries+=1
  desc=struct.unpack_from('<H',rom,entry+1)[0]
  for parity in range(2):
   chain=physical(int.from_bytes(rom[0x7f0000+desc+parity*3:0x7f0000+desc+parity*3+3],'little'))
   for y in range(h):
    q=chain+y*11;assert rom[q]==0xa9 and rom[q+7]==0x22
    pointers.add(int.from_bytes(rom[q+8:q+11],'little'));rows+=1
codes=set();hints=set();added=0;old_bytes=0
for ptr in pointers:
 p=physical(ptr);code=rom[p:p+rom[p-2]];state=execute(code);reverse=bytearray();starts=[]
 for offset,(source,mask,value)in sorted(state.items(),reverse=True):
  assert source in (None,offset)
  starts.append((offset,len(reverse)))
  if mask:reverse+=b'\xbd'+struct.pack('<H',offset)+b'\x29'+struct.pack('<H',mask)+b'\x09'+struct.pack('<H',value)
  else:reverse+=b'\xa9'+struct.pack('<H',value)
  reverse+=b'\x9d'+struct.pack('<H',offset)
 reverse+=b'\x6b';assert execute(reverse)==state and len(reverse)<=255
 hint=bytes(next((pc for off,pc in starts if off<limit),len(reverse)-1)for limit in range(0,rom[p-1]+1,2))
 hints.add(compress_hint(hint));codes.add(bytes(reverse));added+=len(reverse)-len(code);old_bytes+=len(code)
result=dict(romSha256=hashlib.sha256(rom).hexdigest(),asset=4,geometries=geometries,rows=rows,
 uniqueOriginalKernels=len(pointers),originalKernelBytes=old_bytes,uniqueReversedKernels=len(codes),
 reversedCodeBytes=sum(map(len,codes)),sumPerOriginalKernelCodeIncreaseBytes=added,
 compressedHintBytes=sum(map(len,hints)),uniqueCompressedHints=len(hints),
 extraInlineHeaderBytes=3*len(codes),
 extraBytesWithThreeBytePointers=added+sum(map(len,hints))+3*len(codes),
 indexedHintCountFitsOneByte=len(hints)<=256,
 extraBytesWithOneByteHintIndex=added+sum(map(len,hints))+len(codes)+3*len(hints),
 sourceOnly=True,gameIntegrated=False,runtimeCostMeasured=False,
 allocationAndSharedOriginalKernelsNotResolved=True,goal60fpsAchieved=False)
dest=root/'game/sa1/v001/results/20261013_long_audit/reverse_tree_capacity.json'
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
