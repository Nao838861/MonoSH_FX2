"""同じ保存ROM・画面・監査ログを使い、host側の起動番号仮定だけを修正して再検証する。"""
import hashlib,json,re,sys
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from test_sa1_game import verify_pixels,verify_game_state_audit,verify_mask_bounds
name='move_detinput_auditgame_long4000_tracepalette_tracebounds_tracedeadline'
dest=root/'build/sa1_game'/name;snapshot=root/'build/sa1_game/long4000_full192_build'
config=json.loads((dest/'manifest.json').read_text())
assert hashlib.sha256((snapshot/'MonoSHSA1_4bpp_game.sfc').read_bytes()).hexdigest()==config['romSha256']
assert (dest/'game.lbl').read_bytes()==(snapshot/'game.lbl').read_bytes()
labels={n:int(a,16) for a,n in re.findall(r'al ([0-9A-Fa-f]+) \.([^\s]+)',(dest/'game.lbl').read_text())}
assert not (dest/'failure.txt').exists()
summary=json.loads((dest/'summary.json').read_text())
summary['pixelMatchedPresents']=verify_pixels(dest,labels,config)
summary['hardwarePpuReferencesVerified']=bool(config.get('pipeline') and len(list(dest.glob('present*_ppu.json')))==summary['pixelMatchedPresents'])
summary['romSha256']=config['romSha256'];summary['irqMathRegistersVerified']=bool(config.get('pipeline'))
summary['labelsSha256']=hashlib.sha256((dest/'game.lbl').read_bytes()).hexdigest()
intervals=np.diff([p['visibleField']for p in summary['presentationTimes'][2:]])
summary['presentationFieldIntervals']={str(int(k)):int(v)for k,v in zip(*np.unique(intervals,return_counts=True))}
summary['stalledTailFields']=max(0,summary['fields']-summary['presentationTimes'][-1]['visibleField'])
summary['goal60fpsAchieved']=bool(len(intervals)>=120 and np.all(intervals==1)and summary['stalledTailFields']<=1)
for label,file,key in [('flame_direct_row','flame_direct.jsonl','flameDirectCoverage'),('direct_left_row','direct_left.jsonl','directLeftCoverage')]:
 if labels.get(label):
  events=[json.loads(x)for x in (dest/file).read_text().splitlines()]
  summary[key]=dict(rows=len(events),jobs=len({x['job']for x in events}))
  if key=='directLeftCoverage':summary[key]['assets']=sorted({x['asset']for x in events})
summary['gameStateAudit']=verify_game_state_audit(dest,summary['logic'],name)
summary['maskBoundsVerified']=verify_mask_bounds(dest,config.get('maskBounds',False))
assert len(summary['sa1Jobs'])<=summary['maskBoundsVerified']['jobs']<=len(summary['sa1Jobs'])+1
summary['hostPostverificationReplayed']=True
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dest/'host_audit_reverified.json').write_text(json.dumps(dict(romSha256=config['romSha256'],
 gameStateAudit=summary['gameStateAudit'],pixelMatchedPresents=summary['pixelMatchedPresents'],
 hardwarePpuReferencesVerified=summary['hardwarePpuReferencesVerified'],sameSavedCapture=True,
 emulatorRerun=False,gameChanged=False),indent=2)+'\n')
print(json.dumps({k:summary[k]for k in ('fields','logic','presents','pixelMatchedPresents','presentationFieldIntervals','gameStateAudit')},indent=2))
