.export pfTables
.export pf_full_check
.export pf_search, pf_found, pfBase, pfHigh, pfLow, pfMid, pfLimit
; SA-1が作った累積費用表で、転送する記述子数を二分探索する。
.setcpu "65816"
.smart
.macpack longbranch
.import pipe_records, pipe_record_offset, pipe_available, pipe_time_left
.export pipe_prefix_plan: far, pfPartial, pfBytes, pfDesc, sd_collect_costs: far
.segment "COLORBSS"
pfTables: .res 256*SA1_PIPELINE_DEPTH
.segment "BSS"
pfPartial: .res 2
pfBytes: .res 2
pfDesc: .res 2
pfBase: .res 2
pfBeforeBytes: .res 2
pfBeforeCost: .res 2
pfStart: .res 2
pfLow: .res 2
pfHigh: .res 2
pfMid: .res 2
pfLimit: .res 2
.segment "GSU"
.a16
.i16
sd_collect_costs:
  php
  phx
  phy
  rep #$30
  .ifdef SA1_PREFIX_CPU_TABLE
  ; 収集済みのWRAM記述子から作る。SA-1の描画と追加のBW転送を増やさない。
  txa
  lsr
  clc
  adc #pfTables
  tay
  lda pipe_records+2,x
  sta pfLimit
  txa
  clc
  adc #208
  tax
  clc
  adc pfLimit
  sta pfLimit
  stz pfBeforeBytes
  stz pfBeforeCost
pf_collect_next:
  cpx pfLimit
  bcs pf_collect_done
  lda pipe_records,x
  sta pfMid
  clc
  adc pfBeforeBytes
  sta pfBeforeBytes
  sta a:0,y
  lda pfMid
  .repeat 5
    lsr
  .endrepeat
  sta pfStart
  lsr
  lsr
  clc
  adc pfStart
  adc pfMid
  adc #SA1_PREFIX_DESC_COST
  adc pfBeforeCost
  sta pfBeforeCost
  sta a:2,y
  txa
  clc
  adc #6
  tax
  iny
  iny
  iny
  iny
  bra pf_collect_next
  .else
  lda f:$00311a
  beq pf_collect_done
  asl
  asl
  sta f:$004305
  lda pipe_records,x
  and #$8400
  clc
  adc #$6600
  sta f:$004302
  txa
  lsr
  clc
  adc #pfTables
  sta f:$002181
  sep #$20
  lda #0
  sta f:$002183
  lda pipe_records,x
  sta f:$004304
  lda #$95
  sta f:$002231
  lda #1
  sta f:$00420b
  .endif
pf_collect_done:
  rep #$30
  ply
  plx
  plp
  rtl
.segment "CODE"
.a16
.i16
pipe_prefix_plan:
  rep #$30
  stz pfPartial
  stz pfBytes
  stz pfDesc
  ldx pipe_record_offset
  txa
  lsr
  clc
  adc #pfTables
  sta pfBase
  lda pipe_records+4,x
  lsr
  tax
  lda f:pf_div6,x
  and #255
  sta pfStart
  sta pfLow
  ldx pipe_record_offset
  lda pipe_records+2,x
  lsr
  tax
  lda f:pf_div6,x
  and #255
  sta pfHigh
  stz pfBeforeBytes
  stz pfBeforeCost
  lda pfStart
  beq pf_budget
  dec
  asl
  asl
  clc
  adc pfBase
  tax
  lda a:0,x
  sta pfBeforeBytes
  lda a:2,x
  sta pfBeforeCost
pf_budget:
  ; cumulative[start] - cumulative[start-1] gives the original length.
  lda pfStart
  asl
  asl
  clc
  adc pfBase
  tax
  lda a:0,x
  sec
  sbc pfBeforeBytes
  pha
  ldx pipe_record_offset
  lda pipe_records+4,x
  clc
  adc pipe_record_offset
  adc #208
  tax
  pla
  sec
  sbc pipe_records,x
  jcc pf_empty
  beq pf_partial_accounted
  sta pfMid
  clc
  adc pfBeforeBytes
  sta pfBeforeBytes
  lda pfMid
  .repeat 5
    lsr
  .endrepeat
  sta pfLimit
  lsr
  lsr
  clc
  adc pfLimit
  adc pfMid
  adc pfBeforeCost
  sta pfBeforeCost
pf_partial_accounted:
  jsr pipe_time_left
  lda pipe_available
  sec
  sbc #384
  jmi pf_empty
  clc
  adc pfBeforeCost
  sta pfLimit
pf_full_check:
  lda pfLimit
  clc
  adc #192
  sta pfMid
  ; 全量が収まる場合は、6段探索も省く。
  lda pfHigh
  dec
  asl
  asl
  clc
  adc pfBase
  tax
  lda a:2,x
  cmp pfMid
  bcs pf_search
  lda pfHigh
  sta pfLow
  jmp pf_found
pf_search:
  phy
  lda pfHigh
  asl
  asl
  clc
  adc pfBase
  sec
  sbc #4
  sta pfMid
  lda pfBase
  sec
  sbc #4
  tay
  tya
  clc
  adc #128
  cmp pfMid
  bcc pf_lift_32_within
  bne pf_lift_32_skip
pf_lift_32_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_32_skip
  txy
pf_lift_32_skip:
  tya
  clc
  adc #64
  cmp pfMid
  bcc pf_lift_16_within
  bne pf_lift_16_skip
pf_lift_16_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_16_skip
  txy
pf_lift_16_skip:
  tya
  clc
  adc #32
  cmp pfMid
  bcc pf_lift_8_within
  bne pf_lift_8_skip
pf_lift_8_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_8_skip
  txy
pf_lift_8_skip:
  tya
  clc
  adc #16
  cmp pfMid
  bcc pf_lift_4_within
  bne pf_lift_4_skip
pf_lift_4_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_4_skip
  txy
pf_lift_4_skip:
  tya
  clc
  adc #8
  cmp pfMid
  bcc pf_lift_2_within
  bne pf_lift_2_skip
pf_lift_2_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_2_skip
  txy
pf_lift_2_skip:
  tya
  clc
  adc #4
  cmp pfMid
  bcc pf_lift_1_within
  bne pf_lift_1_skip
pf_lift_1_within:
  tax
  lda a:2,x
  cmp pfLimit
  bcs pf_lift_1_skip
  txy
pf_lift_1_skip:
  tya
  sec
  sbc pfBase
  clc
  adc #4
  lsr
  lsr
  sta pfLow
  ply
pf_found:
  lda pfLow
  sec
  sbc pfStart
  beq pf_empty
  asl
  sta pfDesc
  asl
  clc
  adc pfDesc
  sta pfDesc
  lda pfLow
  dec
  asl
  asl
  clc
  adc pfBase
  tax
  lda a:0,x
  sec
  sbc pfBeforeBytes
  sta pfBytes
  lda pfLow
  cmp pfHigh
  beq pf_all_selected
  lda #1
  sta pfPartial
pf_all_selected:
  sec
  rtl
pf_empty:
  clc
  rtl
.segment "GSU"
; IRQではゲーム側が使用中かもしれない本体の除算器を触らない。
pf_div6:
  .repeat 152, I
    .byte I/3
  .endrepeat
