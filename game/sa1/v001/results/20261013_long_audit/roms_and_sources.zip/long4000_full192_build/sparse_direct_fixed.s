; BWのraw画像を詰め直さず、転送先だけ連続CHRへ付け替える。
.setcpu "65816"
.smart
.macpack longbranch
.export sa1_sparse_direct_finish: far, sparse_direct_overflow: far
.ifndef SA1_PREFIX_DESC_COST
SA1_PREFIX_DESC_COST=64
.endif
.segment "GSU"
.a16
.i16
sa1_sparse_direct_finish:
  rep #$30
  lda $011a
  asl
  sta $b0
  asl
  clc
  adc $b0
  sta $b0
.ifdef SA1_PREFIX_TABLE
  stz $b4
  stz $b6
  lda $019a
  clc
  adc #$6600
  sta $b8
  lda $0102
  sta $ba
  ldy #0
.endif
  ldx #0
fixed_descriptor:
  cpx $b0
  bcs fixed_done
  lda f:$430804,x
  sec
  sbc #496
  sta f:$430804,x
.ifdef SA1_PREFIX_TABLE
  lda f:$430800,x
  sta $bc
  clc
  adc $b4
  sta $b4
  sta [$b8],y
  iny
  iny
  lda $bc
  .repeat 5
    lsr
  .endrepeat
  sta $be
  lsr
  lsr
  clc
  adc $be
  adc $bc
  adc #SA1_PREFIX_DESC_COST
  adc $b6
  sta $b6
  sta [$b8],y
  iny
  iny
.endif
  txa
  clc
  adc #6
  tax
  bra fixed_descriptor
fixed_done:
  rtl
sparse_direct_overflow:
  stp
