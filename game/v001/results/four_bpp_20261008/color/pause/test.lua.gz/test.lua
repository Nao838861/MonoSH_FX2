local labels={["LoadAudioData"]=34366,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=5837684,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=33957,["Tad_GetSong"]=34061,["Tad_GlobalVolumesPersist"]=34089,["Tad_GlobalVolumesResetOnSongStart"]=34083,["Tad_Init"]=33573,["Tad_IsLoaderActive"]=34115,["Tad_IsSfxPlaying"]=34129,["Tad_IsSongLoaded"]=34123,["Tad_IsSongPlaying"]=34135,["Tad_LoadSong"]=34016,["Tad_LoadSongIfChanged"]=34049,["Tad_Loader_Bin"]=5837568,["Tad_Loader_SIZE"]=116,["Tad_Process"]=33700,["Tad_QueueCommand"]=33973,["Tad_QueueCommandOverride"]=33978,["Tad_QueuePannedSoundEffect"]=33995,["Tad_QueueSoundEffect"]=34005,["Tad_ReloadCommonAudioData"]=34065,["Tad_SetTransferSize"]=34095,["Tad_SongsStartImmediately"]=34071,["Tad_SongsStartPaused"]=34077,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=1,["Tad_sfxQueue_sfx"]=0,["__BSS_LOAD__"]=58366,["__BSS_RUN__"]=58366,["__BSS_SIZE__"]=5747,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62168,["__DATA_LOAD__"]=4375547,["__DATA_RUN__"]=58363,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50171,["__STARTUP__"]=1,["_abs"]=61799,["_boss_age"]=58981,["_boss_attribute_cache"]=58816,["_boss_attribute_cache_count"]=58978,["_boss_attribute_z_cache"]=58960,["_boss_dda_phase"]=59199,["_boss_dda_x"]=59205,["_boss_dda_y"]=59211,["_boss_death_parts"]=58983,["_boss_death_timer"]=58982,["_boss_fire_gap"]=58992,["_boss_fire_round"]=58989,["_boss_fire_shots"]=58991,["_boss_fire_state"]=58988,["_boss_fire_volley"]=58990,["_boss_history_x"]=58432,["_boss_history_y"]=58560,["_boss_history_z"]=58688,["_boss_last_vblank"]=58368,["_boss_motion_steps"]=58987,["_boss_part_active"]=58396,["_boss_part_bottom"]=58378,["_boss_part_fall_fraction"]=58423,["_boss_part_fall_velocity"]=58414,["_boss_part_timer"]=58405,["_boss_part_x"]=58369,["_boss_part_z"]=58387,["_boss_path_half"]=58986,["_boss_player_bottom"]=58995,["_boss_player_x"]=58993,["_boss_render_camera_delta"]=58979,["_boss_restart_timer"]=58984,["_boss_z_phase"]=58985,["_death_accel_fraction"]=59233,["_death_timer"]=59231,["_death_vy"]=59230,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx4_explosion_lift"]=13212,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_audio_events"]=5648,["_fx_boss_hits"]=59018,["_fx_boss_project"]=58823,["_fx_build_ground"]=13298,["_fx_build_packet"]=23735,["_fx_buttons"]=61399,["_fx_draw"]=59475,["_fx_draw_count"]=60115,["_fx_em0_geometry"]=56060,["_fx_enemy_collisions"]=55527,["_fx_enemy_em1_update"]=56936,["_fx_enemy_em1_update_reference"]=7564,["_fx_enemy_fire_em1"]=7502,["_fx_enemy_remove"]=7491,["_fx_enemy_render"]=54854,["_fx_enemy_render_bullets"]=55133,["_fx_far_d_acc"]=61411,["_fx_far_u_acc"]=61409,["_fx_fire_actions"]=61402,["_fx_frame"]=57840,["_fx_ground_c1ptr"]=63167,["_fx_ground_c3ptr"]=63169,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=61418,["_fx_ground_color3"]=61868,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63133,["_fx_ground_far_xptr"]=63163,["_fx_ground_far_y"]=63173,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63171,["_fx_ground_horizontal"]=62318,["_fx_ground_hptr"]=63128,["_fx_ground_native"]=13383,["_fx_ground_palette_record"]=63131,["_fx_ground_phase"]=61398,["_fx_ground_vptr"]=63165,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63130,["_fx_init"]=11670,["_fx_input"]=61401,["_fx_open_size"]=60088,["_fx_packet"]=60118,["_fx_packet_count"]=60116,["_fx_present"]=12411,["_fx_read_input"]=12147,["_fx_send_ground"]=12207,["_fx_sky_color"]=39095,["_fx_stage_contact"]=54170,["_fx_stage_render"]=53468,["_fx_stage_update"]=54501,["_fx_submit"]=59876,["_ground_irq_vblank_count"]=61406,["_history_head"]=58980,["_hit_pending"]=61413,["_intro_timer"]=59234,["_legacy_enemy_fire_boss_at"]=6096,["_main"]=11707,["_memcpy"]=61630,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=58367,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2077,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=58603,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=58366,["_monosh_bullet_reflect_rng"]=59037,["_monosh_collision_bullet_bands"]=59029,["_monosh_combat_build_collision_bands"]=2259,["_monosh_combat_fast_cache_reset"]=12073,["_monosh_combat_fast_frame"]=59372,["_monosh_combat_fast_render"]=59502,["_monosh_combat_fast_render_cached"]=12080,["_monosh_combat_fire_cooldown"]=59038,["_monosh_combat_half_frame"]=59039,["_monosh_combat_init"]=2103,["_monosh_combat_reflect_bullet"]=11718,["_monosh_combat_render"]=2256,["_monosh_combat_update"]=2198,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59194,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59043,["_monosh_enemy_active_count"]=3019,["_monosh_enemy_active_count_value"]=59041,["_monosh_enemy_bullet_count"]=59040,["_monosh_enemy_bullets"]=59123,["_monosh_enemy_camera_delta_cached"]=59192,["_monosh_enemy_collision_cursor"]=59197,["_monosh_enemy_draw_cache_valid"]=59195,["_monosh_enemy_em1_count"]=59193,["_monosh_enemy_em1_phase"]=59168,["_monosh_enemy_em1_shrink"]=59184,["_monosh_enemy_fast_advance"]=56528,["_monosh_enemy_fast_check_player_bullets"]=4109,["_monosh_enemy_fast_render"]=3594,["_monosh_enemy_fast_render_bullets"]=5059,["_monosh_enemy_fast_spawn_due"]=5435,["_monosh_enemy_fast_update_bullets"]=56198,["_monosh_enemy_fire_at"]=3031,["_monosh_enemy_fire_boss_at"]=3060,["_monosh_enemy_fire_em0_fast"]=6494,["_monosh_enemy_frame"]=2822,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59196,["_monosh_enemy_init"]=2673,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59198,["_monosh_enemy_render_only"]=2852,["_monosh_enemy_spawn_index"]=59165,["_monosh_enemy_spawn_wait"]=59166,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3025,["_monosh_enemy_stage_complete_flag"]=59042,["_monosh_ground_depth_pointer"]=61416,["_monosh_ground_offset"]=58363,["_monosh_ground_screen_delta"]=58364,["_monosh_player_bottom"]=59221,["_monosh_player_bullet_count"]=59012,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=58997,["_monosh_player_can_fire"]=9322,["_monosh_player_draw_asset"]=9338,["_monosh_player_draw_flags"]=9280,["_monosh_player_init"]=9217,["_monosh_player_invuln"]=59224,["_monosh_player_pose"]=59226,["_monosh_player_state"]=59223,["_monosh_player_stumble"]=59225,["_monosh_player_update"]=57230,["_monosh_player_update_reference"]=10547,["_monosh_player_world_active"]=9316,["_monosh_player_x"]=59219,["_monosh_project_x"]=24645,["_monosh_reflected_bullet_count"]=59028,["_monosh_reflected_bullets"]=59013,["_monosh_runtime_fire_actions"]=61403,["_monosh_runtime_frame_counter"]=61404,["_monosh_runtime_paused"]=61408,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=59473,["_monosh_stage_collision_bullet_index"]=59474,["_monosh_stage_contact_result"]=59471,["_monosh_stage_draw_cache_valid"]=59472,["_monosh_stage_frame"]=10822,["_monosh_stage_frame_counter"]=59335,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59339,["_monosh_stage_hitbox_count"]=59469,["_monosh_stage_hitboxes"]=59341,["_monosh_stage_init"]=10787,["_monosh_stage_is_clear"]=10871,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59340,["_monosh_stage_need_hitboxes"]=59470,["_monosh_stage_object_count"]=59333,["_monosh_stage_objects"]=59237,["_monosh_stage_render_only"]=10868,["_monosh_stage_spawn_index"]=59334,["_monosh_stage_spawn_wait"]=59337,["_monosh_stage_title_timer"]=59227,["_monosh_title_draw"]=11696,["_monosh_title_visible"]=58365,["_movement_fraction"]=59232,["_old_buttons"]=61414,["_player_flip"]=59235,["_player_fy"]=59228,["_player_run_phase"]=59236,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12074,["addeq0sp"]=61269,["addeqysp"]=61271,["addysp"]=61287,["addysp1"]=61286,["aslax2"]=61300,["aslax3"]=61311,["aslax4"]=61325,["asrax1"]=61342,["asrax2"]=61352,["asrax3"]=61367,["audio4_first_done"]=12543,["audio4_second_done"]=12624,["background_done"]=98722,["booleq"]=61592,["boolge"]=61609,["boolgt"]=61607,["boolle"]=61599,["boollt"]=61601,["boolne"]=61586,["booluge"]=61625,["boolugt"]=61623,["boolule"]=61615,["boolult"]=61617,["bullet_render4"]=99584,["c_sp"]=66,["decsp1"]=61387,["decsp2"]=61396,["decsp3"]=61409,["decsp4"]=61422,["decsp5"]=61435,["dispatch_nonzero"]=98752,["dma_finished"]=12710,["dma_started"]=13149,["fx4_build_skip"]=63177,["fx4_desc_count"]=63189,["fx4_dma_bytes"]=63185,["fx4_generation"]=63183,["fx4_half_bytes"]=63187,["fx4_page"]=63181,["fx4_wait_obj_blank"]=13100,["fx_add_next_bounds"]=59875,["fx_audio_init"]=34141,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=34183,["fx_audio_sent"]=5653,["fx_build_obj"]=24090,["fx_commit_dma"]=59875,["fx_dma_bytes"]=63983,["fx_dma_count"]=63981,["fx_dma_desc"]=63985,["fx_em1_open_sizes"]=60131,["fx_emit_native"]=55390,["fx_is_obj"]=24042,["fx_latch_obj"]=24438,["fx_obj_build_done"]=24436,["fx_obj_count"]=63757,["fx_obj_dma_bytes"]=63763,["fx_obj_next"]=63485,["fx_obj_overflow"]=63761,["fx_obj_present"]=63621,["fx_obj_present_count"]=63759,["fx_obj_upload_done"]=24643,["fx_plan_dma"]=59856,["fx_project16"]=24675,["fx_read_gsu_spans"]=59801,["fx_reset_next_bounds"]=59875,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63197,["fx_upload_ground"]=13676,["fx_upload_obj"]=24484,["game_started"]=12083,["generic"]=99536,["ground_done"]=13629,["ground_empty"]=13770,["gsu_uv_cache"]=99207,["half_dma_finished"]=13198,["incsp1"]=61515,["incsp2"]=61530,["incsp3"]=61544,["incsp4"]=61549,["incsp5"]=61554,["incsp6"]=61559,["incsp7"]=61564,["incsp8"]=61569,["initialized"]=23803,["integer_render4"]=100384,["ldaidx"]=61574,["margin_render"]=99600,["math4_lift_result"]=13289,["memcpy_getparams"]=61671,["memcpy_upwards"]=61633,["mulax10"]=61690,["mulax3"]=61715,["mulax5"]=61732,["mulax6"]=61752,["mulax7"]=61774,["negax"]=61803,["order"]=63229,["packet_done"]=23890,["packet_work"]=14,["player4_present"]=63767,["player4_upload_bytes"]=63771,["popax"]=61522,["popptr1"]=61817,["popsargsudiv16"]=61907,["ptr1"]=74,["ptr2"]=76,["ptr3"]=78,["ptr4"]=80,["push0"]=61853,["pusha"]=61835,["pusha0"]=61855,["pusha0sp"]=61831,["pushax"]=61857,["pushaysp"]=61833,["pushw0sp"]=61879,["pushwysp"]=61881,["regbank"]=86,["regsave"]=70,["render_entry"]=98304,["render_finished"]=12539,["render_second_finished"]=12620,["render_second_started"]=12598,["render_started"]=12514,["render_stop"]=99754,["reset"]=32768,["scaled_render4"]=100112,["scaled_unpacked4"]=100272,["shlax2"]=61300,["shlax3"]=61311,["shlax4"]=61325,["shrax1"]=61939,["shrax3"]=61947,["shrax4"]=61961,["sorted"]=23869,["sreg"]=68,["stage_update_done"]=54852,["staspidx"]=61978,["stax0sp"]=62000,["staxspidx"]=62011,["staxysp"]=62002,["subysp"]=62059,["tmp1"]=82,["tmp2"]=83,["tmp3"]=84,["tmp4"]=85,["tosadda0"]=61241,["tosaddax"]=61243,["tosdiva0"]=61448,["tosdivax"]=61450,["tosicmp"]=61471,["tosicmp0"]=61469,["tossuba0"]=62038,["tossubax"]=62040,["tosudiva0"]=62072,["tosudivax"]=62074,["tosumoda0"]=62151,["tosumodax"]=62153,["udiv16"]=62089,["L1"]=62123,["@L1"]=62141,["Pos"]=61466,["@L3"]=61507,["@L4"]=61508,["@L2"]=62145,["L0"]=62099,["ret0"]=61588,["ret1"]=61594,["L3"]=61660,["done"]=61668,["L2"]=61932,["@L0"]=62130,["udiv16by8a"]=62130}
local output="D:/HomeBrew/MonoSHFX2_4bpp30_20261008/build/game_v001/four_pause"
local maxframe=720
local scenario="pause"
local field=0
local starts,finishes,halves,logic=0,0,0,0
local gsu_start=0
local lastfield=0
local trace=assert(io.open(output..'/trace.jsonl','w'))
local intervals={}
local gsuMax=0
local mathChecks=0
local dma_start_clock=0
local finished=false
local fixture=false
local bossSeen,dyingSeen,doneSeen,restartSeen=false,false,false,false
local function put(name,offset,v)
  emu.write(0x7e0000+assert(labels[name])+offset,v&255,emu.memType.snesMemory)
end
local function word(name,v) put(name,0,v);put(name,1,v>>8) end
local function read(name,n)
  local a=0x7e0000+assert(labels[name],name)
  local v=emu.read(a,emu.memType.snesMemory)
  if n==2 then v=v+256*emu.read(a+1,emu.memType.snesMemory) end
  return v
end
local function dump(name,mem,a,n)
  local f=assert(io.open(output..'/'..name,'wb'));local t={}
  for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
  f:write(table.concat(t));f:close()
end
local function screenshot(name)
  local f=assert(io.open(output..'/'..name..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer()) do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
  f:write(table.concat(t));f:close()
end
local function cb(name,fn)
  local a=0x7f0000+assert(labels[name],name)
  emu.addMemoryCallback(function(...)
    if finished then return end
    local ok,err=pcall(fn,...)
    if not ok then
      local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close()
      trace:flush();emu.log(tostring(err));emu.stop(1)
    end
  end,emu.callbackType.exec,a,a,emu.cpuType.snes,emu.memType.snesMemory)
end
local nextPlayerInput=nil
local presentPlayerInput=nil
local nextBulletAges=nil
local presentBulletAges=nil
local nextEffectPhase=nil
local presentEffectPhase=nil
local objectBuilds=0
if labels.player4_present then
 cb('fx_build_obj',function()
  if scenario=='players' then
   local poses={9,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30}
   local phase=objectBuilds%408;objectBuilds=objectBuilds+1
   local pose=poses[phase%17+1];local flip=(phase//17)%4;local clipping=phase//68
   local centers={128,8,249,128,128,128};local bottoms={150,150,150,35,252,150}
   put('_fx_draw_count',0,1)
   local values={centers[clipping+1]&255,centers[clipping+1]>>8,bottoms[clipping+1]&255,bottoms[clipping+1]>>8,32,48,pose,flip*16+(clipping==5 and 128 or 0),0,2}
   for i,v in ipairs(values) do put('_fx_draw',i-1,v) end
  end
  nextPlayerInput=nil
  local mt=emu.memType.snesMemory;local base=0x7e0000+labels._fx_draw
  for i=0,read('_fx_draw_count',1)-1 do
   local a=base+i*10
   local function byte(o)return emu.read(a+o,mt)end
   local asset=byte(6)
   if byte(9)==2 and byte(4)==32 and byte(5)==48 and (asset==9 or asset>=15 and asset<=30) then
    local x=byte(0)+byte(1)*256;if x>=32768 then x=x-65536 end
    local y=byte(2)+byte(3)*256;if y>=32768 then y=y-65536 end
    local flags=byte(7);local visible=(flags&128)==0 or ((read('_monosh_runtime_frame_counter',2)>>1)&1)==0
    nextPlayerInput=string.format('{"center":%d,"bottom":%d,"asset":%d,"flags":%d,"visible":%s}',x,y,asset,flags,tostring(visible))
   end
  end
 end)
 cb('fx_latch_obj',function()presentPlayerInput=nextPlayerInput;presentBulletAges=nextBulletAges;presentEffectPhase=nextEffectPhase end)
end
if scenario=='effects' then
 local function seedExplosion()
  put('_monosh_enemy_active_count_value',0,1)
  put('_monosh_enemy_bullet_count',0,0)
  local data={1,2,0,48,96,144,40,0,64,48}
  for i,v in ipairs(data)do put('_monosh_enemies',i-1,v)end
 end
 cb('_monosh_enemy_fast_advance',seedExplosion)
 cb('_monosh_enemy_render_only',seedExplosion)
 cb('_fx_enemy_render',function()
  nextEffectPhase=((logic-1)//8)%6
  put('_monosh_enemy_active_count_value',0,1)
  local data={1,2,0,48-nextEffectPhase*8,96,144,40,0,64,48}
  for i,v in ipairs(data)do put('_monosh_enemies',i-1,v)end
 end)
 cb('_monosh_boss_render_only',function()
  for i=0,8 do put('_boss_part_active',i,0)end
  put('_boss_part_active',0,2);put('_boss_part_x',0,192)
  put('_boss_part_bottom',0,144);put('_boss_part_z',0,40)
  put('_boss_part_timer',0,112-(((logic-1)//8)%6)*8)
  put('_boss_render_camera_delta',0,read('_monosh_ground_screen_delta',1))
 end)
end
if scenario=='stage_effects' then
 cb('_fx_stage_render',function()
  nextEffectPhase=((logic-1)//8)%6
  put('_monosh_stage_object_count',0,1)
  local data={0,0,60,2,12,48-nextEffectPhase*8}
  for i,v in ipairs(data)do put('_monosh_stage_objects',i-1,v)end
 end)
end
if scenario=='bullets' then
 cb('_fx_enemy_render_bullets',function()
  put('_monosh_enemy_bullet_count',0,4)
  local ages={}
  for i=0,2 do
   local age=(read('_monosh_runtime_frame_counter',2)+i*11)&63
   ages[#ages+1]=tostring(age)
   local data={1,96+i*32,150,8,0,0,age}
   for j,v in ipairs(data)do put('_monosh_enemy_bullets',i*7+j-1,v)end
  end
  local boss={1,128,90,8,0,0,128}
  for j,v in ipairs(boss)do put('_monosh_enemy_bullets',21+j-1,v)end
  nextBulletAges='['..table.concat(ages,',')..']'
  put('_monosh_player_invuln',0,255)
 end)
end
cb('math4_lift_result',function()
  local mt=emu.memType.snesMemory
  local z=emu.read(0x7e0380,mt);local world=emu.read(0x7e0381,mt)
  local scale=emu.read(0x7e0000+labels._monosh_boss_explosion_scale_low+z,mt)+(z<13 and 256 or 0)
  assert((emu.getState()['cpu.a']&65535)==((world*scale)//256)*2,'explosion lift differs from original arithmetic')
  mathChecks=mathChecks+1
end)
cb('_fx_frame',function()
  logic=logic+1
  if scenario=='stage_effects' then
    put('_monosh_boss_state',0,0);put('_monosh_player_invuln',0,255)
    put('_monosh_enemy_stage_complete_flag',0,0)
  end
  if scenario=='effects' then
    put('_monosh_boss_state',0,1);put('_monosh_player_invuln',0,255)
    -- 敵描画の呼び出し自体がactive_countで省略されないよう、更新前にも枠を置く。
    put('_monosh_enemy_active_count_value',0,1)
    put('_monosh_enemies',0,1);put('_monosh_enemies',1,2);put('_monosh_enemies',3,0)
    put('_monosh_enemy_bullet_count',0,0)
  end
  if scenario=='bullets' then
    put('_monosh_enemy_bullet_count',0,4)
    for i=0,2 do
      local data={1,96+i*32,150,8,0,0,0}
      for j,v in ipairs(data)do put('_monosh_enemy_bullets',i*7+j-1,v)end
    end
    local boss={1,128,90,8,0,0,128}
    for j,v in ipairs(boss)do put('_monosh_enemy_bullets',21+j-1,v)end
    put('_monosh_player_invuln',0,255)
  end
  if scenario=='boss' or scenario=='boss_hold' then
    put('_monosh_player_invuln',0,255)
    if field>=90 and not fixture then
      fixture=true
      put('_monosh_enemy_stage_complete_flag',0,1)
      put('_monosh_enemy_active_count_value',0,0);put('_monosh_enemy_bullet_count',0,0)
      put('_monosh_stage_object_count',0,0)
      put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
      word('_monosh_stage_frame_counter',3900)
    end
    if scenario=='boss' and read('_monosh_boss_state',1)==1 and field>600 then
      local z=read('_boss_part_z',1)
      local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
      if z>=8 and z<=90 then
        put('_monosh_player_bullets',0,1)
        put('_monosh_player_bullets',1,read('_boss_part_x',1))
        put('_monosh_player_bullets',2,read('_boss_part_bottom',1)-height//2)
        put('_monosh_player_bullets',3,math.max(0,z//2-2));put('_monosh_player_bullets',4,3)
        put('_monosh_player_bullet_count',0,1)
      end
    end
  end
  if scenario=='controls' then put('_monosh_player_invuln',0,255) end
  if scenario=='death' and field>=300 and not fixture then
    fixture=true;put('_monosh_player_invuln',0,0);put('_hit_pending',0,1)
  end
end)
cb('render_started',function()
  starts=starts+1;gsu_start=emu.getState().masterClock
  if scenario=='assets' or scenario=='full' then
    -- 全44素材、四つの反転、左右上下のclip。事前縮小にない幅のfallbackも照合する。
    local index=(starts-1)%880
    local asset=index%44;local flip=(index//44)%4;local clipping=index//176
    local widths={37,129,200,32,16};local heights={53,181,215,48,24}
    local centers={128,8,249,128,128};local bottoms={160,100,270,160,160}
    -- 胴・顔の事前縮小経路を通常位置と左上clipでも必ず通す。
    if asset==13 or asset==14 then
      widths[1]=asset==13 and 62 or 69;heights[1]=asset==13 and 41 or 101
      widths[2]=widths[1];heights[2]=heights[1];bottoms[2]=20
    end
    if scenario=='full' then
      asset=13;flip=0;clipping=0;widths[1]=255;heights[1]=184;centers[1]=128;bottoms[1]=212
    end
    local function cart(a,v) emu.write(a,v&255,emu.memType.gsuWorkRam) end
    local function cartword(a,v) cart(a,v);cart(a+1,v>>8) end
    cartword(0,1);cartword(32,centers[clipping+1]);cartword(34,bottoms[clipping+1])
    cart(36,widths[clipping+1]);cart(37,heights[clipping+1]);cart(38,asset);cart(39,flip*16)
    cartword(0x1002,192);cartword(0x1004,1)
    cartword(0x100a,192);cartword(0x100c,1)
  end
  trace:write(string.format('{"startLine":%d,"field":%d}\n',emu.getState()['ppu.scanline'],field))
  if starts%60==0 or starts==1 or scenario=='assets' or scenario=='full' or scenario=='players' or scenario=='bullets' or scenario=='effects' or scenario=='stage_effects' then
    dump(string.format('frame%05d_packet.bin',starts),emu.memType.gsuWorkRam,0,1536)
    dump(string.format('frame%05d_background.bin',starts),emu.memType.gsuWorkRam,0x1000,16)
    dump(string.format('frame%05d_prepared.bin',starts),emu.memType.gsuWorkRam,0x0600,128)
  end
end)
cb('render_second_started',function() gsu_start=emu.getState().masterClock end)
cb('render_second_finished',function()
  trace:write(string.format('{"secondGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end)
cb('render_finished',function()
  local ms=((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272
  gsuMax=math.max(gsuMax,ms)
  trace:write(string.format('{"gsuMs":%.6f,"field":%d,"logic":%d}\n',ms,field,read('_monosh_runtime_frame_counter',2)))
end)
local currentDraw=nil
local profile={}
local function endDraw()
 if currentDraw then
  local elapsed=(emu.getState().masterClock-currentDraw.clock)&0xffffffff
  local key=currentDraw.key;profile[key]=profile[key] or {sum=0,n=0,max=0}
  local a=profile[key];a.sum=a.sum+elapsed;a.n=a.n+1;a.max=math.max(a.max,elapsed);currentDraw=nil
 end
end
if false then
for _,nm in ipairs({'dispatch_nonzero','render_stop','generic','margin_render','scaled_render4','scaled_unpacked4','integer_render4'}) do
  emu.addMemoryCallback(function()
  if finished then return end
  if nm=='dispatch_nonzero' or nm=='render_stop' then endDraw();return end
  local ss=emu.getState();local meta=emu.read(0x0b,emu.memType.gsuWorkRam)
  currentDraw={clock=ss.masterClock,key=nm..'_'..(meta&63)}
 end,emu.callbackType.exec,labels[nm],labels[nm],emu.cpuType.gsu,emu.memType.gsuMemory)
end
end
emu.addMemoryCallback(function()
  if finished then return end
  trace:write(string.format('{"actualGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end,emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
cb('dma_started',function()
  halves=halves+1
  local line=emu.getState()['ppu.scanline']
  assert(line>=203,'DMA started in visible region')
  dma_start_clock=emu.getState().masterClock
  trace:write(string.format('{"dmaStartLine":%d,"field":%d}\n',line,field))
end)
cb('half_dma_finished',function()
  local line=emu.getState()['ppu.scanline']
  assert(line<=22 or line>=203,'DMA exceeded forced blank')
  trace:write(string.format('{"dmaEndLine":%d,"dmaMs":%.6f,"halfBytes":%d,"descriptors":%d,"field":%d}\n',line,((emu.getState().masterClock-dma_start_clock)&0xffffffff)/21477.272,read('fx4_half_bytes',2),read('fx4_desc_count',2),field))
end)
cb('dma_finished',function()
  finishes=finishes+1
  local state=emu.getState()
  local visibleField=field+(state['ppu.scanline']>=203 and 1 or 0)
  local interval=visibleField-lastfield;intervals[interval]=(intervals[interval] or 0)+1;lastfield=visibleField
  assert(state['ppu.scanline']<=22 or state['ppu.scanline']>=203,'4bpp swap missed the blanking boundary')
  local boss=read('_monosh_boss_state',1)
  local paused=read('_monosh_runtime_paused',1)
  if scenario~='pause' then assert(paused==0,'unexpected pause without Start') end
  bossSeen=bossSeen or boss==1;dyingSeen=dyingSeen or boss==2;doneSeen=doneSeen or boss==3
  restartSeen=restartSeen or (doneSeen and boss==0)
  trace:write(string.format('{"present":%d,"field":%d,"interval":%d,"logic":%d,"page":%d,"boss":%d,"line":%d,"paused":%d,"player":%d,"x":%d,"bottom":%d,"shots":%d}\n',finishes,field,interval,read('_monosh_runtime_frame_counter',2),read('fx4_page',2),read('_monosh_boss_state',1),state['ppu.scanline'],paused,read('_monosh_player_state',1),read('_monosh_player_x',2),read('_monosh_player_bottom',2),read('_monosh_player_bullet_count',1)))
  trace:write(string.format('{"dmaBytes":%d,"field":%d}\n',read('fx4_dma_bytes',2),field))
  if finishes%60==0 or scenario=='assets' or scenario=='full' or scenario=='players' or scenario=='bullets' or scenario=='effects' or scenario=='stage_effects' then
    dump(string.format('frame%05d_fb.bin',finishes),emu.memType.gsuWorkRam,0x2000,24576)
    dump(string.format('frame%05d_vram.bin',finishes),emu.memType.snesVideoRam,0,65536)
    dump(string.format('frame%05d_bounds.bin',finishes),emu.memType.gsuWorkRam,0x580,64)
    dump(string.format('frame%05d_dma.bin',finishes),emu.memType.gsuWorkRam,0x1100,100)
    if labels.player4_present then
      dump(string.format('frame%05d_oam.bin',finishes),emu.memType.snesSpriteRam,0,544)
      dump(string.format('frame%05d_cgram.bin',finishes),emu.memType.snesCgRam,0,512)
      dump(string.format('frame%05d_obj.bin',finishes),emu.memType.snesMemory,0x7e0000+labels.fx_obj_present,136)
    end
    local f=assert(io.open(output..string.format('/frame%05d_meta.json',finishes),'w'))
    f:write(string.format('{"page":%d,"field":%d,"playerObjSource":%d,"playerInput":%s,"bulletAges":%s,"effectPhase":%s}',read('fx4_page',2),field,labels.player4_present and read('player4_present',2) or 0,presentPlayerInput or 'null',presentBulletAges or 'null',presentEffectPhase and tostring(presentEffectPhase) or 'null'));f:close()
  end
end)
emu.addEventCallback(function()
  local input={a=scenario~='boss_hold' and scenario~='boss' and scenario~='effects' and scenario~='stage_effects'}
  if scenario=='controls' then
    local phase=(field//240)%4
    input.up=phase==0;input.right=phase==1;input.down=phase==2;input.left=phase==3
  end
  if scenario=='pause' then input.start=(field>=151 and field<=154) or (field>=211 and field<=214) end
  if scenario=='play' and read('_monosh_boss_state',1)==1 then
    local z=read('_boss_part_z',1)
    local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
    local tx=read('_boss_part_x',1);local ty=read('_boss_part_bottom',1)-height//2+20
    local x=read('_monosh_player_x',2);local y=read('_monosh_player_bottom',2)
    input.right=x<tx-3;input.left=x>tx+3;input.up=y>ty+3;input.down=y<ty-3
  end
  emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
  field=field+1
  if (scenario=='bullets' or scenario=='effects' or scenario=='stage_effects') and field%2==0 then screenshot(string.format('anim%05d',field)) end
  if field%240==0 then screenshot(string.format('screen%05d',field)) end
  if field>=maxframe then
    finished=true
    for k,v in pairs(profile) do trace:write(string.format('{"profile":"%s","n":%d,"sumMs":%.3f,"maxMs":%.3f}\n',k,v.n,v.sum/21477.272,v.max/21477.272)) end
    local sf=assert(io.open(output.."/state.txt","w")); for k,v in pairs(emu.getState()) do sf:write(tostring(k).."="..tostring(v).."\n") end;sf:close()
    trace:write(string.format('{"mathChecks":%d}\n',mathChecks))
    trace:close()
    local f=assert(io.open(output..'/summary.json','w'))
    local ii={};for k,v in pairs(intervals) do ii[#ii+1]=string.format('"%d":%d',k,v) end
    f:write(string.format('{"fields":%d,"renders":%d,"starts":%d,"halves":%d,"logicCalls":%d,"logic":%d,"gsuMaxMs":%.6f,"intervals":{%s},"bossSeen":%s,"dyingSeen":%s,"doneSeen":%s,"restartSeen":%s}',field,finishes,starts,halves,logic,read('_monosh_runtime_frame_counter',2),gsuMax,table.concat(ii,','),tostring(bossSeen),tostring(dyingSeen),tostring(doneSeen),tostring(restartSeen)));f:close();emu.stop(0)
  end
end,emu.eventType.startFrame)
