local labels={["__BSS_LOAD__"]=59048,["__BSS_RUN__"]=59048,["__BSS_SIZE__"]=5759,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62681,["__DATA_LOAD__"]=4376229,["__DATA_RUN__"]=59045,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50853,["__STARTUP__"]=1,["_abs"]=62312,["_boss_age"]=59663,["_boss_attribute_cache"]=59498,["_boss_attribute_cache_count"]=59660,["_boss_attribute_z_cache"]=59642,["_boss_dda_phase"]=59881,["_boss_dda_x"]=59887,["_boss_dda_y"]=59893,["_boss_death_parts"]=59665,["_boss_death_timer"]=59664,["_boss_fire_gap"]=59674,["_boss_fire_round"]=59671,["_boss_fire_shots"]=59673,["_boss_fire_state"]=59670,["_boss_fire_volley"]=59672,["_boss_history_x"]=59114,["_boss_history_y"]=59242,["_boss_history_z"]=59370,["_boss_last_vblank"]=59050,["_boss_motion_steps"]=59669,["_boss_part_active"]=59078,["_boss_part_bottom"]=59060,["_boss_part_fall_fraction"]=59105,["_boss_part_fall_velocity"]=59096,["_boss_part_timer"]=59087,["_boss_part_x"]=59051,["_boss_part_z"]=59069,["_boss_path_half"]=59668,["_boss_player_bottom"]=59677,["_boss_player_x"]=59675,["_boss_render_camera_delta"]=59661,["_boss_restart_timer"]=59666,["_boss_z_phase"]=59667,["_death_accel_fraction"]=59915,["_death_timer"]=59913,["_death_vy"]=59912,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx4_explosion_lift"]=13148,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_boss_hits"]=59539,["_fx_boss_project"]=59344,["_fx_build_ground"]=13234,["_fx_build_packet"]=23671,["_fx_buttons"]=62081,["_fx_draw"]=60157,["_fx_draw_count"]=60797,["_fx_em0_geometry"]=56581,["_fx_enemy_collisions"]=56056,["_fx_enemy_em1_update"]=57457,["_fx_enemy_em1_update_reference"]=7564,["_fx_enemy_fire_em1"]=7502,["_fx_enemy_remove"]=7491,["_fx_enemy_render"]=55426,["_fx_enemy_render_bullets"]=55705,["_fx_far_d_acc"]=62093,["_fx_far_u_acc"]=62091,["_fx_fire_actions"]=62084,["_fx_frame"]=58361,["_fx_ground_c1ptr"]=63849,["_fx_ground_c3ptr"]=63851,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62100,["_fx_ground_color3"]=62550,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63815,["_fx_ground_far_xptr"]=63845,["_fx_ground_far_y"]=63855,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63853,["_fx_ground_horizontal"]=63000,["_fx_ground_hptr"]=63810,["_fx_ground_native"]=13319,["_fx_ground_palette_record"]=63813,["_fx_ground_phase"]=62080,["_fx_ground_vptr"]=63847,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63812,["_fx_init"]=11670,["_fx_input"]=62083,["_fx_open_size"]=60601,["_fx_packet"]=60800,["_fx_packet_count"]=60798,["_fx_present"]=12406,["_fx_read_input"]=12142,["_fx_send_ground"]=12202,["_fx_sky_color"]=39095,["_fx_stage_contact"]=54742,["_fx_stage_render"]=54043,["_fx_stage_update"]=55073,["_fx_submit"]=60389,["_ground_irq_vblank_count"]=62088,["_history_head"]=59662,["_hit_pending"]=62095,["_intro_timer"]=59916,["_legacy_enemy_fire_boss_at"]=6096,["_main"]=11707,["_memcpy"]=62143,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59049,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2077,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=59124,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59048,["_monosh_bullet_reflect_rng"]=59719,["_monosh_collision_bullet_bands"]=59711,["_monosh_combat_build_collision_bands"]=2259,["_monosh_combat_fast_cache_reset"]=12068,["_monosh_combat_fast_frame"]=59893,["_monosh_combat_fast_render"]=60015,["_monosh_combat_fast_render_cached"]=12075,["_monosh_combat_fire_cooldown"]=59720,["_monosh_combat_half_frame"]=59721,["_monosh_combat_init"]=2103,["_monosh_combat_reflect_bullet"]=11718,["_monosh_combat_render"]=2256,["_monosh_combat_update"]=2198,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59876,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59725,["_monosh_enemy_active_count"]=3019,["_monosh_enemy_active_count_value"]=59723,["_monosh_enemy_bullet_count"]=59722,["_monosh_enemy_bullets"]=59805,["_monosh_enemy_camera_delta_cached"]=59874,["_monosh_enemy_collision_cursor"]=59879,["_monosh_enemy_draw_cache_valid"]=59877,["_monosh_enemy_em1_count"]=59875,["_monosh_enemy_em1_phase"]=59850,["_monosh_enemy_em1_shrink"]=59866,["_monosh_enemy_fast_advance"]=57049,["_monosh_enemy_fast_check_player_bullets"]=4109,["_monosh_enemy_fast_render"]=3594,["_monosh_enemy_fast_render_bullets"]=5059,["_monosh_enemy_fast_spawn_due"]=5435,["_monosh_enemy_fast_update_bullets"]=56719,["_monosh_enemy_fire_at"]=3031,["_monosh_enemy_fire_boss_at"]=3060,["_monosh_enemy_fire_em0_fast"]=6494,["_monosh_enemy_frame"]=2822,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59878,["_monosh_enemy_init"]=2673,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59880,["_monosh_enemy_render_only"]=2852,["_monosh_enemy_spawn_index"]=59847,["_monosh_enemy_spawn_wait"]=59848,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3025,["_monosh_enemy_stage_complete_flag"]=59724,["_monosh_ground_depth_pointer"]=62098,["_monosh_ground_offset"]=59045,["_monosh_ground_screen_delta"]=59046,["_monosh_player_bottom"]=59903,["_monosh_player_bullet_count"]=59694,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59679,["_monosh_player_can_fire"]=9322,["_monosh_player_draw_asset"]=9338,["_monosh_player_draw_flags"]=9280,["_monosh_player_init"]=9217,["_monosh_player_invuln"]=59906,["_monosh_player_pose"]=59908,["_monosh_player_state"]=59905,["_monosh_player_stumble"]=59907,["_monosh_player_update"]=57751,["_monosh_player_update_reference"]=10547,["_monosh_player_world_active"]=9316,["_monosh_player_x"]=59901,["_monosh_project_x"]=25220,["_monosh_reflected_bullet_count"]=59710,["_monosh_reflected_bullets"]=59695,["_monosh_runtime_fire_actions"]=62085,["_monosh_runtime_frame_counter"]=62086,["_monosh_runtime_paused"]=62090,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60155,["_monosh_stage_collision_bullet_index"]=60156,["_monosh_stage_contact_result"]=60153,["_monosh_stage_draw_cache_valid"]=60154,["_monosh_stage_frame"]=10822,["_monosh_stage_frame_counter"]=60017,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=60021,["_monosh_stage_hitbox_count"]=60151,["_monosh_stage_hitboxes"]=60023,["_monosh_stage_init"]=10787,["_monosh_stage_is_clear"]=10871,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=60022,["_monosh_stage_need_hitboxes"]=60152,["_monosh_stage_object_count"]=60015,["_monosh_stage_objects"]=59919,["_monosh_stage_render_only"]=10868,["_monosh_stage_spawn_index"]=60016,["_monosh_stage_spawn_wait"]=60019,["_monosh_stage_title_timer"]=59909,["_monosh_title_draw"]=11696,["_monosh_title_visible"]=59047,["_movement_fraction"]=59914,["_old_buttons"]=62096,["_player_flip"]=59917,["_player_fy"]=59910,["_player_run_phase"]=59918,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12069,["addeq0sp"]=61782,["addeqysp"]=61784,["addysp"]=61800,["addysp1"]=61799,["aslax2"]=61813,["aslax3"]=61824,["aslax4"]=61838,["asrax1"]=61855,["asrax2"]=61865,["asrax3"]=61880,["background_done"]=98722,["booleq"]=62105,["boolge"]=62122,["boolgt"]=62120,["boolle"]=62112,["boollt"]=62114,["boolne"]=62099,["booluge"]=62138,["boolugt"]=62136,["boolule"]=62128,["boolult"]=62130,["c_sp"]=72,["decsp1"]=61900,["decsp2"]=61909,["decsp3"]=61922,["decsp4"]=61935,["decsp5"]=61948,["dispatch_nonzero"]=98752,["dma_finished"]=12691,["dma_started"]=13085,["fx4_build_skip"]=63859,["fx4_desc_count"]=63871,["fx4_dma_bytes"]=63867,["fx4_generation"]=63865,["fx4_half_bytes"]=63869,["fx4_page"]=63863,["fx_add_next_bounds"]=60388,["fx_build_obj"]=24004,["fx_commit_dma"]=60388,["fx_dma_bytes"]=64677,["fx_dma_count"]=64675,["fx_dma_desc"]=64679,["fx_em1_open_sizes"]=60644,["fx_emit_native"]=55919,["fx_is_obj"]=23915,["fx_latch_obj"]=25067,["fx_obj_build_done"]=24638,["fx_obj_count"]=64439,["fx_obj_dma_bytes"]=64479,["fx_obj_next"]=64167,["fx_obj_overflow"]=64443,["fx_obj_present"]=64303,["fx_obj_present_count"]=64441,["fx_obj_upload_done"]=25210,["fx_plan_dma"]=60369,["fx_project16"]=25250,["fx_read_gsu_spans"]=60314,["fx_reset_next_bounds"]=60388,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63879,["fx_upload_ground"]=13612,["fx_upload_obj"]=25091,["game_started"]=12078,["generic"]=99408,["ground_done"]=13565,["ground_empty"]=13706,["gsu_uv_cache"]=99120,["half_dma_finished"]=13134,["incsp1"]=62028,["incsp2"]=62043,["incsp3"]=62057,["incsp4"]=62062,["incsp5"]=62067,["incsp6"]=62072,["incsp7"]=62077,["incsp8"]=62082,["initialized"]=23739,["integer_render4"]=100192,["ldaidx"]=62087,["margin_render"]=99456,["math4_lift_result"]=13225,["memcpy_getparams"]=62184,["memcpy_upwards"]=62146,["mulax10"]=62203,["mulax3"]=62228,["mulax5"]=62245,["mulax6"]=62265,["mulax7"]=62287,["negax"]=62316,["order"]=63911,["packet_done"]=23826,["packet_work"]=12,["popax"]=62035,["popptr1"]=62330,["popsargsudiv16"]=62420,["ptr1"]=80,["ptr2"]=82,["ptr3"]=84,["ptr4"]=86,["push0"]=62366,["pusha"]=62348,["pusha0"]=62368,["pusha0sp"]=62344,["pushax"]=62370,["pushaysp"]=62346,["pushw0sp"]=62392,["pushwysp"]=62394,["regbank"]=92,["regsave"]=76,["render_entry"]=98304,["render_finished"]=12531,["render_second_finished"]=12608,["render_second_started"]=12586,["render_started"]=12506,["render_stop"]=99610,["reset"]=32768,["scaled_render4"]=99920,["scaled_unpacked4"]=100080,["shlax2"]=61813,["shlax3"]=61824,["shlax4"]=61838,["shrax1"]=62452,["shrax3"]=62460,["shrax4"]=62474,["sorted"]=23805,["sreg"]=74,["stage_update_done"]=55424,["staspidx"]=62491,["stax0sp"]=62513,["staxspidx"]=62524,["staxysp"]=62515,["subysp"]=62572,["tmp1"]=88,["tmp2"]=89,["tmp3"]=90,["tmp4"]=91,["tosadda0"]=61754,["tosaddax"]=61756,["tosdiva0"]=61961,["tosdivax"]=61963,["tosicmp"]=61984,["tosicmp0"]=61982,["tossuba0"]=62551,["tossubax"]=62553,["tosudiva0"]=62585,["tosudivax"]=62587,["tosumoda0"]=62664,["tosumodax"]=62666,["udiv16"]=62602,["L1"]=62636,["@L1"]=62654,["Pos"]=61979,["@L3"]=62020,["@L4"]=62021,["@L2"]=62658,["L0"]=62612,["ret0"]=62101,["ret1"]=62107,["L3"]=62173,["done"]=62181,["L2"]=62445,["@L0"]=62643,["udiv16by8a"]=62643}
local output="D:/HomeBrew/MonoSHFX2_4bpp30_20261008/build/game_v001/four_boss"
local maxframe=2600
local scenario="boss"
local field=0
local starts,finishes,halves,logic=0,0,0,0
local gsu_start=0
local lastfield=0
local trace=assert(io.open(output..'/trace.jsonl','w'))
local intervals={}
local gsuMax=0
local mathChecks=0
local dma_start_clock=0
local finished=false
local fixture=false
local bossSeen,dyingSeen,doneSeen,restartSeen=false,false,false,false
local function put(name,offset,v)
  emu.write(0x7e0000+assert(labels[name])+offset,v&255,emu.memType.snesMemory)
end
local function word(name,v) put(name,0,v);put(name,1,v>>8) end
local function read(name,n)
  local a=0x7e0000+assert(labels[name],name)
  local v=emu.read(a,emu.memType.snesMemory)
  if n==2 then v=v+256*emu.read(a+1,emu.memType.snesMemory) end
  return v
end
local function dump(name,mem,a,n)
  local f=assert(io.open(output..'/'..name,'wb'));local t={}
  for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
  f:write(table.concat(t));f:close()
end
local function screenshot(name)
  local f=assert(io.open(output..'/'..name..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer()) do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
  f:write(table.concat(t));f:close()
end
local function cb(name,fn)
  local a=0x7f0000+assert(labels[name],name)
  emu.addMemoryCallback(function(...)
    if finished then return end
    local ok,err=pcall(fn,...)
    if not ok then
      local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close()
      trace:flush();emu.log(tostring(err));emu.stop(1)
    end
  end,emu.callbackType.exec,a,a,emu.cpuType.snes,emu.memType.snesMemory)
end
cb('math4_lift_result',function()
  local mt=emu.memType.snesMemory
  local z=emu.read(0x7e0380,mt);local world=emu.read(0x7e0381,mt)
  local scale=emu.read(0x7e0000+labels._monosh_boss_explosion_scale_low+z,mt)+(z<13 and 256 or 0)
  assert((emu.getState()['cpu.a']&65535)==((world*scale)//256)*2,'explosion lift differs from original arithmetic')
  mathChecks=mathChecks+1
end)
cb('_fx_frame',function()
  logic=logic+1
  if scenario=='boss' or scenario=='boss_hold' then
    put('_monosh_player_invuln',0,255)
    if field>=90 and not fixture then
      fixture=true
      put('_monosh_enemy_stage_complete_flag',0,1)
      put('_monosh_enemy_active_count_value',0,0);put('_monosh_enemy_bullet_count',0,0)
      put('_monosh_stage_object_count',0,0)
      put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
      word('_monosh_stage_frame_counter',3900)
    end
    if scenario=='boss' and read('_monosh_boss_state',1)==1 and field>600 then
      local z=read('_boss_part_z',1)
      local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
      if z>=8 and z<=90 then
        put('_monosh_player_bullets',0,1)
        put('_monosh_player_bullets',1,read('_boss_part_x',1))
        put('_monosh_player_bullets',2,read('_boss_part_bottom',1)-height//2)
        put('_monosh_player_bullets',3,math.max(0,z//2-2));put('_monosh_player_bullets',4,3)
        put('_monosh_player_bullet_count',0,1)
      end
    end
  end
  if scenario=='controls' then put('_monosh_player_invuln',0,255) end
  if scenario=='death' and field>=300 and not fixture then
    fixture=true;put('_monosh_player_invuln',0,0);put('_hit_pending',0,1)
  end
end)
cb('render_started',function()
  starts=starts+1;gsu_start=emu.getState().masterClock
  if scenario=='assets' or scenario=='full' then
    -- 全44素材、四つの反転、左右上下のclip。事前縮小にない幅のfallbackも照合する。
    local index=(starts-1)%880
    local asset=index%44;local flip=(index//44)%4;local clipping=index//176
    local widths={37,129,200,32,16};local heights={53,181,215,48,24}
    local centers={128,8,249,128,128};local bottoms={160,100,270,160,160}
    -- 胴・顔の事前縮小経路を通常位置と左上clipでも必ず通す。
    if asset==13 or asset==14 then
      widths[1]=asset==13 and 62 or 69;heights[1]=asset==13 and 41 or 101
      widths[2]=widths[1];heights[2]=heights[1];bottoms[2]=20
    end
    if scenario=='full' then
      asset=13;flip=0;clipping=0;widths[1]=255;heights[1]=184;centers[1]=128;bottoms[1]=212
    end
    local function cart(a,v) emu.write(a,v&255,emu.memType.gsuWorkRam) end
    local function cartword(a,v) cart(a,v);cart(a+1,v>>8) end
    cartword(0,1);cartword(32,centers[clipping+1]);cartword(34,bottoms[clipping+1])
    cart(36,widths[clipping+1]);cart(37,heights[clipping+1]);cart(38,asset);cart(39,flip*16)
    cartword(0x1002,192);cartword(0x1004,1)
    cartword(0x100a,192);cartword(0x100c,1)
  end
  trace:write(string.format('{"startLine":%d,"field":%d}\n',emu.getState()['ppu.scanline'],field))
  if starts%60==0 or starts==1 or scenario=='assets' or scenario=='full' then
    dump(string.format('frame%05d_packet.bin',starts),emu.memType.gsuWorkRam,0,1536)
    dump(string.format('frame%05d_background.bin',starts),emu.memType.gsuWorkRam,0x1000,16)
    dump(string.format('frame%05d_prepared.bin',starts),emu.memType.gsuWorkRam,0x0600,128)
  end
end)
cb('render_second_started',function() gsu_start=emu.getState().masterClock end)
cb('render_second_finished',function()
  trace:write(string.format('{"secondGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end)
cb('render_finished',function()
  local ms=((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272
  gsuMax=math.max(gsuMax,ms)
  trace:write(string.format('{"gsuMs":%.6f,"field":%d,"logic":%d}\n',ms,field,read('_monosh_runtime_frame_counter',2)))
end)
local currentDraw=nil
local profile={}
local function endDraw()
 if currentDraw then
  local elapsed=(emu.getState().masterClock-currentDraw.clock)&0xffffffff
  local key=currentDraw.key;profile[key]=profile[key] or {sum=0,n=0,max=0}
  local a=profile[key];a.sum=a.sum+elapsed;a.n=a.n+1;a.max=math.max(a.max,elapsed);currentDraw=nil
 end
end
if false then
for _,nm in ipairs({'dispatch_nonzero','render_stop','generic','margin_render','scaled_render4','scaled_unpacked4','integer_render4'}) do
  emu.addMemoryCallback(function()
  if finished then return end
  if nm=='dispatch_nonzero' or nm=='render_stop' then endDraw();return end
  local ss=emu.getState();local meta=emu.read(0x0b,emu.memType.gsuWorkRam)
  if nm=='scaled_unpacked4' and field>=140 and field<144 then
    trace:write(string.format('{"uvDebug":%d,"x":%d,"y":%d,"dv":%d,"v":%d,"h":%d,"flag":%d,"bank":%d}\n',meta&63,ss['cart.coprocessor.r5'],ss['cart.coprocessor.r2'],ss['cart.coprocessor.r4'],ss['cart.coprocessor.r7'],ss['cart.coprocessor.r6'],ss['cart.coprocessor.r3'],ss['cart.coprocessor.romBank']))
  end
  currentDraw={clock=ss.masterClock,key=nm..'_'..(meta&63)}
 end,emu.callbackType.exec,labels[nm],labels[nm],emu.cpuType.gsu,emu.memType.gsuMemory)
end
end
emu.addMemoryCallback(function()
  if finished then return end
  trace:write(string.format('{"actualGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end,emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
cb('dma_started',function()
  halves=halves+1
  local line=emu.getState()['ppu.scanline']
  assert(line>=203,'DMA started in visible region')
  dma_start_clock=emu.getState().masterClock
  trace:write(string.format('{"dmaStartLine":%d,"field":%d}\n',line,field))
end)
cb('half_dma_finished',function()
  local line=emu.getState()['ppu.scanline']
  assert(line<=22 or line>=203,'DMA exceeded forced blank')
  trace:write(string.format('{"dmaEndLine":%d,"dmaMs":%.6f,"halfBytes":%d,"descriptors":%d,"field":%d}\n',line,((emu.getState().masterClock-dma_start_clock)&0xffffffff)/21477.272,read('fx4_half_bytes',2),read('fx4_desc_count',2),field))
end)
cb('dma_finished',function()
  finishes=finishes+1
  local state=emu.getState()
  local visibleField=field+(state['ppu.scanline']>=203 and 1 or 0)
  local interval=visibleField-lastfield;intervals[interval]=(intervals[interval] or 0)+1;lastfield=visibleField
  assert(state['ppu.scanline']<=22 or state['ppu.scanline']>=203,'4bpp swap missed the blanking boundary')
  local boss=read('_monosh_boss_state',1)
  local paused=read('_monosh_runtime_paused',1)
  if scenario~='pause' then assert(paused==0,'unexpected pause without Start') end
  bossSeen=bossSeen or boss==1;dyingSeen=dyingSeen or boss==2;doneSeen=doneSeen or boss==3
  restartSeen=restartSeen or (doneSeen and boss==0)
  trace:write(string.format('{"present":%d,"field":%d,"interval":%d,"logic":%d,"page":%d,"boss":%d,"line":%d,"paused":%d,"player":%d,"x":%d,"bottom":%d,"shots":%d}\n',finishes,field,interval,read('_monosh_runtime_frame_counter',2),read('fx4_page',2),read('_monosh_boss_state',1),state['ppu.scanline'],paused,read('_monosh_player_state',1),read('_monosh_player_x',2),read('_monosh_player_bottom',2),read('_monosh_player_bullet_count',1)))
  trace:write(string.format('{"dmaBytes":%d,"field":%d}\n',read('fx4_dma_bytes',2),field))
  if finishes%60==0 or scenario=='assets' or scenario=='full' then
    dump(string.format('frame%05d_fb.bin',finishes),emu.memType.gsuWorkRam,0x2000,24576)
    dump(string.format('frame%05d_vram.bin',finishes),emu.memType.snesVideoRam,0,65536)
    dump(string.format('frame%05d_bounds.bin',finishes),emu.memType.gsuWorkRam,0x580,64)
    dump(string.format('frame%05d_dma.bin',finishes),emu.memType.gsuWorkRam,0x1100,100)
    local f=assert(io.open(output..string.format('/frame%05d_meta.json',finishes),'w'))
    f:write(string.format('{"page":%d,"field":%d}',read('fx4_page',2),field));f:close()
  end
end)
emu.addEventCallback(function()
  local input={a=scenario~='boss_hold' and scenario~='boss'}
  if scenario=='controls' then
    local phase=(field//240)%4
    input.up=phase==0;input.right=phase==1;input.down=phase==2;input.left=phase==3
  end
  if scenario=='pause' then input.start=(field>=151 and field<=154) or (field>=211 and field<=214) end
  if scenario=='play' and read('_monosh_boss_state',1)==1 then
    local z=read('_boss_part_z',1)
    local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
    local tx=read('_boss_part_x',1);local ty=read('_boss_part_bottom',1)-height//2+20
    local x=read('_monosh_player_x',2);local y=read('_monosh_player_bottom',2)
    input.right=x<tx-3;input.left=x>tx+3;input.up=y>ty+3;input.down=y<ty-3
  end
  emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
  field=field+1
  if field%240==0 then screenshot(string.format('screen%05d',field)) end
  if field>=maxframe then
    finished=true
    for k,v in pairs(profile) do trace:write(string.format('{"profile":"%s","n":%d,"sumMs":%.3f,"maxMs":%.3f}\n',k,v.n,v.sum/21477.272,v.max/21477.272)) end
    local sf=assert(io.open(output.."/state.txt","w")); for k,v in pairs(emu.getState()) do sf:write(tostring(k).."="..tostring(v).."\n") end;sf:close()
    trace:write(string.format('{"mathChecks":%d}\n',mathChecks))
    trace:close()
    local f=assert(io.open(output..'/summary.json','w'))
    local ii={};for k,v in pairs(intervals) do ii[#ii+1]=string.format('"%d":%d',k,v) end
    f:write(string.format('{"fields":%d,"renders":%d,"starts":%d,"halves":%d,"logicCalls":%d,"logic":%d,"gsuMaxMs":%.6f,"intervals":{%s},"bossSeen":%s,"dyingSeen":%s,"doneSeen":%s,"restartSeen":%s}',field,finishes,starts,halves,logic,read('_monosh_runtime_frame_counter',2),gsuMax,table.concat(ii,','),tostring(bossSeen),tostring(dyingSeen),tostring(doneSeen),tostring(restartSeen)));f:close();emu.stop(0)
  end
end,emu.eventType.startFrame)
