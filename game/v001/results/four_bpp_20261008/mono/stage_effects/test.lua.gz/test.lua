local labels={["LoadAudioData"]=34385,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=5837684,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=33955,["Tad_GetSong"]=34059,["Tad_GlobalVolumesPersist"]=34087,["Tad_GlobalVolumesResetOnSongStart"]=34081,["Tad_Init"]=33571,["Tad_IsLoaderActive"]=34113,["Tad_IsSfxPlaying"]=34127,["Tad_IsSongLoaded"]=34121,["Tad_IsSongPlaying"]=34133,["Tad_LoadSong"]=34014,["Tad_LoadSongIfChanged"]=34047,["Tad_Loader_Bin"]=5837568,["Tad_Loader_SIZE"]=116,["Tad_Process"]=33698,["Tad_QueueCommand"]=33971,["Tad_QueueCommandOverride"]=33976,["Tad_QueuePannedSoundEffect"]=33993,["Tad_QueueSoundEffect"]=34003,["Tad_ReloadCommonAudioData"]=34063,["Tad_SetTransferSize"]=34093,["Tad_SongsStartImmediately"]=34069,["Tad_SongsStartPaused"]=34075,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=1,["Tad_sfxQueue_sfx"]=0,["__BSS_LOAD__"]=59048,["__BSS_RUN__"]=59048,["__BSS_SIZE__"]=5761,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=62807,["__DATA_LOAD__"]=4376229,["__DATA_RUN__"]=59045,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50853,["__STARTUP__"]=1,["_abs"]=62438,["_boss_age"]=59663,["_boss_attribute_cache"]=59498,["_boss_attribute_cache_count"]=59660,["_boss_attribute_z_cache"]=59642,["_boss_dda_phase"]=59881,["_boss_dda_x"]=59887,["_boss_dda_y"]=59893,["_boss_death_parts"]=59665,["_boss_death_timer"]=59664,["_boss_fire_gap"]=59674,["_boss_fire_round"]=59671,["_boss_fire_shots"]=59673,["_boss_fire_state"]=59670,["_boss_fire_volley"]=59672,["_boss_history_x"]=59114,["_boss_history_y"]=59242,["_boss_history_z"]=59370,["_boss_last_vblank"]=59050,["_boss_motion_steps"]=59669,["_boss_part_active"]=59078,["_boss_part_bottom"]=59060,["_boss_part_fall_fraction"]=59105,["_boss_part_fall_velocity"]=59096,["_boss_part_timer"]=59087,["_boss_part_x"]=59051,["_boss_part_z"]=59069,["_boss_path_half"]=59668,["_boss_player_bottom"]=59677,["_boss_player_x"]=59675,["_boss_render_camera_delta"]=59661,["_boss_restart_timer"]=59666,["_boss_z_phase"]=59667,["_death_accel_fraction"]=59915,["_death_timer"]=59913,["_death_vy"]=59912,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx4_explosion_lift"]=13161,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_audio_events"]=5648,["_fx_boss_hits"]=59657,["_fx_boss_project"]=59462,["_fx_build_ground"]=13247,["_fx_build_packet"]=23684,["_fx_buttons"]=62081,["_fx_draw"]=60157,["_fx_draw_count"]=60797,["_fx_em0_geometry"]=56699,["_fx_enemy_collisions"]=56166,["_fx_enemy_em1_update"]=57575,["_fx_enemy_em1_update_reference"]=7564,["_fx_enemy_fire_em1"]=7502,["_fx_enemy_remove"]=7491,["_fx_enemy_render"]=55536,["_fx_enemy_render_bullets"]=55815,["_fx_far_d_acc"]=62093,["_fx_far_u_acc"]=62091,["_fx_fire_actions"]=62084,["_fx_frame"]=58479,["_fx_ground_c1ptr"]=63849,["_fx_ground_c3ptr"]=63851,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62100,["_fx_ground_color3"]=62550,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63815,["_fx_ground_far_xptr"]=63845,["_fx_ground_far_y"]=63855,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63853,["_fx_ground_horizontal"]=63000,["_fx_ground_hptr"]=63810,["_fx_ground_native"]=13332,["_fx_ground_palette_record"]=63813,["_fx_ground_phase"]=62080,["_fx_ground_vptr"]=63847,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63812,["_fx_init"]=11670,["_fx_input"]=62083,["_fx_open_size"]=60727,["_fx_packet"]=60800,["_fx_packet_count"]=60798,["_fx_present"]=12411,["_fx_read_input"]=12147,["_fx_send_ground"]=12207,["_fx_sky_color"]=39095,["_fx_stage_contact"]=54852,["_fx_stage_render"]=54142,["_fx_stage_update"]=55183,["_fx_submit"]=60515,["_ground_irq_vblank_count"]=62088,["_history_head"]=59662,["_hit_pending"]=62095,["_intro_timer"]=59916,["_legacy_enemy_fire_boss_at"]=6096,["_main"]=11707,["_memcpy"]=62269,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59049,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2077,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=59242,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59048,["_monosh_bullet_reflect_rng"]=59719,["_monosh_collision_bullet_bands"]=59711,["_monosh_combat_build_collision_bands"]=2259,["_monosh_combat_fast_cache_reset"]=12073,["_monosh_combat_fast_frame"]=60011,["_monosh_combat_fast_render"]=60141,["_monosh_combat_fast_render_cached"]=12080,["_monosh_combat_fire_cooldown"]=59720,["_monosh_combat_half_frame"]=59721,["_monosh_combat_init"]=2103,["_monosh_combat_reflect_bullet"]=11718,["_monosh_combat_render"]=2256,["_monosh_combat_update"]=2198,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59876,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59725,["_monosh_enemy_active_count"]=3019,["_monosh_enemy_active_count_value"]=59723,["_monosh_enemy_bullet_count"]=59722,["_monosh_enemy_bullets"]=59805,["_monosh_enemy_camera_delta_cached"]=59874,["_monosh_enemy_collision_cursor"]=59879,["_monosh_enemy_draw_cache_valid"]=59877,["_monosh_enemy_em1_count"]=59875,["_monosh_enemy_em1_phase"]=59850,["_monosh_enemy_em1_shrink"]=59866,["_monosh_enemy_fast_advance"]=57167,["_monosh_enemy_fast_check_player_bullets"]=4109,["_monosh_enemy_fast_render"]=3594,["_monosh_enemy_fast_render_bullets"]=5059,["_monosh_enemy_fast_spawn_due"]=5435,["_monosh_enemy_fast_update_bullets"]=56837,["_monosh_enemy_fire_at"]=3031,["_monosh_enemy_fire_boss_at"]=3060,["_monosh_enemy_fire_em0_fast"]=6494,["_monosh_enemy_frame"]=2822,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59878,["_monosh_enemy_init"]=2673,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59880,["_monosh_enemy_render_only"]=2852,["_monosh_enemy_spawn_index"]=59847,["_monosh_enemy_spawn_wait"]=59848,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3025,["_monosh_enemy_stage_complete_flag"]=59724,["_monosh_ground_depth_pointer"]=62098,["_monosh_ground_offset"]=59045,["_monosh_ground_screen_delta"]=59046,["_monosh_player_bottom"]=59903,["_monosh_player_bullet_count"]=59694,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59679,["_monosh_player_can_fire"]=9322,["_monosh_player_draw_asset"]=9338,["_monosh_player_draw_flags"]=9280,["_monosh_player_init"]=9217,["_monosh_player_invuln"]=59906,["_monosh_player_pose"]=59908,["_monosh_player_state"]=59905,["_monosh_player_stumble"]=59907,["_monosh_player_update"]=57869,["_monosh_player_update_reference"]=10547,["_monosh_player_world_active"]=9316,["_monosh_player_x"]=59901,["_monosh_project_x"]=25319,["_monosh_reflected_bullet_count"]=59710,["_monosh_reflected_bullets"]=59695,["_monosh_runtime_fire_actions"]=62085,["_monosh_runtime_frame_counter"]=62086,["_monosh_runtime_paused"]=62090,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60155,["_monosh_stage_collision_bullet_index"]=60156,["_monosh_stage_contact_result"]=60153,["_monosh_stage_draw_cache_valid"]=60154,["_monosh_stage_frame"]=10822,["_monosh_stage_frame_counter"]=60017,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=60021,["_monosh_stage_hitbox_count"]=60151,["_monosh_stage_hitboxes"]=60023,["_monosh_stage_init"]=10787,["_monosh_stage_is_clear"]=10871,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=60022,["_monosh_stage_need_hitboxes"]=60152,["_monosh_stage_object_count"]=60015,["_monosh_stage_objects"]=59919,["_monosh_stage_render_only"]=10868,["_monosh_stage_spawn_index"]=60016,["_monosh_stage_spawn_wait"]=60019,["_monosh_stage_title_timer"]=59909,["_monosh_title_draw"]=11696,["_monosh_title_visible"]=59047,["_movement_fraction"]=59914,["_old_buttons"]=62096,["_player_flip"]=59917,["_player_fy"]=59910,["_player_run_phase"]=59918,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12074,["addeq0sp"]=61908,["addeqysp"]=61910,["addysp"]=61926,["addysp1"]=61925,["aslax2"]=61939,["aslax3"]=61950,["aslax4"]=61964,["asrax1"]=61981,["asrax2"]=61991,["asrax3"]=62006,["audio4_first_done"]=12540,["audio4_second_done"]=12621,["background_done"]=98722,["booleq"]=62231,["boolge"]=62248,["boolgt"]=62246,["boolle"]=62238,["boollt"]=62240,["boolne"]=62225,["booluge"]=62264,["boolugt"]=62262,["boolule"]=62254,["boolult"]=62256,["c_sp"]=74,["decsp1"]=62026,["decsp2"]=62035,["decsp3"]=62048,["decsp4"]=62061,["decsp5"]=62074,["dispatch_nonzero"]=98752,["dma_finished"]=12704,["dma_started"]=13098,["fx4_build_skip"]=63859,["fx4_desc_count"]=63871,["fx4_dma_bytes"]=63867,["fx4_generation"]=63865,["fx4_half_bytes"]=63869,["fx4_page"]=63863,["fx_add_next_bounds"]=60514,["fx_audio_init"]=34139,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=34190,["fx_audio_sent"]=5653,["fx_build_obj"]=24017,["fx_commit_dma"]=60514,["fx_dma_bytes"]=64679,["fx_dma_count"]=64677,["fx_dma_desc"]=64681,["fx_em1_open_sizes"]=60770,["fx_emit_native"]=56029,["fx_is_obj"]=23928,["fx_latch_obj"]=25080,["fx_obj_build_done"]=24651,["fx_obj_count"]=64439,["fx_obj_dma_bytes"]=64479,["fx_obj_next"]=64167,["fx_obj_overflow"]=64443,["fx_obj_present"]=64303,["fx_obj_present_count"]=64441,["fx_obj_upload_done"]=25309,["fx_plan_dma"]=60495,["fx_prepare_obj_dma"]=25187,["fx_project16"]=25349,["fx_read_gsu_spans"]=60440,["fx_reset_next_bounds"]=60514,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63879,["fx_upload_ground"]=13625,["fx_upload_obj"]=25254,["game_started"]=12083,["generic"]=99424,["ground_done"]=13578,["ground_empty"]=13719,["gsu_uv_cache"]=99136,["half_dma_finished"]=13147,["incsp1"]=62154,["incsp2"]=62169,["incsp3"]=62183,["incsp4"]=62188,["incsp5"]=62193,["incsp6"]=62198,["incsp7"]=62203,["incsp8"]=62208,["initialized"]=23752,["integer_render4"]=100208,["ldaidx"]=62213,["margin_render"]=99472,["math4_lift_result"]=13238,["memcpy_getparams"]=62310,["memcpy_upwards"]=62272,["mulax10"]=62329,["mulax3"]=62354,["mulax5"]=62371,["mulax6"]=62391,["mulax7"]=62413,["negax"]=62442,["order"]=63911,["packet_done"]=23839,["packet_work"]=14,["popax"]=62161,["popptr1"]=62456,["popsargsudiv16"]=62546,["ptr1"]=82,["ptr2"]=84,["ptr3"]=86,["ptr4"]=88,["push0"]=62492,["pusha"]=62474,["pusha0"]=62494,["pusha0sp"]=62470,["pushax"]=62496,["pushaysp"]=62472,["pushw0sp"]=62518,["pushwysp"]=62520,["regbank"]=94,["regsave"]=78,["render_entry"]=98304,["render_finished"]=12536,["render_second_finished"]=12617,["render_second_started"]=12595,["render_started"]=12511,["render_stop"]=99626,["reset"]=32768,["scaled_render4"]=99936,["scaled_unpacked4"]=100096,["shlax2"]=61939,["shlax3"]=61950,["shlax4"]=61964,["shrax1"]=62578,["shrax3"]=62586,["shrax4"]=62600,["sorted"]=23818,["sreg"]=76,["stage_update_done"]=55534,["staspidx"]=62617,["stax0sp"]=62639,["staxspidx"]=62650,["staxysp"]=62641,["subysp"]=62698,["tmp1"]=90,["tmp2"]=91,["tmp3"]=92,["tmp4"]=93,["tosadda0"]=61880,["tosaddax"]=61882,["tosdiva0"]=62087,["tosdivax"]=62089,["tosicmp"]=62110,["tosicmp0"]=62108,["tossuba0"]=62677,["tossubax"]=62679,["tosudiva0"]=62711,["tosudivax"]=62713,["tosumoda0"]=62790,["tosumodax"]=62792,["udiv16"]=62728,["L1"]=62762,["@L1"]=62780,["Pos"]=62105,["@L3"]=62146,["@L4"]=62147,["@L2"]=62784,["L0"]=62738,["ret0"]=62227,["ret1"]=62233,["L3"]=62299,["done"]=62307,["L2"]=62571,["@L0"]=62769,["udiv16by8a"]=62769}
local output="D:/AI/Nao_u_BOT/GPT/projects/monosh_fx2/.cache/fx2_4bpp_audio/build/game_v001/four_stage_effects"
local maxframe=480
local scenario="stage_effects"
local field=0
local starts,finishes,halves,logic=0,0,0,0
local gsu_start=0
local lastfield=0
local trace=assert(io.open(output..'/trace.jsonl','w'))
local intervals={}
local gsuMax=0
local mathChecks=0
local dma_start_clock=0
local finished=false
local fixture=false
local bossSeen,dyingSeen,doneSeen,restartSeen=false,false,false,false
local function put(name,offset,v)
  emu.write(0x7e0000+assert(labels[name])+offset,v&255,emu.memType.snesMemory)
end
local function word(name,v) put(name,0,v);put(name,1,v>>8) end
local function read(name,n)
  local a=0x7e0000+assert(labels[name],name)
  local v=emu.read(a,emu.memType.snesMemory)
  if n==2 then v=v+256*emu.read(a+1,emu.memType.snesMemory) end
  return v
end
local function dump(name,mem,a,n)
  local f=assert(io.open(output..'/'..name,'wb'));local t={}
  for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,mem)) end
  f:write(table.concat(t));f:close()
end
local function screenshot(name)
  local f=assert(io.open(output..'/'..name..'.rgb','wb'));local t={}
  for _,v in ipairs(emu.getScreenBuffer()) do t[#t+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
  f:write(table.concat(t));f:close()
end
local function cb(name,fn)
  local a=0x7f0000+assert(labels[name],name)
  emu.addMemoryCallback(function(...)
    if finished then return end
    local ok,err=pcall(fn,...)
    if not ok then
      local f=assert(io.open(output..'/failure.txt','w'));f:write(tostring(err));f:close()
      trace:flush();emu.log(tostring(err));emu.stop(1)
    end
  end,emu.callbackType.exec,a,a,emu.cpuType.snes,emu.memType.snesMemory)
end
local nextPlayerInput=nil
local presentPlayerInput=nil
local nextBulletAges=nil
local presentBulletAges=nil
local nextEffectPhase=nil
local presentEffectPhase=nil
local objectBuilds=0
if labels.player4_present then
 cb('fx_build_obj',function()
  if scenario=='players' then
   local poses={9,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30}
   local phase=objectBuilds%408;objectBuilds=objectBuilds+1
   local pose=poses[phase%17+1];local flip=(phase//17)%4;local clipping=phase//68
   local centers={128,8,249,128,128,128};local bottoms={150,150,150,35,252,150}
   put('_fx_draw_count',0,1)
   local values={centers[clipping+1]&255,centers[clipping+1]>>8,bottoms[clipping+1]&255,bottoms[clipping+1]>>8,32,48,pose,flip*16+(clipping==5 and 128 or 0),0,2}
   for i,v in ipairs(values) do put('_fx_draw',i-1,v) end
  end
  nextPlayerInput=nil
  local mt=emu.memType.snesMemory;local base=0x7e0000+labels._fx_draw
  for i=0,read('_fx_draw_count',1)-1 do
   local a=base+i*10
   local function byte(o)return emu.read(a+o,mt)end
   local asset=byte(6)
   if byte(9)==2 and byte(4)==32 and byte(5)==48 and (asset==9 or asset>=15 and asset<=30) then
    local x=byte(0)+byte(1)*256;if x>=32768 then x=x-65536 end
    local y=byte(2)+byte(3)*256;if y>=32768 then y=y-65536 end
    local flags=byte(7);local visible=(flags&128)==0 or ((read('_monosh_runtime_frame_counter',2)>>1)&1)==0
    nextPlayerInput=string.format('{"center":%d,"bottom":%d,"asset":%d,"flags":%d,"visible":%s}',x,y,asset,flags,tostring(visible))
   end
  end
 end)
 cb('fx_latch_obj',function()presentPlayerInput=nextPlayerInput;presentBulletAges=nextBulletAges;presentEffectPhase=nextEffectPhase end)
end
if scenario=='effects' then
 local function seedExplosion()
  put('_monosh_enemy_active_count_value',0,1)
  put('_monosh_enemy_bullet_count',0,0)
  local data={1,2,0,48,96,144,40,0,64,48}
  for i,v in ipairs(data)do put('_monosh_enemies',i-1,v)end
 end
 cb('_monosh_enemy_fast_advance',seedExplosion)
 cb('_monosh_enemy_render_only',seedExplosion)
 cb('_fx_enemy_render',function()
  nextEffectPhase=((logic-1)//8)%6
  put('_monosh_enemy_active_count_value',0,1)
  local data={1,2,0,48-nextEffectPhase*8,96,144,40,0,64,48}
  for i,v in ipairs(data)do put('_monosh_enemies',i-1,v)end
 end)
 cb('_monosh_boss_render_only',function()
  for i=0,8 do put('_boss_part_active',i,0)end
  put('_boss_part_active',0,2);put('_boss_part_x',0,192)
  put('_boss_part_bottom',0,144);put('_boss_part_z',0,40)
  put('_boss_part_timer',0,112-(((logic-1)//8)%6)*8)
  put('_boss_render_camera_delta',0,read('_monosh_ground_screen_delta',1))
 end)
end
if scenario=='stage_effects' then
 cb('_fx_stage_render',function()
  nextEffectPhase=((logic-1)//8)%6
  put('_monosh_stage_object_count',0,1)
  local data={0,0,60,2,12,48-nextEffectPhase*8}
  for i,v in ipairs(data)do put('_monosh_stage_objects',i-1,v)end
 end)
end
if scenario=='bullets' then
 cb('_fx_enemy_render_bullets',function()
  put('_monosh_enemy_bullet_count',0,4)
  local ages={}
  for i=0,2 do
   local age=(read('_monosh_runtime_frame_counter',2)+i*11)&63
   ages[#ages+1]=tostring(age)
   local data={1,96+i*32,150,8,0,0,age}
   for j,v in ipairs(data)do put('_monosh_enemy_bullets',i*7+j-1,v)end
  end
  local boss={1,128,90,8,0,0,128}
  for j,v in ipairs(boss)do put('_monosh_enemy_bullets',21+j-1,v)end
  nextBulletAges='['..table.concat(ages,',')..']'
  put('_monosh_player_invuln',0,255)
 end)
end
cb('math4_lift_result',function()
  local mt=emu.memType.snesMemory
  local z=emu.read(0x7e0380,mt);local world=emu.read(0x7e0381,mt)
  local scale=emu.read(0x7e0000+labels._monosh_boss_explosion_scale_low+z,mt)+(z<13 and 256 or 0)
  assert((emu.getState()['cpu.a']&65535)==((world*scale)//256)*2,'explosion lift differs from original arithmetic')
  mathChecks=mathChecks+1
end)
cb('_fx_frame',function()
  logic=logic+1
  if scenario=='stage_effects' then
    put('_monosh_boss_state',0,0);put('_monosh_player_invuln',0,255)
    put('_monosh_enemy_stage_complete_flag',0,0)
  end
  if scenario=='effects' then
    put('_monosh_boss_state',0,1);put('_monosh_player_invuln',0,255)
    -- 敵描画の呼び出し自体がactive_countで省略されないよう、更新前にも枠を置く。
    put('_monosh_enemy_active_count_value',0,1)
    put('_monosh_enemies',0,1);put('_monosh_enemies',1,2);put('_monosh_enemies',3,0)
    put('_monosh_enemy_bullet_count',0,0)
  end
  if scenario=='bullets' then
    put('_monosh_enemy_bullet_count',0,4)
    for i=0,2 do
      local data={1,96+i*32,150,8,0,0,0}
      for j,v in ipairs(data)do put('_monosh_enemy_bullets',i*7+j-1,v)end
    end
    local boss={1,128,90,8,0,0,128}
    for j,v in ipairs(boss)do put('_monosh_enemy_bullets',21+j-1,v)end
    put('_monosh_player_invuln',0,255)
  end
  if scenario=='boss' or scenario=='boss_hold' then
    put('_monosh_player_invuln',0,255)
    if field>=90 and not fixture then
      fixture=true
      put('_monosh_enemy_stage_complete_flag',0,1)
      put('_monosh_enemy_active_count_value',0,0);put('_monosh_enemy_bullet_count',0,0)
      put('_monosh_stage_object_count',0,0)
      put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
      word('_monosh_stage_frame_counter',3900)
    end
    if scenario=='boss' and read('_monosh_boss_state',1)==1 and field>600 then
      local z=read('_boss_part_z',1)
      local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
      if z>=8 and z<=90 then
        put('_monosh_player_bullets',0,1)
        put('_monosh_player_bullets',1,read('_boss_part_x',1))
        put('_monosh_player_bullets',2,read('_boss_part_bottom',1)-height//2)
        put('_monosh_player_bullets',3,math.max(0,z//2-2));put('_monosh_player_bullets',4,3)
        put('_monosh_player_bullet_count',0,1)
      end
    end
  end
  if scenario=='controls' then put('_monosh_player_invuln',0,255) end
  if scenario=='death' and field>=300 and not fixture then
    fixture=true;put('_monosh_player_invuln',0,0);put('_hit_pending',0,1)
  end
end)
cb('render_started',function()
  if not labels.player4_present then presentEffectPhase=nextEffectPhase end
  starts=starts+1;gsu_start=emu.getState().masterClock
  if scenario=='assets' or scenario=='full' then
    -- 全44素材、四つの反転、左右上下のclip。事前縮小にない幅のfallbackも照合する。
    local index=(starts-1)%880
    local asset=index%44;local flip=(index//44)%4;local clipping=index//176
    local widths={37,129,200,32,16};local heights={53,181,215,48,24}
    local centers={128,8,249,128,128};local bottoms={160,100,270,160,160}
    -- 胴・顔の事前縮小経路を通常位置と左上clipでも必ず通す。
    if asset==13 or asset==14 then
      widths[1]=asset==13 and 62 or 69;heights[1]=asset==13 and 41 or 101
      widths[2]=widths[1];heights[2]=heights[1];bottoms[2]=20
    end
    if scenario=='full' then
      asset=13;flip=0;clipping=0;widths[1]=255;heights[1]=184;centers[1]=128;bottoms[1]=212
    end
    local function cart(a,v) emu.write(a,v&255,emu.memType.gsuWorkRam) end
    local function cartword(a,v) cart(a,v);cart(a+1,v>>8) end
    cartword(0,1);cartword(32,centers[clipping+1]);cartword(34,bottoms[clipping+1])
    cart(36,widths[clipping+1]);cart(37,heights[clipping+1]);cart(38,asset);cart(39,flip*16)
    cartword(0x1002,192);cartword(0x1004,1)
    cartword(0x100a,192);cartword(0x100c,1)
  end
  trace:write(string.format('{"startLine":%d,"field":%d}\n',emu.getState()['ppu.scanline'],field))
  if starts%60==0 or starts==1 or scenario=='assets' or scenario=='full' or scenario=='players' or scenario=='bullets' or scenario=='effects' or scenario=='stage_effects' then
    dump(string.format('frame%05d_packet.bin',starts),emu.memType.gsuWorkRam,0,1536)
    dump(string.format('frame%05d_background.bin',starts),emu.memType.gsuWorkRam,0x1000,16)
    dump(string.format('frame%05d_prepared.bin',starts),emu.memType.gsuWorkRam,0x0600,128)
  end
end)
cb('render_second_started',function() gsu_start=emu.getState().masterClock end)
cb('render_second_finished',function()
  trace:write(string.format('{"secondGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end)
cb('render_finished',function()
  local ms=((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272
  gsuMax=math.max(gsuMax,ms)
  trace:write(string.format('{"gsuMs":%.6f,"field":%d,"logic":%d}\n',ms,field,read('_monosh_runtime_frame_counter',2)))
end)
local currentDraw=nil
local profile={}
local function endDraw()
 if currentDraw then
  local elapsed=(emu.getState().masterClock-currentDraw.clock)&0xffffffff
  local key=currentDraw.key;profile[key]=profile[key] or {sum=0,n=0,max=0}
  local a=profile[key];a.sum=a.sum+elapsed;a.n=a.n+1;a.max=math.max(a.max,elapsed);currentDraw=nil
 end
end
if false then
for _,nm in ipairs({'dispatch_nonzero','render_stop','generic','margin_render','scaled_render4','scaled_unpacked4','integer_render4'}) do
  emu.addMemoryCallback(function()
  if finished then return end
  if nm=='dispatch_nonzero' or nm=='render_stop' then endDraw();return end
  local ss=emu.getState();local meta=emu.read(0x0b,emu.memType.gsuWorkRam)
  currentDraw={clock=ss.masterClock,key=nm..'_'..(meta&63)}
 end,emu.callbackType.exec,labels[nm],labels[nm],emu.cpuType.gsu,emu.memType.gsuMemory)
end
end
emu.addMemoryCallback(function()
  if finished then return end
  trace:write(string.format('{"actualGsuMs":%.6f,"field":%d}\n',((emu.getState().masterClock-gsu_start)&0xffffffff)/21477.272,field))
end,emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
cb('dma_started',function()
  halves=halves+1
  local line=emu.getState()['ppu.scanline']
  assert(line>=203,'DMA started in visible region')
  dma_start_clock=emu.getState().masterClock
  trace:write(string.format('{"dmaStartLine":%d,"field":%d}\n',line,field))
end)
cb('half_dma_finished',function()
  local line=emu.getState()['ppu.scanline']
  assert(line<=22 or line>=203,'DMA exceeded forced blank')
  trace:write(string.format('{"dmaEndLine":%d,"dmaMs":%.6f,"halfBytes":%d,"descriptors":%d,"field":%d}\n',line,((emu.getState().masterClock-dma_start_clock)&0xffffffff)/21477.272,read('fx4_half_bytes',2),read('fx4_desc_count',2),field))
end)
cb('dma_finished',function()
  finishes=finishes+1
  local state=emu.getState()
  local visibleField=field+(state['ppu.scanline']>=203 and 1 or 0)
  local interval=visibleField-lastfield;intervals[interval]=(intervals[interval] or 0)+1;lastfield=visibleField
  assert(state['ppu.scanline']<=22 or state['ppu.scanline']>=203,'4bpp swap missed the blanking boundary')
  local boss=read('_monosh_boss_state',1)
  local paused=read('_monosh_runtime_paused',1)
  if scenario~='pause' then assert(paused==0,'unexpected pause without Start') end
  bossSeen=bossSeen or boss==1;dyingSeen=dyingSeen or boss==2;doneSeen=doneSeen or boss==3
  restartSeen=restartSeen or (doneSeen and boss==0)
  trace:write(string.format('{"present":%d,"field":%d,"interval":%d,"logic":%d,"page":%d,"boss":%d,"line":%d,"paused":%d,"player":%d,"x":%d,"bottom":%d,"shots":%d}\n',finishes,field,interval,read('_monosh_runtime_frame_counter',2),read('fx4_page',2),read('_monosh_boss_state',1),state['ppu.scanline'],paused,read('_monosh_player_state',1),read('_monosh_player_x',2),read('_monosh_player_bottom',2),read('_monosh_player_bullet_count',1)))
  trace:write(string.format('{"dmaBytes":%d,"field":%d}\n',read('fx4_dma_bytes',2),field))
  if finishes%60==0 or scenario=='assets' or scenario=='full' or scenario=='players' or scenario=='bullets' or scenario=='effects' or scenario=='stage_effects' then
    dump(string.format('frame%05d_fb.bin',finishes),emu.memType.gsuWorkRam,0x2000,24576)
    dump(string.format('frame%05d_vram.bin',finishes),emu.memType.snesVideoRam,0,65536)
    dump(string.format('frame%05d_bounds.bin',finishes),emu.memType.gsuWorkRam,0x580,64)
    dump(string.format('frame%05d_dma.bin',finishes),emu.memType.gsuWorkRam,0x1100,100)
    if labels.player4_present then
      dump(string.format('frame%05d_oam.bin',finishes),emu.memType.snesSpriteRam,0,544)
      dump(string.format('frame%05d_cgram.bin',finishes),emu.memType.snesCgRam,0,512)
      dump(string.format('frame%05d_obj.bin',finishes),emu.memType.snesMemory,0x7e0000+labels.fx_obj_present,136)
    end
    local f=assert(io.open(output..string.format('/frame%05d_meta.json',finishes),'w'))
    f:write(string.format('{"page":%d,"field":%d,"playerObjSource":%d,"playerInput":%s,"bulletAges":%s,"effectPhase":%s}',read('fx4_page',2),field,labels.player4_present and read('player4_present',2) or 0,presentPlayerInput or 'null',presentBulletAges or 'null',presentEffectPhase and tostring(presentEffectPhase) or 'null'));f:close()
  end
end)
emu.addEventCallback(function()
  local input={a=scenario~='boss_hold' and scenario~='boss' and scenario~='effects' and scenario~='stage_effects'}
  if scenario=='controls' then
    local phase=(field//240)%4
    input.up=phase==0;input.right=phase==1;input.down=phase==2;input.left=phase==3
  end
  if scenario=='pause' then input.start=(field>=151 and field<=154) or (field>=211 and field<=214) end
  if scenario=='play' and read('_monosh_boss_state',1)==1 then
    local z=read('_boss_part_z',1)
    local height=emu.read(0x7e0000+labels._monosh_boss_face_geometry+math.min(z,110)*2+1,emu.memType.snesMemory)
    local tx=read('_boss_part_x',1);local ty=read('_boss_part_bottom',1)-height//2+20
    local x=read('_monosh_player_x',2);local y=read('_monosh_player_bottom',2)
    input.right=x<tx-3;input.left=x>tx+3;input.up=y>ty+3;input.down=y<ty-3
  end
  emu.setInput(input,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
  field=field+1
  if (scenario=='bullets' or scenario=='effects' or scenario=='stage_effects') and field%2==0 then screenshot(string.format('anim%05d',field)) end
  if field%240==0 then screenshot(string.format('screen%05d',field)) end
  if field>=maxframe then
    finished=true
    for k,v in pairs(profile) do trace:write(string.format('{"profile":"%s","n":%d,"sumMs":%.3f,"maxMs":%.3f}\n',k,v.n,v.sum/21477.272,v.max/21477.272)) end
    local sf=assert(io.open(output.."/state.txt","w")); for k,v in pairs(emu.getState()) do sf:write(tostring(k).."="..tostring(v).."\n") end;sf:close()
    trace:write(string.format('{"mathChecks":%d}\n',mathChecks))
    trace:close()
    local f=assert(io.open(output..'/summary.json','w'))
    local ii={};for k,v in pairs(intervals) do ii[#ii+1]=string.format('"%d":%d',k,v) end
    f:write(string.format('{"fields":%d,"renders":%d,"starts":%d,"halves":%d,"logicCalls":%d,"logic":%d,"gsuMaxMs":%.6f,"intervals":{%s},"bossSeen":%s,"dyingSeen":%s,"doneSeen":%s,"restartSeen":%s}',field,finishes,starts,halves,logic,read('_monosh_runtime_frame_counter',2),gsuMax,table.concat(ii,','),tostring(bossSeen),tostring(dyingSeen),tostring(doneSeen),tostring(restartSeen)));f:close();emu.stop(0)
  end
end,emu.eventType.startFrame)
